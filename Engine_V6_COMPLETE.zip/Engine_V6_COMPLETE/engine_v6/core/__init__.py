"""
Core modules for Engine V6
"""
