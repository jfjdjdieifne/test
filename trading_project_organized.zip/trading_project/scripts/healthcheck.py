#!/usr/bin/env python3
"""Operational smoke check for imports and end-to-end integration."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Allow running directly from a source checkout without installation.
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from trading_system import TradingAnalysisPipeline  # noqa: E402
from trading_system.core.causal_kernels import NUMBA_OK  # noqa: E402


def sample(n: int = 160) -> pd.DataFrame:
    rng = np.random.default_rng(2026)
    open_ = 100 + np.cumsum(rng.normal(0, 0.4, n))
    close = open_ + rng.normal(0, 0.25, n)
    high = np.maximum(open_, close) + np.abs(rng.normal(0.15, 0.05, n)) + 1e-9
    low = np.minimum(open_, close) - np.abs(rng.normal(0.15, 0.05, n)) - 1e-9
    atr = pd.Series(high - low).rolling(14, min_periods=1).mean().to_numpy()

    sh = np.zeros(n, bool); sl = np.zeros(n, bool)
    shp = np.full(n, np.nan); slp = np.full(n, np.nan)
    sho = np.full(n, np.nan); slo = np.full(n, np.nan)
    for i in range(20, n, 30):
        sh[i] = True; shp[i] = high[i-4]; sho[i] = i-4
    for i in range(35, n, 30):
        sl[i] = True; slp[i] = low[i-4]; slo[i] = i-4

    state = np.full(n, "RANGING", object)
    bos = np.full(n, "NONE", object)
    strength = np.zeros(n)
    for k, i in enumerate(range(45, n, 50)):
        direction = "BULLISH" if k % 2 == 0 else "BEARISH"
        state[i:] = direction; bos[i:] = "BOS"; strength[i:] = 0.7

    return pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close,
        "volume": np.abs(rng.normal(500, 50, n)), "atr": atr,
        "volatility_percentile": pd.Series(atr).rolling(80, min_periods=2).rank(pct=True).fillna(0.5),
        "adaptive_period": np.full(n, 14),
        "swing_high": sh, "swing_low": sl,
        "swing_high_price": shp, "swing_low_price": slp,
        "swing_high_origin_index": sho, "swing_low_origin_index": slo,
        "structure_state": state, "last_bos_type": bos,
        "last_bos_strength": strength,
        "last_swing_high": pd.Series(high).rolling(30, min_periods=1).max(),
        "last_swing_low": pd.Series(low).rolling(30, min_periods=1).min(),
    })


def main() -> int:
    try:
        result = TradingAnalysisPipeline().analyze(sample())
        report = {
            "status": "ok",
            "rows": len(result.dataframe),
            "columns": len(result.dataframe.columns),
            "numba": NUMBA_OK,
            "timings_ms": {k: round(v, 3) for k, v in result.timings_ms.items()},
            "registries": {
                "liquidity_levels": len(result.liquidity_levels),
                "order_blocks": len(result.order_blocks),
                "breakers": len(result.breaker_blocks),
                "fvgs": len(result.fair_value_gaps),
                "inverted_fvgs": len(result.inverted_fvgs),
            },
        }
        print(json.dumps(report, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "failed", "error": f"{type(exc).__name__}: {exc}"}, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
