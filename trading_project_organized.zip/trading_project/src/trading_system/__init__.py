"""Causal trading analysis toolkit assembled from the supplied modules."""

from trading_system.pipeline import (
    IntegrationDataError,
    PipelineConfig,
    PipelineResult,
    TradingAnalysisPipeline,
)

__all__ = [
    "IntegrationDataError",
    "PipelineConfig",
    "PipelineResult",
    "TradingAnalysisPipeline",
]

__version__ = "0.1.0"
