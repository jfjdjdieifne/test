"""Integration pipeline for the currently available analytical engines."""

from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, Dict, List

import pandas as pd

from trading_system.engines.fvg import FVGConfig, FVGEngine
from trading_system.engines.liquidity_map import LiquidityMapConfig, LiquidityMapEngine
from trading_system.engines.order_blocks import OrderBlockConfig, OrderBlockEngine
from trading_system.engines.volume_delta import VolumeDeltaConfig, VolumeDeltaEngine


class IntegrationDataError(ValueError):
    """Raised when upstream features required by the available pipeline are absent."""


@dataclass
class PipelineConfig:
    volume_delta: VolumeDeltaConfig = field(default_factory=VolumeDeltaConfig)
    liquidity: LiquidityMapConfig = field(default_factory=LiquidityMapConfig)
    order_blocks: OrderBlockConfig = field(default_factory=OrderBlockConfig)
    fvg: FVGConfig = field(default_factory=FVGConfig)


@dataclass
class PipelineResult:
    dataframe: pd.DataFrame
    liquidity_levels: List[Any]
    order_blocks: List[Any]
    breaker_blocks: List[Any]
    fair_value_gaps: List[Any]
    inverted_fvgs: List[Any]
    timings_ms: Dict[str, float]


class TradingAnalysisPipeline:
    """Run Modules 3.1 -> 2.2 -> 4.1 -> 4.2 on one enriched dataset.

    The input must already contain outputs from the not-yet-supplied upstream
    modules (ATR/regime, swings and market structure). A fresh engine instance
    is created for every call, preventing state leakage between datasets.
    """

    REQUIRED_UPSTREAM_COLUMNS = {
        "open", "high", "low", "close", "volume", "atr",
        "volatility_percentile", "adaptive_period",
        "swing_high", "swing_low", "swing_high_price", "swing_low_price",
        "structure_state", "last_bos_type", "last_bos_strength",
        "last_swing_high", "last_swing_low",
    }

    def __init__(self, config: PipelineConfig | None = None) -> None:
        self.config = config or PipelineConfig()

    def _validate(self, df: pd.DataFrame) -> None:
        if not isinstance(df, pd.DataFrame):
            raise IntegrationDataError("Input must be a pandas DataFrame.")
        missing = sorted(self.REQUIRED_UPSTREAM_COLUMNS - set(df.columns))
        if missing:
            raise IntegrationDataError(
                "Missing upstream columns: " + ", ".join(missing)
                + ". Modules 1.1/2.1/structure are not present in the supplied source yet."
            )
        if df.columns.has_duplicates:
            raise IntegrationDataError("Input contains duplicate column names.")

    @staticmethod
    def _run_timed(name: str, timings: Dict[str, float], function):
        start = perf_counter()
        result = function()
        timings[name] = (perf_counter() - start) * 1000.0
        return result

    def analyze(self, df: pd.DataFrame) -> PipelineResult:
        self._validate(df)
        timings: Dict[str, float] = {}

        volume_engine = VolumeDeltaEngine(self.config.volume_delta)
        work = self._run_timed("volume_delta", timings, lambda: volume_engine.analyze(df))

        liquidity_engine = LiquidityMapEngine(self.config.liquidity)
        work, levels = self._run_timed(
            "liquidity_map", timings,
            lambda: liquidity_engine.analyze(
                work, buy_volume_col="buy_volume", sell_volume_col="sell_volume"
            ),
        )

        ob_engine = OrderBlockEngine(self.config.order_blocks)
        work, order_blocks, breakers = self._run_timed(
            "order_blocks", timings, lambda: ob_engine.analyze(work)
        )

        fvg_engine = FVGEngine(self.config.fvg)
        work, fvgs, inverted = self._run_timed(
            "fvg", timings, lambda: fvg_engine.analyze(work)
        )

        if work.columns.has_duplicates:
            duplicates = work.columns[work.columns.duplicated()].tolist()
            raise RuntimeError(f"Pipeline produced duplicate columns: {duplicates}")

        return PipelineResult(
            dataframe=work,
            liquidity_levels=levels,
            order_blocks=order_blocks,
            breaker_blocks=breakers,
            fair_value_gaps=fvgs,
            inverted_fvgs=inverted,
            timings_ms=timings,
        )
