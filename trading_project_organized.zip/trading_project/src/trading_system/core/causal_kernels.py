"""
causal_kernels.py
Shared Causal Computation Primitives — Layer 0

Extracted per the "Rule of Three": as of Module 3.2, the following
patterns had each been independently duplicated across 2-3 files:

  1. Adaptive EMA / Wilder RMA recurrence
     (Module 1.1, 3.1, 3.2 — 3x identical math, different variable names)
  2. Adaptive-period-from-coefficient-of-variation estimation
     (Module 1.1's _adaptive_period, and Module 3.1/3.2's VERBATIM
     duplicate _fallback_adaptive_period — a duplication the original
     external review did not catch, found independently here)
  3. Rolling causal percentile ranking, in TWO distinct causal categories
     that must NOT be confused with each other (see below)
  4. Variable-window O(n) causal mean (Module 3.2)
  5. O(n*window) causal rolling OLS slope (Module 3.1)
  6. Streaming causal percentile tracker (Module 2.2's
     _CausalPercentileTracker — a THIRD, structurally different pattern:
     incremental/stateful rather than vectorized/stateless)
  7. verify_truncation_invariance test utility (Module 3.1)

NEW HARDENING ADDED HERE (not present in any of the original 3 copies):
  - `validate_period_array()`: every kernel that divides by a period value
    now validates period_arr > 0 BEFORE use. None of the three original
    duplicates had this guard — a future module forgetting to .clip() its
    period array upstream would previously cause a SILENT division-by-zero
    producing inf/NaN that propagates undetected. This is now impossible.

CRITICAL DISTINCTION — READ BEFORE USING ANY PERCENTILE FUNCTION:

    causal_percentile_predictive(series, window)
        Applies shift(1) BEFORE ranking. Use this when the percentile
        result will be used to make a DECISION THAT AFFECTS HOW BAR i's
        OWN DATA GETS PROCESSED (a meta-parameter decision) — e.g.
        "which smoothing period should I apply AT bar i?". Without the
        shift, you'd have bar i's processing depend on a rank computed
        FROM bar i's own value — a subtle circularity, not a strict
        look-ahead bias, but forbidden by this project's stricter
        "true live simulation" standard.

    causal_percentile_descriptive(series, window)
        NO extra shift — ranks bar i's value INCLUSIVELY against its own
        trailing history. Use this when the percentile is a plain
        DESCRIPTIVE OUTPUT (e.g. "how unusual is today's absorption
        score?") that does not feed back into how bar i itself was
        computed. This is causally sound: bar i's value is fully known
        the moment bar i closes — the earliest possible moment anyway.

    Using the wrong one is not a crash — it's a silent logic bug. Every
    call site in every module MUST justify, in a comment, which category
    applies.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Optional

try:
    from numba import njit
    NUMBA_OK = True
except ImportError:
    NUMBA_OK = False


# ── Shared Exceptions ────────────────────────────────────────────────────
class CausalKernelError(Exception):
    """Base exception for all shared kernel primitives."""


class KernelValidationError(CausalKernelError):
    """Raised when kernel inputs violate a mathematical precondition
    (e.g. a period array containing zero/negative values, which would
    silently produce inf/NaN via division)."""


# ── Validation (new hardening, not present in any original duplicate) ──
def validate_period_array(period_arr: np.ndarray, min_period: int = 1) -> None:
    """
    Guards every kernel below from silent division-by-zero / negative-
    period corruption. Call this BEFORE any kernel that computes
    `alpha = 1.0 / period_arr[i]` or uses period as a window length.
    """
    if period_arr.size == 0:
        raise KernelValidationError("period_arr is empty.")
    if not np.isfinite(period_arr).all():
        raise KernelValidationError("period_arr contains NaN/Inf.")
    if (period_arr < min_period).any():
        bad_count = int((period_arr < min_period).sum())
        raise KernelValidationError(
            f"period_arr contains {bad_count} value(s) < {min_period}. "
            f"This would cause division-by-zero or invalid window sizes. "
            f"Ensure upstream .clip(min_period, ...) was applied."
        )


# ── Kernel 1: Adaptive EMA / Wilder RMA recurrence ──────────────────────
# Mathematically identical recurrence; two names preserved because
# "Wilder RMA" is a specific named concept in classical TA (used for ATR),
# while "adaptive EMA" is the more general framing used for signed signals
# like delta_ratio or absorption_signal. Both point to the same function.
if NUMBA_OK:
    @njit(cache=True)
    def _adaptive_ema_numba(x: np.ndarray, period_arr: np.ndarray, seed: float) -> np.ndarray:
        n = len(x)
        out = np.empty(n)
        out[0] = seed
        for i in range(1, n):
            alpha = 1.0 / period_arr[i]
            out[i] = alpha * x[i] + (1.0 - alpha) * out[i - 1]
        return out
else:
    def _adaptive_ema_numba(x: np.ndarray, period_arr: np.ndarray, seed: float) -> np.ndarray:
        n = len(x)
        out = np.empty(n)
        out[0] = seed
        for i in range(1, n):
            alpha = 1.0 / period_arr[i]
            out[i] = alpha * x[i] + (1.0 - alpha) * out[i - 1]
        return out


def adaptive_ema_kernel(x: np.ndarray, period_arr: np.ndarray, seed: float) -> np.ndarray:
    """
    Causal recurrence: out[i] = alpha*x[i] + (1-alpha)*out[i-1],
    alpha = 1/period_arr[i] (per-bar variable smoothing).

    Raises:
        KernelValidationError if period_arr has any value < 1.
    """
    validate_period_array(period_arr, min_period=1)
    return _adaptive_ema_numba(x.astype(float), period_arr.astype(np.int64), float(seed))


# Alias preserving classical-TA naming for ATR-style usage (Module 1.1).
wilder_rma_adaptive = adaptive_ema_kernel


# ── Kernel 2: O(n) variable-window causal mean (Prefix Sums) ────────────
if NUMBA_OK:
    @njit(cache=True)
    def _variable_window_mean_numba(x: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
        n = len(x)
        prefix = np.empty(n + 1)
        prefix[0] = 0.0
        for i in range(n):
            prefix[i + 1] = prefix[i] + x[i]
        out = np.empty(n)
        for i in range(n):
            p = period_arr[i]
            if p > max_window:
                p = max_window
            w = p if p <= (i + 1) else (i + 1)
            start = i - w + 1
            out[i] = (prefix[i + 1] - prefix[start]) / w
        return out
else:
    def _variable_window_mean_numba(x: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
        n = len(x)
        prefix = np.concatenate(([0.0], np.cumsum(x)))
        out = np.empty(n)
        for i in range(n):
            w = min(period_arr[i], max_window, i + 1)
            start = i - w + 1
            out[i] = (prefix[i + 1] - prefix[start]) / w
        return out


def variable_window_causal_mean(x: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
    """O(n) causal moving average with per-bar variable window length."""
    validate_period_array(period_arr, min_period=1)
    if max_window < 1:
        raise KernelValidationError("max_window must be >= 1.")
    return _variable_window_mean_numba(x.astype(float), period_arr.astype(np.int64), int(max_window))


# ── Kernel 3: O(n*window) causal rolling OLS slope ──────────────────────
# NOTE: unlike the mean above, OLS cross-terms (sum_xy) genuinely cannot
# be reduced to a simple prefix-sum trick when the window length varies
# per-bar — this IS the legitimate O(n*window) case (see Module 3.1
# design note). Do not "optimize" this away without re-deriving the math.
if NUMBA_OK:
    @njit(cache=True)
    def _rolling_ols_slope_numba(y: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
        n = len(y)
        out = np.zeros(n)
        for i in range(n):
            p = period_arr[i]
            if p > max_window:
                p = max_window
            start = i - p + 1
            if start < 0:
                start = 0
            w = i - start + 1
            if w < 3:
                out[i] = 0.0
                continue
            sum_x = 0.0
            sum_y = 0.0
            sum_xy = 0.0
            sum_xx = 0.0
            for j in range(w):
                xv = float(j)
                yv = y[start + j]
                sum_x += xv
                sum_y += yv
                sum_xy += xv * yv
                sum_xx += xv * xv
            mean_x = sum_x / w
            mean_y = sum_y / w
            denom = sum_xx - w * mean_x * mean_x
            out[i] = 0.0 if denom == 0.0 else (sum_xy - w * mean_x * mean_y) / denom
        return out
else:
    def _rolling_ols_slope_numba(y: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
        n = len(y)
        out = np.zeros(n)
        for i in range(n):
            p = min(period_arr[i], max_window)
            start = max(i - p + 1, 0)
            w = i - start + 1
            if w < 3:
                continue
            x = np.arange(w, dtype=float)
            yv = y[start:i + 1]
            mean_x, mean_y = x.mean(), yv.mean()
            denom = (x * x).sum() - w * mean_x * mean_x
            out[i] = 0.0 if denom == 0.0 else ((x * yv).sum() - w * mean_x * mean_y) / denom
        return out


def rolling_ols_slope_adaptive(y: np.ndarray, period_arr: np.ndarray, max_window: int) -> np.ndarray:
    """Causal rolling OLS slope, window length = period_arr[i] (clipped)."""
    validate_period_array(period_arr, min_period=1)
    if max_window < 3:
        raise KernelValidationError("max_window must be >= 3 for a meaningful regression.")
    return _rolling_ols_slope_numba(y.astype(float), period_arr.astype(np.int64), int(max_window))


# ── Percentile Category A: PREDICTIVE (shift-before-rank) ──────────────
def causal_percentile_predictive(series: pd.Series, window: int, min_samples: int) -> pd.Series:
    """
    Use when the resulting percentile decides how bar i itself gets
    processed (meta-parameter decisions). See module docstring.
    """
    return (
        series.shift(1)
              .rolling(window, min_periods=min_samples)
              .rank(pct=True)
              .fillna(0.5)
    )


# ── Percentile Category B: DESCRIPTIVE (inclusive, no extra shift) ─────
def causal_percentile_descriptive(series: pd.Series, window: int, min_samples: int) -> pd.Series:
    """
    Use for plain descriptive scores that do not feed back into bar i's
    own processing. See module docstring for the formal justification.
    """
    return series.rolling(window, min_periods=min_samples).rank(pct=True).fillna(0.5)


# ── Shared: Adaptive Period from Coefficient-of-Variation ──────────────
@dataclass
class AdaptivePeriodConfig:
    """
    Shared config for the "how much should I smooth right now?" decision,
    used by Module 1.1 (on True Range) and Modules 3.1/3.2 (on delta_ratio)
    — these were IDENTICAL logic with different variable names, an
    additional duplication the original external review missed entirely.
    """
    min_period: int = 5
    max_period: int = 50
    vol_of_vol_period: int = 20
    period_rank_window: int = 100

    def __post_init__(self) -> None:
        if self.min_period < 2:
            raise KernelValidationError("min_period must be >= 2.")
        if self.max_period <= self.min_period:
            raise KernelValidationError("max_period must be > min_period.")
        if self.vol_of_vol_period < 2:
            raise KernelValidationError("vol_of_vol_period must be >= 2.")
        if self.period_rank_window < 2:
            raise KernelValidationError("period_rank_window must be >= 2.")


def compute_adaptive_period_from_volatility(
    signal: pd.Series, config: AdaptivePeriodConfig
) -> pd.Series:
    """
    Unifies Module 1.1's _adaptive_period(tr) and Module 3.1/3.2's
    (verbatim-duplicated) _fallback_adaptive_period(delta_ratio).

    Uses .abs() in the mean unconditionally — safe for both use cases:
    for an always-positive signal (True Range), abs() is a no-op; for a
    signed signal (delta_ratio), abs() is required. This single function
    now correctly serves both original call sites without behavior change.

    High CoV (unstable signal) -> SHORT period (react fast).
    Low  CoV (stable signal)   -> LONG  period (smooth more).
    Uses PREDICTIVE percentile category (meta-parameter decision) — the
    resulting period decides how THIS bar's own smoothing is applied.
    """
    w = config.vol_of_vol_period
    roll_std = signal.rolling(w, min_periods=2).std()
    roll_mean = signal.abs().rolling(w, min_periods=2).mean()
    cov = (roll_std / roll_mean.replace(0, np.nan)).fillna(0.5)

    cov_pct = causal_percentile_predictive(cov, config.period_rank_window, min_samples=2)

    period = (
        config.max_period - cov_pct * (config.max_period - config.min_period)
    ).round().astype(int).clip(config.min_period, config.max_period)

    return period


# ── Streaming Causal Percentile Tracker (state-machine variant) ────────
from collections import deque


class CausalPercentileTracker:
    """
    Incremental/stateful causal percentile tracker (originally in Module
    2.2). Structurally DIFFERENT from the two vectorized functions above:
    this is for online/bar-by-bar scenarios with a bounded history buffer
    (e.g. tracking a running distribution of gap sizes between liquidity
    levels, where levels are created sparsely and irregularly — not every
    bar — making a vectorized pandas rolling window inapplicable).

    Discipline: call `.percentile_value()` / `.rank_of()` to READ, THEN
    call `.push()` to add the new observation. This read-then-push order
    is what guarantees zero look-ahead in the caller's logic.
    """

    def __init__(self, buffer_size: int, min_samples: int, bootstrap_value: float):
        if min_samples > buffer_size:
            raise KernelValidationError(
                "min_samples cannot exceed buffer_size (tracker would never "
                "become statistically 'ready')."
            )
        self._buffer: deque = deque(maxlen=buffer_size)
        self._min_samples = min_samples
        self._bootstrap_value = bootstrap_value

    @property
    def ready(self) -> bool:
        return len(self._buffer) >= self._min_samples

    def percentile_value(self, pct: float) -> float:
        if not self.ready:
            return self._bootstrap_value
        return float(np.percentile(np.fromiter(self._buffer, dtype=float), pct * 100))

    def rank_of(self, value: float) -> float:
        if len(self._buffer) < 2:
            return 0.5
        arr = np.fromiter(self._buffer, dtype=float)
        return float((arr < value).mean())

    def push(self, value: float) -> None:
        self._buffer.append(value)


# ── Shared Test Utility: Truncation Invariance ──────────────────────────
def verify_truncation_invariance(
    engine_factory, df: pd.DataFrame, split_at: int = 500, **analyze_kwargs
) -> None:
    """
    Verifies df[:split_at] output is IDENTICAL whether analyzed alone or
    as a prefix of a larger dataset — the project's standard proof of
    zero look-ahead. Checks numeric AND categorical columns.

    IMPORTANT: **kwargs passed here must describe the SAME declared
    conditions used elsewhere in the same test session (e.g. bar_type),
    even though most kwargs only affect warnings/labels, not the actual
    numeric computation — mismatched kwargs across test calls in the same
    file are a readability/consistency smell, even when harmless.
    """
    raw_a = engine_factory().analyze(df.iloc[:split_at].copy(), **analyze_kwargs)
    raw_b = engine_factory().analyze(df.copy(), **analyze_kwargs)

    # Engines may return a DataFrame directly or a tuple/list whose first
    # element is the primary DataFrame (registries follow it).
    out_a = raw_a[0] if isinstance(raw_a, (tuple, list)) else raw_a
    out_b = raw_b[0] if isinstance(raw_b, (tuple, list)) else raw_b
    if not isinstance(out_a, pd.DataFrame) or not isinstance(out_b, pd.DataFrame):
        raise TypeError("analyze() must return a DataFrame or place it first in a tuple/list.")

    numeric_cols = out_a.select_dtypes(include=[np.number]).columns
    other_cols = [c for c in out_a.columns if c not in numeric_cols]

    for col in numeric_cols:
        a = out_a[col].to_numpy()
        b = out_b[col].iloc[:split_at].to_numpy()
        matches = np.isclose(a, b, rtol=0.0, atol=1e-9, equal_nan=True)
        if not matches.all():
            finite = np.isfinite(a) & np.isfinite(b)
            diff = float(np.max(np.abs(a[finite] - b[finite]))) if finite.any() else float("nan")
            raise AssertionError(f"LOOK-AHEAD in numeric column '{col}': max diff = {diff}")

    for col in other_cols:
        mismatches = (out_a[col].values != out_b[col].iloc[:split_at].values).sum()
        assert mismatches == 0, f"LOOK-AHEAD in categorical column '{col}': {mismatches} mismatches"

    print(f"✅ Truncation invariance verified on {len(numeric_cols)} numeric + "
          f"{len(other_cols)} categorical columns.")


# ── Self-Test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"⚡ Numba: {'ON' if NUMBA_OK else 'OFF'}")

    np.random.seed(0)
    n = 1000
    x = np.random.randn(n).cumsum()
    period = np.full(n, 14)

    # 1. adaptive_ema_kernel basic sanity + validation guard
    out = adaptive_ema_kernel(x, period, seed=x[0])
    assert len(out) == n
    try:
        adaptive_ema_kernel(x, np.full(n, 0), seed=0.0)
        print("❌ FAILED to catch zero period")
    except KernelValidationError as e:
        print(f"✅ Caught zero-period guard: {e}")

    # 2. variable_window_causal_mean vs pandas rolling mean equivalence
    pd_mean = pd.Series(x).rolling(14, min_periods=1).mean().values
    kernel_mean = variable_window_causal_mean(x, period, max_window=200)
    assert np.abs(pd_mean - kernel_mean).max() < 1e-9
    print("✅ variable_window_causal_mean matches pandas rolling mean.")

    # 3. Predictive vs Descriptive percentile must differ
    s = pd.Series(np.random.randn(200))
    pred = causal_percentile_predictive(s, window=50, min_samples=2)
    desc = causal_percentile_descriptive(s, window=50, min_samples=2)
    assert not pred.equals(desc), "Predictive and Descriptive percentiles must differ!"
    print("✅ Predictive vs Descriptive percentile categories are distinct.")

    # 4. compute_adaptive_period_from_volatility sanity
    cfg = AdaptivePeriodConfig()
    period_out = compute_adaptive_period_from_volatility(pd.Series(x), cfg)
    assert period_out.between(cfg.min_period, cfg.max_period).all()
    print("✅ compute_adaptive_period_from_volatility bounds respected.")

    # 5. CausalPercentileTracker cross-validation guard
    try:
        CausalPercentileTracker(buffer_size=10, min_samples=20, bootstrap_value=0.5)
        print("❌ FAILED to catch min_samples > buffer_size")
    except KernelValidationError as e:
        print(f"✅ Caught: {e}")

    print("\n✅ All causal_kernels.py self-tests passed.")
