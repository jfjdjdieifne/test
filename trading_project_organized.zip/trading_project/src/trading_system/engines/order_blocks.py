"""
Module 4.1: Order Block Detector
VERSION 2 - Hardened Production Grade

Fixes applied over V1 (independent review — one external critique claim
was verified INCORRECT upon tracing, one was confirmed and escalated to
also affect Module 2.2 retroactively, and one new issue was found
independently):

  1. CONFIRMED BUG: `get_active_obs_at()` queried CURRENT lifecycle status
     instead of reconstructing the HISTORICAL status at the requested
     bar_index. Fixed via `broken_at_index` comparison. ESCALATED: the
     identical bug exists in Module 2.2's `get_active_levels_at()` — a
     retroactive patch snippet is provided in this file's trailing
     comments; it must be applied to Module 2.2 as well.

  2. CORRECTED DIAGNOSIS: an external critique claimed a "race condition"
     in breaker_strength assignment when multiple OBs break on the same
     bar. Tracing the original loop structure line-by-line shows this
     claim is FALSE — the `self._breakers[-1]` correction happens inside
     the per-OB inner loop iteration, immediately after that specific
     OB's breaker is appended, so it is never ambiguous in practice.
     HOWEVER, the suggested fix (pass bos_strength directly into
     `_process_ob_interaction` instead of correcting it after the fact)
     is adopted anyway — not to fix a live bug, but to eliminate a
     fragile IMPLICIT invariant (correctness depending on loop execution
     order) that a future refactor could silently break.

  3. NEW (independently found, not in any prior review): consecutive
     same-direction BOS events with no intervening opposite-color candle
     could create DUPLICATE Order Blocks at the identical origin candle
     and price zone. Fixed with a deduplication guard, analogous in
     spirit to Module 2.2's equal-level handling but structurally
     simpler here (exact origin-bar match, not a statistical gap test).

  4. Minor cleanup: removed a redundant double-call to
     `validate_period_array` (adaptive_ema_kernel already validates
     internally; the outer call added no protection, just noise).
"""

from __future__ import annotations

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from enum import IntEnum, Enum
from typing import Optional, List, Dict, Tuple

from trading_system.core.causal_kernels import (
    adaptive_ema_kernel,
    causal_percentile_descriptive,
    causal_percentile_predictive,          # noqa: F401 — exercised transitively
    validate_period_array,
    verify_truncation_invariance,
    CausalPercentileTracker,               # noqa: F401 — reserved for future use
    compute_adaptive_period_from_volatility,
    AdaptivePeriodConfig,
    KernelValidationError,
)


# ── Exceptions ───────────────────────────────────────────────────────────
class OrderBlockError(Exception):
    """Base exception for this module."""


class OrderBlockConfigError(OrderBlockError):
    """Raised when OrderBlockConfig has invalid/contradictory values."""


class OrderBlockDataError(OrderBlockError):
    """Raised when input dataframe fails sanity/schema/consistency checks."""


# ── Enums ────────────────────────────────────────────────────────────────
class OBType(Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"


class OBStatus(IntEnum):
    ACTIVE = 0
    MITIGATED = 1
    TESTED_CE = 2
    BROKEN = 3


# ── Persistent Objects ───────────────────────────────────────────────────
@dataclass
class OrderBlock:
    ob_id: int
    ob_type: OBType
    ob_high: float
    ob_low: float
    ob_mid: float
    ob_ce: float
    origin_bar_index: int
    confirmed_bar_index: int

    status: OBStatus = OBStatus.ACTIVE
    quality_score: float = 0.0
    sweep_evidence: float = 0.0
    bos_strength_at_formation: float = 0.0
    ofi_evidence: float = 0.0
    absorption_evidence: float = 0.0
    discount_premium_evidence: float = 0.0

    mitigated_at_index: Optional[int] = None
    tested_ce_at_index: Optional[int] = None
    broken_at_index: Optional[int] = None
    breaker_id: Optional[int] = None

    def is_monitorable(self) -> bool:
        return self.status != OBStatus.BROKEN

    def was_monitorable_at(self, bar_index: int) -> bool:
        """
        FIX (Problem 1): reconstructs HISTORICAL monitorability at a given
        bar_index, instead of querying current live status. An OB is
        considered monitorable at bar_index iff it was already confirmed
        by then AND (it never broke, OR it broke strictly AFTER bar_index).
        """
        if self.confirmed_bar_index > bar_index:
            return False
        if self.broken_at_index is None:
            return True
        return self.broken_at_index > bar_index


@dataclass
class BreakerBlock:
    breaker_id: int
    original_ob_id: int
    breaker_direction: OBType
    breaker_strength: float
    confirmed_bar_index: int
    zone_high: float
    zone_low: float


# ── Config ───────────────────────────────────────────────────────────────
@dataclass
class OrderBlockConfig:
    lookback_absolute_cap: int = 200

    base_weight_sweep: float = 0.30
    base_weight_bos_strength: float = 0.20
    base_weight_ofi: float = 0.20
    base_weight_absorption: float = 0.15
    base_weight_discount_premium: float = 0.15

    flow_evidence_regime_sensitivity: float = 0.50
    disagreement_dampening_factor: float = 0.50

    quality_percentile_window: int = 100
    quality_percentile_min_samples: int = 10

    net_bias_period_config: AdaptivePeriodConfig = field(
        default_factory=lambda: AdaptivePeriodConfig(
            min_period=5, max_period=50, vol_of_vol_period=20, period_rank_window=100
        )
    )

    def __post_init__(self) -> None:
        if self.lookback_absolute_cap < 3:
            raise OrderBlockConfigError("lookback_absolute_cap must be >= 3.")
        weights = [
            self.base_weight_sweep, self.base_weight_bos_strength,
            self.base_weight_ofi, self.base_weight_absorption,
            self.base_weight_discount_premium,
        ]
        if any(w < 0 for w in weights):
            raise OrderBlockConfigError("All base weights must be non-negative.")
        if abs(sum(weights) - 1.0) > 1e-6:
            raise OrderBlockConfigError("Base weights must sum to 1.0.")
        if not (0.0 <= self.flow_evidence_regime_sensitivity <= 1.0):
            raise OrderBlockConfigError("flow_evidence_regime_sensitivity must be in [0,1].")
        if not (0.0 <= self.disagreement_dampening_factor <= 1.0):
            raise OrderBlockConfigError("disagreement_dampening_factor must be in [0,1].")
        if self.quality_percentile_window < self.quality_percentile_min_samples:
            raise OrderBlockConfigError(
                "quality_percentile_window must be >= quality_percentile_min_samples."
            )


# ── Main Engine ──────────────────────────────────────────────────────────
class OrderBlockEngine:

    def __init__(self, config: Optional[OrderBlockConfig] = None):
        self.cfg = config or OrderBlockConfig()
        self._all_obs: List[OrderBlock] = []
        self._active: Dict[OBType, List[OrderBlock]] = {OBType.BULLISH: [], OBType.BEARISH: []}
        self._breakers: List[BreakerBlock] = []
        self._next_ob_id = 0
        self._next_breaker_id = 0

    # ── Validation ───────────────────────────────────────────────────
    def _validate_input(
        self, df: pd.DataFrame, required_cols: List[str], optional_groups: Dict[str, List[str]]
    ) -> Dict[str, bool]:
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            raise OrderBlockDataError(f"Missing required columns: {missing}")

        availability = {
            group_name: all(c in df.columns for c in cols)
            for group_name, cols in optional_groups.items()
        }

        for col in required_cols:
            if df[col].dtype in (float, np.float64) and not np.isfinite(df[col].values).all():
                raise OrderBlockDataError(f"Column '{col}' contains NaN/Inf.")

        if (df["high"] < df["low"]).any():
            raise OrderBlockDataError("'high' < 'low' detected.")
        if (df["atr"] <= 0).any():
            raise OrderBlockDataError("ATR column contains non-positive values.")

        valid_structure_states = {"BULLISH", "BEARISH", "RANGING"}
        bad_states = set(df["structure_state"].dropna().unique()) - valid_structure_states
        if bad_states:
            raise OrderBlockDataError(
                f"Unrecognized structure_state values: {bad_states}. "
                f"Expected subset of {valid_structure_states}."
            )
        return availability

    # ── BOS event inference (or explicit override) ─────────────────
    def _detect_bos_events(
        self, df: pd.DataFrame,
        bos_confirmed_bull_col: Optional[str], bos_confirmed_bear_col: Optional[str],
    ) -> Tuple[np.ndarray, np.ndarray]:
        n = len(df)
        if bos_confirmed_bull_col and bos_confirmed_bull_col in df.columns:
            bull_event = df[bos_confirmed_bull_col].values.astype(bool)
            bear_event = df[bos_confirmed_bear_col].values.astype(bool)
            return bull_event, bear_event

        bos_type = df["last_bos_type"].values
        bos_strength = df["last_bos_strength"].values
        structure = df["structure_state"].values

        changed = np.zeros(n, dtype=bool)
        changed[1:] = (
            (bos_strength[1:] != bos_strength[:-1]) |
            (structure[1:] != structure[:-1]) |
            (bos_type[1:] != bos_type[:-1])
        )
        changed[0] = bos_type[0] == "BOS"

        is_bos = bos_type == "BOS"
        bull_event = changed & is_bos & (structure == "BULLISH")
        bear_event = changed & is_bos & (structure == "BEARISH")
        return bull_event, bear_event

    # ── OB candle search ─────────────────────────────────────────────
    def _find_opposing_candle(
        self, open_: np.ndarray, close: np.ndarray, confirm_idx: int,
        lookback_n: int, want_bearish: bool
    ) -> Optional[int]:
        lower = max(0, confirm_idx - lookback_n)
        for j in range(confirm_idx - 1, lower - 1, -1):
            is_bearish = close[j] < open_[j]
            if is_bearish == want_bearish:
                return j
        return None

    # ── Quality scoring ──────────────────────────────────────────────
    def _score_ob(
        self, ob_type: OBType, origin_idx: int, confirm_idx: int,
        volatility_pct: np.ndarray,
        liq_max_sweep_score: Optional[np.ndarray],
        delta_ratio: Optional[np.ndarray],
        absorption_score: Optional[np.ndarray], absorption_direction: Optional[np.ndarray],
        last_bos_strength: np.ndarray,
        last_swing_high: np.ndarray, last_swing_low: np.ndarray,
        ob_mid: float,
    ) -> Tuple[float, float, float, float, float, float]:
        if liq_max_sweep_score is not None:
            sweep_ev = float(np.max(liq_max_sweep_score[origin_idx:confirm_idx + 1]))
        else:
            sweep_ev = 0.5

        bos_ev = float(np.clip(last_bos_strength[confirm_idx], 0.0, 1.0))

        if delta_ratio is not None:
            dr = delta_ratio[origin_idx]
            ofi_ev = float(np.clip(-dr, 0.0, 1.0)) if ob_type == OBType.BULLISH else float(np.clip(dr, 0.0, 1.0))
        else:
            ofi_ev = 0.5

        if absorption_score is not None and absorption_direction is not None:
            expected_dir = "BULLISH" if ob_type == OBType.BULLISH else "BEARISH"
            raw_abs = float(np.abs(absorption_score[origin_idx]))
            absorb_ev = raw_abs if absorption_direction[origin_idx] == expected_dir \
                else raw_abs * self.cfg.disagreement_dampening_factor
        else:
            absorb_ev = 0.5

        rng = last_swing_high[confirm_idx] - last_swing_low[confirm_idx]
        if rng > 1e-9:
            if ob_type == OBType.BULLISH:
                disc_prem_ev = float(np.clip((last_swing_high[confirm_idx] - ob_mid) / rng, 0.0, 1.0))
            else:
                disc_prem_ev = float(np.clip((ob_mid - last_swing_low[confirm_idx]) / rng, 0.0, 1.0))
        else:
            disc_prem_ev = 0.5

        vp = float(volatility_pct[confirm_idx])
        flow_damp = 1.0 - self.cfg.flow_evidence_regime_sensitivity * vp
        w_sweep = self.cfg.base_weight_sweep
        w_bos = self.cfg.base_weight_bos_strength
        w_ofi = self.cfg.base_weight_ofi * flow_damp
        w_absorb = self.cfg.base_weight_absorption * flow_damp
        w_disc = self.cfg.base_weight_discount_premium

        total_w = max(w_sweep + w_bos + w_ofi + w_absorb + w_disc, 1e-9)
        w_sweep, w_bos, w_ofi, w_absorb, w_disc = (
            w_sweep / total_w, w_bos / total_w, w_ofi / total_w, w_absorb / total_w, w_disc / total_w
        )

        quality = (
            w_sweep * sweep_ev + w_bos * bos_ev + w_ofi * ofi_ev
            + w_absorb * absorb_ev + w_disc * disc_prem_ev
        )
        return float(np.clip(quality, 0.0, 1.0)), sweep_ev, bos_ev, ofi_ev, absorb_ev, disc_prem_ev

    # ── OB creation (with deduplication guard — FIX 3) ─────────────
    def _create_ob(
        self, ob_type: OBType, origin_idx: int, confirm_idx: int,
        high: np.ndarray, low: np.ndarray,
        volatility_pct: np.ndarray, last_bos_strength: np.ndarray,
        last_swing_high: np.ndarray, last_swing_low: np.ndarray,
        liq_max_sweep_score: Optional[np.ndarray], delta_ratio: Optional[np.ndarray],
        absorption_score: Optional[np.ndarray], absorption_direction: Optional[np.ndarray],
    ) -> OrderBlock:
        # FIX (Problem 3, independently found): prevent duplicate OB
        # creation when consecutive same-direction BOS events resolve to
        # the identical opposing candle (no new candle of that color
        # formed in between). Returns the existing OB unchanged rather
        # than silently duplicating the same price zone.
        for existing in self._active[ob_type]:
            if existing.origin_bar_index == origin_idx:
                return existing

        ob_high = float(high[origin_idx])
        ob_low = float(low[origin_idx])
        ob_mid = (ob_high + ob_low) / 2.0
        ob_ce = ob_mid

        quality, sweep_ev, bos_ev, ofi_ev, absorb_ev, disc_ev = self._score_ob(
            ob_type, origin_idx, confirm_idx, volatility_pct,
            liq_max_sweep_score, delta_ratio, absorption_score, absorption_direction,
            last_bos_strength, last_swing_high, last_swing_low, ob_mid,
        )

        ob = OrderBlock(
            ob_id=self._next_ob_id, ob_type=ob_type, ob_high=ob_high, ob_low=ob_low,
            ob_mid=ob_mid, ob_ce=ob_ce, origin_bar_index=origin_idx, confirmed_bar_index=confirm_idx,
            quality_score=quality, sweep_evidence=sweep_ev, bos_strength_at_formation=bos_ev,
            ofi_evidence=ofi_ev, absorption_evidence=absorb_ev, discount_premium_evidence=disc_ev,
        )
        self._next_ob_id += 1
        self._all_obs.append(ob)
        self._active[ob_type].append(ob)
        return ob

    # ── Lifecycle interaction (strength passed directly — FIX 2) ────
    def _process_ob_interaction(
        self, ob: OrderBlock, bar_index: int, bar_high: float, bar_low: float, bar_close: float,
        opposite_bos_event: bool, bos_strength_at_bar: float,
    ) -> None:
        if opposite_bos_event:
            breached = (bar_close < ob.ob_low) if ob.ob_type == OBType.BULLISH else (bar_close > ob.ob_high)
            if breached:
                ob.status = OBStatus.BROKEN
                ob.broken_at_index = bar_index

                breaker_dir = OBType.BEARISH if ob.ob_type == OBType.BULLISH else OBType.BULLISH
                breaker = BreakerBlock(
                    breaker_id=self._next_breaker_id, original_ob_id=ob.ob_id,
                    breaker_direction=breaker_dir,
                    # FIX (Problem 2, defensive): strength assigned directly
                    # at creation — no reliance on post-hoc list-order
                    # correction via self._breakers[-1].
                    breaker_strength=bos_strength_at_bar,
                    confirmed_bar_index=bar_index, zone_high=ob.ob_high, zone_low=ob.ob_low,
                )
                self._breakers.append(breaker)
                ob.breaker_id = breaker.breaker_id
                self._next_breaker_id += 1
                return

        touched = not (bar_low > ob.ob_high or bar_high < ob.ob_low)
        if not touched:
            return

        new_status = OBStatus.MITIGATED
        if ob.mitigated_at_index is None:
            ob.mitigated_at_index = bar_index

        ce_reached = (bar_low <= ob.ob_ce) if ob.ob_type == OBType.BULLISH else (bar_high >= ob.ob_ce)
        if ce_reached:
            new_status = OBStatus.TESTED_CE
            if ob.tested_ce_at_index is None:
                ob.tested_ce_at_index = bar_index

        ob.status = OBStatus(max(int(ob.status), int(new_status)))

    # ── Public API ────────────────────────────────────────────────────
    def analyze(
        self,
        df: pd.DataFrame,
        open_col: str = "open", high_col: str = "high", low_col: str = "low", close_col: str = "close",
        atr_col: str = "atr", volatility_percentile_col: str = "volatility_percentile",
        adaptive_period_col: str = "adaptive_period",
        structure_state_col: str = "structure_state",
        last_bos_type_col: str = "last_bos_type", last_bos_strength_col: str = "last_bos_strength",
        last_swing_high_col: str = "last_swing_high", last_swing_low_col: str = "last_swing_low",
        bos_confirmed_bull_col: Optional[str] = None, bos_confirmed_bear_col: Optional[str] = None,
        liq_max_sweep_score_col: Optional[str] = "liq_max_sweep_score",
        delta_ratio_col: Optional[str] = "delta_ratio",
        absorption_score_col: Optional[str] = "absorption_score",
        absorption_direction_col: Optional[str] = "absorption_direction_raw",
    ) -> Tuple[pd.DataFrame, List[OrderBlock], List[BreakerBlock]]:

        required = [
            open_col, high_col, low_col, close_col, atr_col, volatility_percentile_col,
            adaptive_period_col, structure_state_col, last_bos_type_col, last_bos_strength_col,
            last_swing_high_col, last_swing_low_col,
        ]
        optional_groups = {
            "liquidity": [liq_max_sweep_score_col] if liq_max_sweep_score_col else [],
            "order_flow": [delta_ratio_col] if delta_ratio_col else [],
            "absorption": [absorption_score_col, absorption_direction_col]
                if absorption_score_col and absorption_direction_col else [],
        }
        availability = self._validate_input(df, required, optional_groups)

        n = len(df)
        open_ = df[open_col].values.astype(float)
        high = df[high_col].values.astype(float)
        low = df[low_col].values.astype(float)
        close = df[close_col].values.astype(float)
        atr = df[atr_col].values.astype(float)
        volatility_pct = df[volatility_percentile_col].values.astype(float)
        adaptive_period = df[adaptive_period_col].values.astype(int)
        last_bos_strength = df[last_bos_strength_col].values.astype(float)
        last_swing_high = df[last_swing_high_col].values.astype(float)
        last_swing_low = df[last_swing_low_col].values.astype(float)

        liq_max_sweep_score = (
            df[liq_max_sweep_score_col].values.astype(float) if availability["liquidity"] else None
        )
        delta_ratio = df[delta_ratio_col].values.astype(float) if availability["order_flow"] else None
        absorption_score = (
            df[absorption_score_col].values.astype(float) if availability["absorption"] else None
        )
        absorption_direction = (
            df[absorption_direction_col].values if availability["absorption"] else None
        )

        bull_event, bear_event = self._detect_bos_events(df, bos_confirmed_bull_col, bos_confirmed_bear_col)

        active_bull_count = np.zeros(n, dtype=int)
        active_bear_count = np.zeros(n, dtype=int)
        nearest_bull_ob_dist_atr = np.full(n, np.nan)
        nearest_bear_ob_dist_atr = np.full(n, np.nan)
        max_bull_quality = np.zeros(n)
        max_bear_quality = np.zeros(n)
        any_ob_broken = np.zeros(n, dtype=bool)
        any_breaker_formed = np.zeros(n, dtype=bool)
        ob_net_bias_raw = np.zeros(n)

        for i in range(n):
            lookback_n = min(int(adaptive_period[i]), self.cfg.lookback_absolute_cap)

            if bull_event[i]:
                j = self._find_opposing_candle(open_, close, i, lookback_n, want_bearish=True)
                if j is not None:
                    self._create_ob(
                        OBType.BULLISH, j, i, high, low, volatility_pct,
                        last_bos_strength, last_swing_high, last_swing_low,
                        liq_max_sweep_score, delta_ratio, absorption_score, absorption_direction,
                    )
            if bear_event[i]:
                j = self._find_opposing_candle(open_, close, i, lookback_n, want_bearish=False)
                if j is not None:
                    self._create_ob(
                        OBType.BEARISH, j, i, high, low, volatility_pct,
                        last_bos_strength, last_swing_high, last_swing_low,
                        liq_max_sweep_score, delta_ratio, absorption_score, absorption_direction,
                    )

            for ob_type, opposite_event in ((OBType.BULLISH, bear_event[i]), (OBType.BEARISH, bull_event[i])):
                still_active = []
                for ob in self._active[ob_type]:
                    self._process_ob_interaction(
                        ob, i, high[i], low[i], close[i], opposite_event,
                        bos_strength_at_bar=float(last_bos_strength[i]),
                    )
                    if ob.status == OBStatus.BROKEN and ob.broken_at_index == i:
                        any_ob_broken[i] = True
                        any_breaker_formed[i] = True
                    if ob.is_monitorable():
                        still_active.append(ob)
                self._active[ob_type] = still_active

            bulls = self._active[OBType.BULLISH]
            bears = self._active[OBType.BEARISH]
            active_bull_count[i] = len(bulls)
            active_bear_count[i] = len(bears)
            if bulls:
                nearest_bull_ob_dist_atr[i] = min(abs(ob.ob_mid - close[i]) for ob in bulls) / atr[i]
                max_bull_quality[i] = max(ob.quality_score for ob in bulls)
            if bears:
                nearest_bear_ob_dist_atr[i] = min(abs(ob.ob_mid - close[i]) for ob in bears) / atr[i]
                max_bear_quality[i] = max(ob.quality_score for ob in bears)

            bull_bias = sum(ob.quality_score / (1.0 + abs(ob.ob_mid - close[i]) / atr[i]) for ob in bulls)
            bear_bias = sum(ob.quality_score / (1.0 + abs(ob.ob_mid - close[i]) / atr[i]) for ob in bears)
            ob_net_bias_raw[i] = bull_bias - bear_bias

        net_bias_series = pd.Series(ob_net_bias_raw, index=df.index)
        net_bias_period = compute_adaptive_period_from_volatility(
            net_bias_series, self.cfg.net_bias_period_config
        )
        net_bias_period_arr = net_bias_period.values.astype(np.int64)
        # FIX (cleanup): removed redundant explicit validate_period_array call —
        # adaptive_ema_kernel already performs this validation internally.
        ob_net_bias_smoothed = adaptive_ema_kernel(ob_net_bias_raw, net_bias_period_arr, seed=0.0)

        out = df.copy()
        out["active_bullish_ob_count"] = active_bull_count
        out["active_bearish_ob_count"] = active_bear_count
        out["nearest_bullish_ob_dist_atr"] = nearest_bull_ob_dist_atr
        out["nearest_bearish_ob_dist_atr"] = nearest_bear_ob_dist_atr
        out["max_bullish_ob_quality"] = max_bull_quality
        out["max_bearish_ob_quality"] = max_bear_quality
        out["any_ob_broken"] = any_ob_broken
        out["any_breaker_formed"] = any_breaker_formed
        out["ob_net_bias_raw"] = ob_net_bias_raw
        out["ob_net_bias_smoothed"] = ob_net_bias_smoothed
        out["ob_quality_percentile_context"] = causal_percentile_descriptive(
            pd.Series(np.maximum(max_bull_quality, max_bear_quality), index=df.index),
            self.cfg.quality_percentile_window, self.cfg.quality_percentile_min_samples,
        )

        return out, self._all_obs, self._breakers

    def get_active_obs_at(self, bar_index: int, ob_type: Optional[OBType] = None) -> List[OrderBlock]:
        """
        FIX (Problem 1): now reconstructs HISTORICAL monitorability via
        `was_monitorable_at()` instead of querying current live status —
        a query for bar 200 on data that now extends to bar 1000 returns
        the same result it would have returned had the engine stopped
        exactly at bar 200.
        """
        pool = self._all_obs if ob_type is None else [ob for ob in self._all_obs if ob.ob_type == ob_type]
        return [ob for ob in pool if ob.was_monitorable_at(bar_index)]

    def ob_registry_to_dataframe(self) -> pd.DataFrame:
        rows = []
        for ob in self._all_obs:
            rows.append({
                "ob_id": ob.ob_id, "type": ob.ob_type.value, "ob_high": ob.ob_high, "ob_low": ob.ob_low,
                "ob_mid": ob.ob_mid, "origin_bar": ob.origin_bar_index, "confirmed_bar": ob.confirmed_bar_index,
                "status": ob.status.name, "quality_score": ob.quality_score,
                "sweep_evidence": ob.sweep_evidence, "bos_strength": ob.bos_strength_at_formation,
                "ofi_evidence": ob.ofi_evidence, "absorption_evidence": ob.absorption_evidence,
                "discount_premium": ob.discount_premium_evidence,
                "mitigated_at": ob.mitigated_at_index, "tested_ce_at": ob.tested_ce_at_index,
                "broken_at": ob.broken_at_index, "breaker_id": ob.breaker_id,
            })
        return pd.DataFrame(rows)

    def breaker_registry_to_dataframe(self) -> pd.DataFrame:
        rows = []
        for b in self._breakers:
            rows.append({
                "breaker_id": b.breaker_id, "original_ob_id": b.original_ob_id,
                "direction": b.breaker_direction.value, "strength": b.breaker_strength,
                "confirmed_bar": b.confirmed_bar_index, "zone_high": b.zone_high, "zone_low": b.zone_low,
            })
        return pd.DataFrame(rows)


# ── Smoke Test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    np.random.seed(3)
    N = 400

    open_ = 30_000 + np.cumsum(np.random.randn(N) * 30)
    close = open_ + np.random.randn(N) * 20
    high = np.maximum(open_, close) + np.abs(np.random.randn(N) * 10) + 1e-6
    low = np.minimum(open_, close) - np.abs(np.random.randn(N) * 10) - 1e-6
    atr = pd.Series(high - low).rolling(14, min_periods=1).mean().values
    volatility_pct = pd.Series(atr).rank(pct=True).fillna(0.5).values
    adaptive_period = np.full(N, 14)

    structure_state = np.full(N, "RANGING", dtype=object)
    last_bos_type = np.full(N, "NONE", dtype=object)
    last_bos_strength = np.zeros(N)
    event_bars = list(range(50, N, 60))
    for k, eb in enumerate(event_bars):
        direction = "BULLISH" if k % 2 == 0 else "BEARISH"
        structure_state[eb:] = direction
        last_bos_type[eb:] = "BOS"
        last_bos_strength[eb:] = 0.6 + 0.1 * (k % 3)

    last_swing_high = pd.Series(high).rolling(30, min_periods=1).max().values
    last_swing_low = pd.Series(low).rolling(30, min_periods=1).min().values

    buy_vol = np.abs(np.random.randn(N) * 100 + 300)
    sell_vol = np.abs(np.random.randn(N) * 100 + 300)
    delta_ratio = np.divide(buy_vol - sell_vol, buy_vol + sell_vol)

    liq_max_sweep_score = np.random.uniform(0, 1, N)
    absorption_score = np.random.uniform(-1, 1, N)
    absorption_direction = np.where(absorption_score > 0, "BULLISH",
                                     np.where(absorption_score < 0, "BEARISH", "NEUTRAL"))

    df = pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close, "atr": atr,
        "volatility_percentile": volatility_pct, "adaptive_period": adaptive_period,
        "structure_state": structure_state, "last_bos_type": last_bos_type,
        "last_bos_strength": last_bos_strength,
        "last_swing_high": last_swing_high, "last_swing_low": last_swing_low,
        "liq_max_sweep_score": liq_max_sweep_score,
        "delta_ratio": delta_ratio,
        "absorption_score": absorption_score, "absorption_direction_raw": absorption_direction,
    })

    engine = OrderBlockEngine()
    out, obs, breakers = engine.analyze(df)

    print(out[["active_bullish_ob_count", "active_bearish_ob_count",
               "max_bullish_ob_quality", "ob_net_bias_smoothed"]].tail(15).to_string())
    print("\nOB Registry:")
    print(engine.ob_registry_to_dataframe().to_string())
    print("\nBreaker Registry:")
    print(engine.breaker_registry_to_dataframe().to_string())

    print("\n--- Causal Correctness Assertions ---")
    for ob in obs:
        assert ob.confirmed_bar_index > ob.origin_bar_index
        pre = engine.get_active_obs_at(ob.confirmed_bar_index - 1)
        assert ob.ob_id not in [o.ob_id for o in pre], "LOOK-AHEAD: OB visible before confirmation!"
    print(f"✅ Verified {len(obs)} OBs: no premature visibility.")

    # NEW: explicit test for the historical-reconstruction fix (Problem 1)
    print("\n--- Historical Reconstruction Test (Problem 1 fix) ---")
    broken_obs = [ob for ob in obs if ob.broken_at_index is not None]
    if broken_obs:
        sample = broken_obs[0]
        mid_point = (sample.confirmed_bar_index + sample.broken_at_index) // 2
        active_at_mid = engine.get_active_obs_at(mid_point)
        assert sample.ob_id in [o.ob_id for o in active_at_mid], (
            "Historical reconstruction FAILED: an OB that was active mid-lifecycle "
            "was not returned by a query at that historical bar."
        )
        print(f"✅ OB #{sample.ob_id} correctly reconstructed as active at historical "
              f"bar {mid_point} (confirmed={sample.confirmed_bar_index}, "
              f"broken={sample.broken_at_index}), despite being BROKEN in current state.")
    else:
        print("⚠️  No broken OBs in this random seed to exercise the historical test.")

    # NEW: duplicate-OB prevention test (Problem 3)
    print("\n--- Deduplication Test (Problem 3 fix) ---")
    origins = [(ob.ob_type, ob.origin_bar_index) for ob in obs]
    assert len(origins) == len(set(origins)), "Duplicate OB detected at same origin bar!"
    print("✅ No duplicate OBs created at the same origin candle.")

    print("\n--- Truncation Invariance Test ---")
    verify_truncation_invariance(OrderBlockEngine, df, split_at=200)

    print("\n--- Validation Tests ---")
    bad = df.copy()
    bad.loc[5, "structure_state"] = "SIDEWAYS_INVALID"
    try:
        OrderBlockEngine().analyze(bad)
        print("❌ FAILED to catch invalid structure_state")
    except OrderBlockDataError as e:
        print(f"✅ Caught: {e}")
