"""
Module 2.2: Liquidity Map Engine
VERSION 3 - Hardened Production Grade (Performance-Optimized)

Fixes applied over V2 (via independent review, not blind acceptance):

  1. Active-Levels Index: separate per-type active lists (`_active_bsl`,
     `_active_ssl`) so the hot per-bar loop only iterates levels that are
     still ACTIVE/TESTED. Dead levels (SWEPT/BROKEN) are pruned from the
     hot path immediately but retained in `_levels` for full history/debug.
     This does NOT change algorithmic complexity class — it removes
     constant-factor overhead from iterating dead objects, which compounds
     meaningfully over tens of thousands of bars with hundreds of levels.

  2. DISCLOSED (not "fixed", by design): `_create_level`'s equal-level
     search still scans the FULL historical `_levels` list (including dead
     ones), because equal-level/noise-floor statistics are legitimately
     defined over the entire historical price-gap distribution for that
     level type, not just currently-active levels. This is a deliberate
     accuracy-vs-performance tradeoff, not an oversight. If profiling
     proves this a bottleneck at scale, replace with a sorted-array +
     binary-search nearest-neighbor structure — deferred consciously, not
     neglected silently.

  3. DISCLOSED (not "fixed", flagged for empirical validation): a fresh
     touch resets `_decay_accum` to 1.0 fully, causing a discontinuous
     jump in `strength_score` for long-dormant levels. This is an
     intentional design choice (a retest re-validates relevance), but it
     is flagged here as a concrete acceptance criterion for Module 8.1
     (Performance Analyzer): if this discontinuity measurably degrades
     Layer 6 scoring stability, replace with a partial-revival function
     instead of a hard reset.
"""

from __future__ import annotations

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Tuple

from trading_system.core.causal_kernels import CausalPercentileTracker


# ── Exceptions ───────────────────────────────────────────────────────────
class LiquidityMapError(Exception):
    """Base exception for this module."""


class LiquidityConfigError(LiquidityMapError):
    """Raised when LiquidityMapConfig has invalid/contradictory values."""


class LiquidityDataError(LiquidityMapError):
    """Raised when input dataframe fails sanity/schema checks."""


# ── Enums ────────────────────────────────────────────────────────────────
class LevelType(Enum):
    BSL = "BSL"
    SSL = "SSL"


class LevelStatus(Enum):
    ACTIVE = "ACTIVE"
    TESTED = "TESTED"
    SWEPT = "SWEPT"
    BROKEN = "BROKEN"


# ── Config ───────────────────────────────────────────────────────────────
@dataclass
class LiquidityMapConfig:
    equal_level_bootstrap_ratio: float = 0.10
    equal_level_min_samples: int = 20
    equal_level_gap_percentile: float = 0.25
    gap_history_buffer_size: int = 200

    broken_bootstrap_ratio: float = 0.20
    broken_min_samples: int = 20
    broken_threshold_percentile: float = 0.75
    broken_history_buffer_size: int = 200

    strength_half_life_multiplier: float = 10.0
    touch_diminishing_exponent: float = 0.5

    base_weight_reversal: float = 0.35
    base_weight_wick: float = 0.35
    base_weight_order_flow: float = 0.30
    wick_weight_regime_sensitivity: float = 0.50
    sweep_decision_boundary: float = 0.50

    wick_rank_window: int = 100
    wick_rank_min_samples: int = 10

    def __post_init__(self) -> None:
        if not (0.0 < self.equal_level_gap_percentile < 1.0):
            raise LiquidityConfigError("equal_level_gap_percentile must be in (0,1).")
        if not (0.0 < self.broken_threshold_percentile < 1.0):
            raise LiquidityConfigError("broken_threshold_percentile must be in (0,1).")
        if self.equal_level_min_samples < 2:
            raise LiquidityConfigError("equal_level_min_samples must be >= 2.")
        if self.broken_min_samples < 2:
            raise LiquidityConfigError("broken_min_samples must be >= 2.")
        if self.strength_half_life_multiplier <= 0:
            raise LiquidityConfigError("strength_half_life_multiplier must be > 0.")

        weights = [self.base_weight_reversal, self.base_weight_wick, self.base_weight_order_flow]
        if any(w < 0 for w in weights):
            raise LiquidityConfigError("Base weights must be non-negative.")
        if abs(sum(weights) - 1.0) > 1e-6:
            raise LiquidityConfigError("Base weights must sum to 1.0.")
        if not (0.0 <= self.wick_weight_regime_sensitivity <= 1.0):
            raise LiquidityConfigError("wick_weight_regime_sensitivity must be in [0,1].")
        if not (0.0 < self.sweep_decision_boundary < 1.0):
            raise LiquidityConfigError("sweep_decision_boundary must be in (0,1).")

        if self.equal_level_min_samples > self.gap_history_buffer_size:
            raise LiquidityConfigError(
                "equal_level_min_samples cannot exceed gap_history_buffer_size."
            )
        if self.broken_min_samples > self.broken_history_buffer_size:
            raise LiquidityConfigError(
                "broken_min_samples cannot exceed broken_history_buffer_size."
            )
        if self.wick_rank_min_samples > self.wick_rank_window:
            raise LiquidityConfigError(
                "wick_rank_min_samples cannot exceed wick_rank_window."
            )


# ── Liquidity Level (persistent object) ────────────────────────────────
@dataclass
class LiquidityLevel:
    level_id: int
    level_type: LevelType
    price: float
    origin_bar_index: int
    created_at_index: int
    origin_strength: float

    status: LevelStatus = LevelStatus.ACTIVE
    touch_count: int = 0
    strength_score: float = 0.0
    is_equal_level: bool = False
    equal_group_id: Optional[int] = None
    last_interaction_index: Optional[int] = None
    last_sweep_score: Optional[float] = None
    swept_at_index: Optional[int] = None
    broken_at_index: Optional[int] = None

    _decay_accum: float = field(default=1.0, repr=False)
    _touch_bonus: float = field(default=1.0, repr=False)

    def is_monitorable(self) -> bool:
        return self.status in (LevelStatus.ACTIVE, LevelStatus.TESTED)

    def was_monitorable_at(self, bar_index: int) -> bool:
        """Reconstruct whether this level was monitorable at a historical bar."""
        if self.created_at_index > bar_index:
            return False
        terminal_index = (
            self.swept_at_index
            if self.swept_at_index is not None
            else self.broken_at_index
        )
        return terminal_index is None or terminal_index > bar_index



# ── Main Engine ──────────────────────────────────────────────────────────
class LiquidityMapEngine:

    def __init__(self, config: Optional[LiquidityMapConfig] = None):
        self.cfg = config or LiquidityMapConfig()
        self._levels: List[LiquidityLevel] = []          # full history (debug/registry)
        # FIX: hot-path active index, pruned immediately on terminal status.
        self._active: Dict[LevelType, List[LiquidityLevel]] = {
            LevelType.BSL: [], LevelType.SSL: [],
        }
        self._next_id = 0
        self._next_group_id = 0

        self._gap_tracker: Dict[LevelType, CausalPercentileTracker] = {
            lt: CausalPercentileTracker(
                self.cfg.gap_history_buffer_size, self.cfg.equal_level_min_samples,
                self.cfg.equal_level_bootstrap_ratio)
            for lt in LevelType
        }
        self._wick_tracker: Dict[LevelType, CausalPercentileTracker] = {
            lt: CausalPercentileTracker(
                self.cfg.wick_rank_window, self.cfg.wick_rank_min_samples, 0.5)
            for lt in LevelType
        }
        self._broken_tracker: Dict[LevelType, CausalPercentileTracker] = {
            lt: CausalPercentileTracker(
                self.cfg.broken_history_buffer_size, self.cfg.broken_min_samples,
                self.cfg.broken_bootstrap_ratio)
            for lt in LevelType
        }

    # ── Validation ───────────────────────────────────────────────────
    def _validate_input(self, df: pd.DataFrame, cols: Dict[str, str]) -> None:
        required = [
            cols["high"], cols["low"], cols["close"], cols["atr"],
            cols["volatility_percentile"], cols["adaptive_period"],
            cols["swing_high"], cols["swing_low"],
            cols["swing_high_price"], cols["swing_low_price"],
        ]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise LiquidityDataError(f"Missing required columns: {missing}")

        for flag_col in (cols["swing_high"], cols["swing_low"]):
            if df[flag_col].dtype != bool:
                raise LiquidityDataError(
                    f"Column '{flag_col}' must be boolean (True only on the "
                    f"CONFIRMATION bar from Module 2.1)."
                )
        if (df[cols["atr"]] <= 0).any():
            raise LiquidityDataError("ATR column contains non-positive values.")
        if len(df) < 2:
            raise LiquidityDataError("Need at least 2 bars.")

    # ── Level creation ──────────────────────────────────────────────
    def _create_level(
        self, level_type: LevelType, price: float, bar_index: int,
        origin_bar_index: int, origin_strength: float, current_atr: float
    ) -> LiquidityLevel:
        level = LiquidityLevel(
            level_id=self._next_id, level_type=level_type, price=price,
            origin_bar_index=origin_bar_index, created_at_index=bar_index,
            origin_strength=origin_strength, strength_score=origin_strength,
        )
        self._next_id += 1

        # DISCLOSED tradeoff (see module docstring point 2): intentionally
        # scans FULL history (not just active) — equal-level noise-floor
        # statistics are legitimately defined over the whole historical
        # gap distribution for this level type, dead levels included.
        same_type_prior = [lv for lv in self._levels if lv.level_type == level_type]
        if same_type_prior:
            gaps = [abs(price - lv.price) / current_atr for lv in same_type_prior]
            min_gap = min(gaps)
            nearest_level = same_type_prior[int(np.argmin(gaps))]

            tracker = self._gap_tracker[level_type]
            tolerance = tracker.percentile_value(self.cfg.equal_level_gap_percentile)

            if min_gap <= tolerance:
                level.is_equal_level = True
                nearest_level.is_equal_level = True
                if nearest_level.equal_group_id is None:
                    nearest_level.equal_group_id = self._next_group_id
                    self._next_group_id += 1
                level.equal_group_id = nearest_level.equal_group_id

            tracker.push(min_gap)

        self._levels.append(level)
        self._active[level_type].append(level)  # FIX: hot-path index
        return level

    # ── Sweep score computation ────────────────────────────────────
    def _compute_sweep_score(
        self, level: LiquidityLevel, bar_high: float, bar_low: float,
        bar_close: float, current_atr: float, volatility_pct: float,
        order_flow_ratio: Optional[float]
    ) -> float:
        bar_range = max(bar_high - bar_low, 1e-9)

        if level.level_type == LevelType.BSL:
            penetration = bar_high - level.price
            reversal_component = np.clip((bar_high - bar_close) / bar_range, 0.0, 1.0)
            of_component = (
                np.clip((-order_flow_ratio + 1.0) / 2.0, 0.0, 1.0)
                if order_flow_ratio is not None else None
            )
        else:
            penetration = level.price - bar_low
            reversal_component = np.clip((bar_close - bar_low) / bar_range, 0.0, 1.0)
            of_component = (
                np.clip((order_flow_ratio + 1.0) / 2.0, 0.0, 1.0)
                if order_flow_ratio is not None else None
            )

        penetration_ratio = max(penetration, 0.0) / current_atr

        tracker = self._wick_tracker[level.level_type]
        wick_component = tracker.rank_of(penetration_ratio)
        tracker.push(penetration_ratio)

        wick_weight = self.cfg.base_weight_wick * (
            1.0 - self.cfg.wick_weight_regime_sensitivity * volatility_pct
        )
        reversal_weight = self.cfg.base_weight_reversal
        of_weight = self.cfg.base_weight_order_flow if of_component is not None else 0.0

        total = max(reversal_weight + wick_weight + of_weight, 1e-9)
        reversal_weight, wick_weight, of_weight = (
            reversal_weight / total, wick_weight / total, of_weight / total
        )

        score = reversal_weight * reversal_component + wick_weight * wick_component
        if of_component is not None:
            score += of_weight * of_component

        return float(np.clip(score, 0.0, 1.0))

    # ── Touch event handler ─────────────────────────────────────────
    def _register_touch(self, level: LiquidityLevel) -> None:
        """
        DISCLOSED design choice (see module docstring point 3): full reset
        of _decay_accum to 1.0 causes a discontinuous strength_score jump
        for long-dormant levels. Flagged as an empirical acceptance
        criterion for Module 8.1, not changed speculatively here.
        """
        level.touch_count += 1
        level._decay_accum = 1.0
        level._touch_bonus = (1 + level.touch_count) ** self.cfg.touch_diminishing_exponent

    # ── Interaction handling ───────────────────────────────────────
    def _process_interaction(
        self, level: LiquidityLevel, bar_index: int, bar_high: float,
        bar_low: float, bar_close: float, current_atr: float,
        volatility_pct: float, order_flow_ratio: Optional[float]
    ) -> Optional[float]:
        touched = (
            bar_high >= level.price if level.level_type == LevelType.BSL
            else bar_low <= level.price
        )
        if not touched:
            return None

        closed_beyond = (
            bar_close > level.price if level.level_type == LevelType.BSL
            else bar_close < level.price
        )
        overshoot = (
            (bar_close - level.price) if level.level_type == LevelType.BSL
            else (level.price - bar_close)
        )

        level.last_interaction_index = bar_index
        self._register_touch(level)

        if closed_beyond:
            overshoot_ratio = max(overshoot, 0.0) / current_atr
            btracker = self._broken_tracker[level.level_type]
            broken_threshold = btracker.percentile_value(self.cfg.broken_threshold_percentile)

            is_decisive = overshoot_ratio > broken_threshold
            btracker.push(overshoot_ratio)

            if is_decisive:
                level.status = LevelStatus.BROKEN
                level.broken_at_index = bar_index
                level.last_sweep_score = None
                return None

        sweep_score = self._compute_sweep_score(
            level, bar_high, bar_low, bar_close, current_atr,
            volatility_pct, order_flow_ratio
        )
        level.last_sweep_score = sweep_score

        if not closed_beyond and sweep_score > self.cfg.sweep_decision_boundary:
            level.status = LevelStatus.SWEPT
            level.swept_at_index = bar_index
        else:
            level.status = LevelStatus.TESTED

        return sweep_score

    # ── Public API ────────────────────────────────────────────────────
    def analyze(
        self,
        df: pd.DataFrame,
        high_col: str = "high", low_col: str = "low", close_col: str = "close",
        atr_col: str = "atr", volatility_percentile_col: str = "volatility_percentile",
        adaptive_period_col: str = "adaptive_period",
        swing_high_col: str = "swing_high", swing_low_col: str = "swing_low",
        swing_high_price_col: str = "swing_high_price", swing_low_price_col: str = "swing_low_price",
        swing_high_origin_index_col: Optional[str] = "swing_high_origin_index",
        swing_low_origin_index_col: Optional[str] = "swing_low_origin_index",
        swing_strength_col: Optional[str] = "swing_strength",
        buy_volume_col: Optional[str] = None, sell_volume_col: Optional[str] = None,
    ) -> Tuple[pd.DataFrame, List[LiquidityLevel]]:
        cols = dict(
            high=high_col, low=low_col, close=close_col, atr=atr_col,
            volatility_percentile=volatility_percentile_col,
            adaptive_period=adaptive_period_col,
            swing_high=swing_high_col, swing_low=swing_low_col,
            swing_high_price=swing_high_price_col, swing_low_price=swing_low_price_col,
        )
        self._validate_input(df, cols)

        has_strength = swing_strength_col is not None and swing_strength_col in df.columns
        has_of = (
            buy_volume_col is not None and sell_volume_col is not None
            and buy_volume_col in df.columns and sell_volume_col in df.columns
        )

        n = len(df)
        high = df[high_col].values
        low = df[low_col].values
        close = df[close_col].values
        atr = df[atr_col].values
        vol_pct = df[volatility_percentile_col].values
        adap_period = df[adaptive_period_col].values
        sh_flag = df[swing_high_col].values
        sl_flag = df[swing_low_col].values
        sh_price = df[swing_high_price_col].values
        sl_price = df[swing_low_price_col].values
        strength_arr = df[swing_strength_col].values if has_strength else None
        sh_origin = (
            df[swing_high_origin_index_col].values
            if swing_high_origin_index_col and swing_high_origin_index_col in df.columns
            else None
        )
        sl_origin = (
            df[swing_low_origin_index_col].values
            if swing_low_origin_index_col and swing_low_origin_index_col in df.columns
            else None
        )
        buy_vol = df[buy_volume_col].values if has_of else None
        sell_vol = df[sell_volume_col].values if has_of else None

        active_bsl_count = np.zeros(n, dtype=int)
        active_ssl_count = np.zeros(n, dtype=int)
        nearest_bsl_dist_atr = np.full(n, np.nan)
        nearest_ssl_dist_atr = np.full(n, np.nan)
        max_sweep_score = np.zeros(n)
        any_broken = np.zeros(n, dtype=bool)
        any_swept = np.zeros(n, dtype=bool)

        prev_half_life = None
        decay_per_bar = 1.0

        for i in range(n):
            current_atr = atr[i]

            of_ratio = None
            if has_of:
                tot = buy_vol[i] + sell_vol[i]
                of_ratio = float((buy_vol[i] - sell_vol[i]) / tot) if tot > 0 else 0.0

            # 1) Register newly confirmed swings (added to BOTH _levels and _active)
            if sh_flag[i]:
                strength = float(strength_arr[i]) if has_strength and not np.isnan(strength_arr[i]) else 0.5
                origin_idx = int(sh_origin[i]) if sh_origin is not None and not pd.isna(sh_origin[i]) else i
                self._create_level(LevelType.BSL, float(sh_price[i]), i, origin_idx, strength, current_atr)
            if sl_flag[i]:
                strength = float(strength_arr[i]) if has_strength and not np.isnan(strength_arr[i]) else 0.5
                origin_idx = int(sl_origin[i]) if sl_origin is not None and not pd.isna(sl_origin[i]) else i
                self._create_level(LevelType.SSL, float(sl_price[i]), i, origin_idx, strength, current_atr)

            # 2) Process interactions — ONLY over active levels (FIX: hot-path index)
            bar_max_sweep = 0.0
            for lt in LevelType:
                still_active = []
                for level in self._active[lt]:
                    fresh_score = self._process_interaction(
                        level, i, high[i], low[i], close[i], current_atr,
                        float(vol_pct[i]), of_ratio
                    )
                    if fresh_score is not None:
                        bar_max_sweep = max(bar_max_sweep, fresh_score)
                    if level.status == LevelStatus.BROKEN:
                        any_broken[i] = True
                    elif level.status == LevelStatus.SWEPT:
                        any_swept[i] = True

                    if level.is_monitorable():
                        still_active.append(level)
                    # else: level is terminal — dropped from hot path here,
                    # but remains permanently in self._levels for history.
                self._active[lt] = still_active

            # 3) Global decay: one pow() per bar (half_life is market-wide)
            half_life = max(self.cfg.strength_half_life_multiplier * adap_period[i], 1.0)
            if half_life != prev_half_life:
                decay_per_bar = 0.5 ** (1.0 / half_life)
                prev_half_life = half_life

            for lt in LevelType:
                for level in self._active[lt]:
                    level._decay_accum *= decay_per_bar
                    level.strength_score = (
                        level.origin_strength * level._decay_accum * level._touch_bonus
                    )

            # 4) Per-bar summary (reads directly from the now-pruned active index)
            bsl_active = self._active[LevelType.BSL]
            ssl_active = self._active[LevelType.SSL]
            active_bsl_count[i] = len(bsl_active)
            active_ssl_count[i] = len(ssl_active)
            if bsl_active:
                nearest_bsl_dist_atr[i] = min(abs(lv.price - close[i]) for lv in bsl_active) / current_atr
            if ssl_active:
                nearest_ssl_dist_atr[i] = min(abs(lv.price - close[i]) for lv in ssl_active) / current_atr
            max_sweep_score[i] = bar_max_sweep

        out = df.copy()
        out["liq_active_bsl_count"] = active_bsl_count
        out["liq_active_ssl_count"] = active_ssl_count
        out["liq_nearest_bsl_dist_atr"] = nearest_bsl_dist_atr
        out["liq_nearest_ssl_dist_atr"] = nearest_ssl_dist_atr
        out["liq_max_sweep_score"] = max_sweep_score
        out["liq_any_broken"] = any_broken
        out["liq_any_swept"] = any_swept

        return out, self._levels

    def get_active_levels_at(self, bar_index: int) -> List[LiquidityLevel]:
        """Return levels that were monitorable at ``bar_index``."""
        return [lv for lv in self._levels if lv.was_monitorable_at(bar_index)]

    def registry_to_dataframe(self) -> pd.DataFrame:
        rows = []
        for lv in self._levels:
            rows.append({
                "level_id": lv.level_id, "type": lv.level_type.value,
                "price": lv.price, "origin_bar": lv.origin_bar_index,
                "created_at": lv.created_at_index, "status": lv.status.value,
                "touch_count": lv.touch_count, "strength_score": lv.strength_score,
                "is_equal_level": lv.is_equal_level, "equal_group_id": lv.equal_group_id,
                "swept_at": lv.swept_at_index, "broken_at": lv.broken_at_index,
            })
        return pd.DataFrame(rows)


# ── Smoke Test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import time as _t

    np.random.seed(42)
    N = 500

    close = 30_000 + np.cumsum(np.random.randn(N) * 40)
    high = close + np.abs(np.random.randn(N) * 25)
    low = close - np.abs(np.random.randn(N) * 25)
    atr = pd.Series(high - low).rolling(14, min_periods=1).mean().values
    vol_pct = pd.Series(atr).rank(pct=True).values
    adaptive_period = np.full(N, 14)

    swing_high = np.zeros(N, dtype=bool)
    swing_low = np.zeros(N, dtype=bool)
    swing_high_price = np.full(N, np.nan)
    swing_low_price = np.full(N, np.nan)
    swing_high_origin_index = np.full(N, np.nan)
    swing_low_origin_index = np.full(N, np.nan)

    known_confirmations = []
    for i in range(20, N, 15):
        swing_high[i] = True
        swing_high_price[i] = high[i - 5]
        swing_high_origin_index[i] = i - 5
        known_confirmations.append((i, i - 5, high[i - 5], LevelType.BSL))
    for i in range(28, N, 17):
        swing_low[i] = True
        swing_low_price[i] = low[i - 5]
        swing_low_origin_index[i] = i - 5
        known_confirmations.append((i, i - 5, low[i - 5], LevelType.SSL))

    df = pd.DataFrame({
        "high": high, "low": low, "close": close, "atr": atr,
        "volatility_percentile": vol_pct, "adaptive_period": adaptive_period,
        "swing_high": swing_high, "swing_low": swing_low,
        "swing_high_price": swing_high_price, "swing_low_price": swing_low_price,
        "swing_high_origin_index": swing_high_origin_index,
        "swing_low_origin_index": swing_low_origin_index,
    })

    engine = LiquidityMapEngine()
    t0 = _t.perf_counter()
    out, registry = engine.analyze(df)
    print(f"✅ {N} bars processed in {(_t.perf_counter()-t0)*1000:.2f} ms")

    print(out[["liq_active_bsl_count", "liq_active_ssl_count",
               "liq_nearest_bsl_dist_atr", "liq_max_sweep_score"]].tail(15))
    print("\nRegistry status distribution:")
    print(engine.registry_to_dataframe()["status"].value_counts())

    print("\n--- Causal Correctness Assertions ---")
    for confirm_idx, origin_idx, price, ltype in known_confirmations:
        matches = [
            lv for lv in registry
            if lv.level_type == ltype and lv.created_at_index == confirm_idx
        ]
        assert matches, f"No level created at confirmation bar {confirm_idx}"
        lv = matches[0]
        assert lv.origin_bar_index == origin_idx
        assert abs(lv.price - price) < 1e-9
    print(f"✅ Verified {len(known_confirmations)} levels: correct causal metadata.")

    for confirm_idx, origin_idx, price, ltype in known_confirmations:
        pre_confirm_active = engine.get_active_levels_at(confirm_idx - 1)
        assert all(lv.price != price for lv in pre_confirm_active), (
            "LOOK-AHEAD VIOLATION"
        )
    print("✅ Zero look-ahead verified.")

    # NEW: verify hot-path index consistency — active index must never
    # contain a terminal-status level.
    for lt in LevelType:
        for lv in engine._active[lt]:
            assert lv.is_monitorable(), "Active index leaked a terminal-status level!"
    print("✅ Active-levels index integrity verified: no dead levels in hot path.")

    print(f"\nTotal levels created (full history): {len(registry)}")
    print(f"Currently active: BSL={len(engine._active[LevelType.BSL])}, "
          f"SSL={len(engine._active[LevelType.SSL])}")
