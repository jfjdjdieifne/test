"""
Module 4.2: Fair Value Gap (FVG) + Premium/Discount Engine
VERSION 1 - Production Grade

Detects 3-candle Fair Value Gaps, tracks their persistent lifecycle
(ACTIVE -> PARTIAL -> CE_FILLED -> FILLED / INVERTED), and computes a
continuous, structure-relative Premium/Discount positioning score.

INDEPENDENT DESIGN DECISIONS:

  1. FVG INVERSION DOES NOT REQUIRE BOS CONFIRMATION — a deliberate
     departure from Module 4.1's strict Breaker rule. An Order Block
     represents a discrete institutional decision point; breaking it is
     a STRUCTURAL event, hence the strict BOS requirement. A Fair Value
     Gap represents a statistical price inefficiency; its inversion
     (Inverted FVG / IFVG in ICT theory) is a PRICE-ACTION event (a
     decisive close through the gap's far edge), not a structural one.
     Applying Module 4.1's rule here would be "false consistency" —
     imposing a rule where its underlying justification doesn't apply.

  2. "Decisive inversion" reuses the CausalPercentileTracker statistical
     pattern from Module 2.2's BROKEN-threshold logic (self-calibrating
     from observed overshoot ratios) rather than a hardcoded ratio. This
     is intentional pattern REUSE (same statistical question, asked in a
     structurally analogous lifecycle), not code duplication — FVG
     lifecycle is architecturally closer to Module 2.2's Liquidity Level
     (a "does price statistically commit past this point" question) than
     to Module 4.1's Order Block (a "was this structural decision point
     invalidated" question).

  3. NO fixed Fibonacci OTE zone (0.618-0.786) is hardcoded. These ratios
     are numerologically popular in ICT/SMC practice but have no rigorous
     statistical derivation for any specific market/timeframe — hardcoding
     them would violate this project's core anti-magic-number principle.
     Instead, `discount_score`/`premium_score` are exposed as continuous
     [0,1] values; if a specific zone empirically matters, Module 8.2
     (Adaptive Weight Updater) can discover that relationship from data,
     rather than us assuming it a priori.

  4. OB-confluence distance is converted to a score via PERCENTILE RANK
     of the distance against its own causal history (using the already-
     imported `causal_percentile_descriptive`), not an arbitrary decay
     function like exp(-k*distance) — eliminating another potential
     magic constant (the decay rate k).

  5. STRUCTURALLY IMPOSSIBLE duplicate detection: unlike Module 4.1
     (where a backward search across multiple BOS events could resolve
     to the same candle), FVG detection here is a fixed-offset 3-candle
     check anchored at (i-2, i-1, i) for every bar — there is no search,
     hence no mechanism that could ever produce two FVGs with identical
     origin coordinates. No deduplication guard is implemented because
     none is needed; this is a designed invariant, not an oversight.

  6. FVG "stacking" (overlapping consecutive gaps during strong impulsive
     moves) is intentionally NOT deduplicated or merged (unlike Module
     2.2's equal-level handling for swing highs/lows) — each FVG in a
     stack represents a distinct inefficiency at a distinct price and
     time, and ICT theory treats stacked FVGs as a meaningful signal of
     sustained displacement. Blindly reapplying Module 2.2's merge logic
     here would destroy real information.

  7. Once FILLED, an FVG becomes TERMINAL (removed from the active hot-
     path registry) even though a "late" decisive inversion is
     theoretically still geometrically possible afterward. This is a
     disclosed pragmatic simplification: IFVG formation in practice
     results from a single decisive impulsive move THROUGH the gap, not
     a slow multi-bar crawl past an already-filled level — so a fill
     event and a potential inversion are evaluated together at the same
     bar (see `_process_fvg_interaction`), and if inversion doesn't
     happen at the fill moment, the FVG is considered to have "done its
     job" and is retired from active monitoring.

OPEN ARCHITECTURAL DECISION (flagged, not unilaterally acted upon):
    This is the THIRD module (after 2.2 and 4.1) implementing the same
    "Dict[Type, List[PersistentObject]] with prune-on-terminal-status"
    registry pattern, plus a THIRD independent `was_monitorable_at()`
    historical-reconstruction method. This is a strong candidate for a
    generic `PersistentLifecycleRegistry[T]` utility class. Not extracted
    here without your explicit approval, per this project's established
    practice of flagging refactors rather than performing them silently.
"""

from __future__ import annotations

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from enum import IntEnum, Enum
from typing import Optional, List, Dict, Tuple

from trading_system.core.causal_kernels import (
    adaptive_ema_kernel,
    causal_percentile_descriptive,
    validate_period_array,
    verify_truncation_invariance,
    CausalPercentileTracker,
    compute_adaptive_period_from_volatility,
    AdaptivePeriodConfig,
)


# ── Exceptions ───────────────────────────────────────────────────────────
class FVGError(Exception):
    """Base exception for this module."""


class FVGConfigError(FVGError):
    """Raised when FVGConfig has invalid/contradictory values."""


class FVGDataError(FVGError):
    """Raised when input dataframe fails sanity/schema/consistency checks."""


# ── Enums ────────────────────────────────────────────────────────────────
class FVGType(Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"


class FVGStatus(IntEnum):
    """Monotonic lifecycle, enforced via max() — same elegant pattern as
    Module 4.1's OBStatus. Note: FILLED and INVERTED are BOTH terminal
    (is_monitorable() checks against both), evaluated together at the
    same bar per design decision #7."""
    ACTIVE = 0
    PARTIAL = 1
    CE_FILLED = 2
    FILLED = 3
    INVERTED = 4


# ── Persistent Objects ───────────────────────────────────────────────────
@dataclass
class FairValueGap:
    fvg_id: int
    fvg_type: FVGType
    fvg_high: float                 # near edge for BULLISH (=low[i]), far edge for BEARISH (=low[i-2])
    fvg_low: float                  # far edge for BULLISH (=high[i-2]), near edge for BEARISH (=high[i])
    fvg_ce: float                   # 50% consequent encroachment level
    origin_bar_index: int           # index i-2 (first candle of the 3-candle pattern)
    confirmed_bar_index: int        # index i (third candle — gap fully known/usable from here)

    status: FVGStatus = FVGStatus.ACTIVE
    quality_score: float = 0.0
    gap_size_evidence: float = 0.0
    displacement_evidence: float = 0.0
    ofi_evidence: float = 0.0
    absorption_evidence: float = 0.0
    ob_confluence_evidence: float = 0.0

    partial_at_index: Optional[int] = None
    ce_filled_at_index: Optional[int] = None
    filled_at_index: Optional[int] = None
    inverted_at_index: Optional[int] = None
    inverted_fvg_id: Optional[int] = None

    def is_monitorable(self) -> bool:
        return self.status not in (FVGStatus.FILLED, FVGStatus.INVERTED)

    def was_monitorable_at(self, bar_index: int) -> bool:
        if self.confirmed_bar_index > bar_index:
            return False
        terminal_index = self.filled_at_index if self.filled_at_index is not None else self.inverted_at_index
        if terminal_index is None:
            return True
        return terminal_index > bar_index


@dataclass
class InvertedFVG:
    inverted_id: int
    original_fvg_id: int
    direction: FVGType              # opposite of the original FVG's type
    confirmed_bar_index: int
    zone_high: float
    zone_low: float
    overshoot_ratio_at_inversion: float


# ── Config ───────────────────────────────────────────────────────────────
@dataclass
class FVGConfig:
    # --- Quality score base weights (structural priors; must sum to 1.0) ---
    # gap_size gets the highest prior weight: FVG significance is
    # theoretically ABOUT displacement magnitude first and foremost.
    base_weight_gap_size: float = 0.30
    base_weight_displacement: float = 0.20
    base_weight_ofi: float = 0.20
    base_weight_absorption: float = 0.15
    base_weight_ob_confluence: float = 0.15

    flow_evidence_regime_sensitivity: float = 0.50
    disagreement_dampening_factor: float = 0.50

    # --- Inversion tracker (reused CausalPercentileTracker pattern,
    #     see design decision #2) ---
    inversion_bootstrap_ratio: float = 0.20
    inversion_min_samples: int = 20
    inversion_threshold_percentile: float = 0.75
    inversion_history_buffer_size: int = 200

    # --- Descriptive percentile windows ---
    gap_percentile_window: int = 100
    min_percentile_samples: int = 10

    # --- Independent adaptive smoothing for fvg_net_bias series ---
    net_bias_period_config: AdaptivePeriodConfig = field(
        default_factory=lambda: AdaptivePeriodConfig(
            min_period=5, max_period=50, vol_of_vol_period=20, period_rank_window=100
        )
    )

    def __post_init__(self) -> None:
        weights = [
            self.base_weight_gap_size, self.base_weight_displacement,
            self.base_weight_ofi, self.base_weight_absorption, self.base_weight_ob_confluence,
        ]
        if any(w < 0 for w in weights):
            raise FVGConfigError("All base weights must be non-negative.")
        if abs(sum(weights) - 1.0) > 1e-6:
            raise FVGConfigError("Base weights must sum to 1.0.")
        if not (0.0 <= self.flow_evidence_regime_sensitivity <= 1.0):
            raise FVGConfigError("flow_evidence_regime_sensitivity must be in [0,1].")
        if not (0.0 <= self.disagreement_dampening_factor <= 1.0):
            raise FVGConfigError("disagreement_dampening_factor must be in [0,1].")
        if not (0.0 < self.inversion_threshold_percentile < 1.0):
            raise FVGConfigError("inversion_threshold_percentile must be in (0,1).")
        if self.inversion_min_samples < 2:
            raise FVGConfigError("inversion_min_samples must be >= 2.")
        if self.inversion_min_samples > self.inversion_history_buffer_size:
            raise FVGConfigError("inversion_min_samples cannot exceed inversion_history_buffer_size.")
        if self.gap_percentile_window < self.min_percentile_samples:
            raise FVGConfigError("gap_percentile_window must be >= min_percentile_samples.")


# ── Main Engine ──────────────────────────────────────────────────────────
class FVGEngine:

    def __init__(self, config: Optional[FVGConfig] = None):
        self.cfg = config or FVGConfig()
        self._all_fvgs: List[FairValueGap] = []
        self._active: Dict[FVGType, List[FairValueGap]] = {FVGType.BULLISH: [], FVGType.BEARISH: []}
        self._inverted: List[InvertedFVG] = []
        self._next_fvg_id = 0
        self._next_inverted_id = 0

        self._inversion_tracker: Dict[FVGType, CausalPercentileTracker] = {
            ft: CausalPercentileTracker(
                self.cfg.inversion_history_buffer_size, self.cfg.inversion_min_samples,
                self.cfg.inversion_bootstrap_ratio,
            )
            for ft in FVGType
        }

    # ── Validation ───────────────────────────────────────────────────
    def _validate_input(self, df: pd.DataFrame, required: List[str], optional_groups: Dict[str, List[str]]) -> Dict[str, bool]:
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise FVGDataError(f"Missing required columns: {missing}")

        availability = {g: all(c in df.columns for c in cols) for g, cols in optional_groups.items()}

        for col in required:
            if df[col].dtype in (float, np.float64) and not np.isfinite(df[col].values).all():
                raise FVGDataError(f"Column '{col}' contains NaN/Inf.")
        if (df["high"] < df["low"]).any():
            raise FVGDataError("'high' < 'low' detected.")
        if (df["atr"] <= 0).any():
            raise FVGDataError("ATR column contains non-positive values.")
        if (df["last_swing_high"] < df["last_swing_low"]).any():
            raise FVGDataError("'last_swing_high' < 'last_swing_low' detected — invalid structural range.")
        if len(df) < 3:
            raise FVGDataError("Need at least 3 bars to detect any FVG.")
        return availability

    # ── FVG detection (O(1) per bar, fixed 3-candle offset) ─────────
    def _detect_and_create(
        self, i: int, high: np.ndarray, low: np.ndarray, open_: np.ndarray, close: np.ndarray,
        volatility_pct: np.ndarray, delta_ratio: Optional[np.ndarray],
        absorption_score: Optional[np.ndarray], absorption_direction: Optional[np.ndarray],
        nearest_bull_ob_dist: Optional[np.ndarray], nearest_bear_ob_dist: Optional[np.ndarray],
        ob_dist_percentile_cache: Dict[str, pd.Series],
        gap_size_pct: pd.Series, atr: np.ndarray,
    ) -> None:
        if i < 2:
            return

        # Bullish FVG: gap between candle (i-2)'s high and candle i's low.
        if low[i] > high[i - 2]:
            self._create_fvg(
                FVGType.BULLISH, i - 2, i, fvg_low=float(high[i - 2]), fvg_high=float(low[i]),
                high=high, low=low, open_=open_, close=close, volatility_pct=volatility_pct,
                delta_ratio=delta_ratio, absorption_score=absorption_score,
                absorption_direction=absorption_direction,
                ob_dist=nearest_bull_ob_dist, ob_dist_pct_series=ob_dist_percentile_cache.get("bull"),
                gap_size_pct=gap_size_pct, atr=atr,
            )

        # Bearish FVG: gap between candle i's high and candle (i-2)'s low.
        if high[i] < low[i - 2]:
            self._create_fvg(
                FVGType.BEARISH, i - 2, i, fvg_low=float(high[i]), fvg_high=float(low[i - 2]),
                high=high, low=low, open_=open_, close=close, volatility_pct=volatility_pct,
                delta_ratio=delta_ratio, absorption_score=absorption_score,
                absorption_direction=absorption_direction,
                ob_dist=nearest_bear_ob_dist, ob_dist_pct_series=ob_dist_percentile_cache.get("bear"),
                gap_size_pct=gap_size_pct, atr=atr,
            )

    def _create_fvg(
        self, fvg_type: FVGType, origin_idx: int, confirm_idx: int, fvg_low: float, fvg_high: float,
        high: np.ndarray, low: np.ndarray, open_: np.ndarray, close: np.ndarray,
        volatility_pct: np.ndarray, delta_ratio: Optional[np.ndarray],
        absorption_score: Optional[np.ndarray], absorption_direction: Optional[np.ndarray],
        ob_dist: Optional[np.ndarray], ob_dist_pct_series: Optional[pd.Series],
        gap_size_pct: pd.Series, atr: np.ndarray,
    ) -> None:
        fvg_ce = (fvg_high + fvg_low) / 2.0
        middle_idx = origin_idx + 1  # the displacement candle (i-1)

        gap_ev = float(gap_size_pct.iloc[confirm_idx])

        middle_range = max(high[middle_idx] - low[middle_idx], 1e-9)
        displacement_ev = float(np.clip(abs(close[middle_idx] - open_[middle_idx]) / middle_range, 0.0, 1.0))

        if delta_ratio is not None:
            dr = delta_ratio[middle_idx]
            ofi_ev = float(np.clip(dr, 0.0, 1.0)) if fvg_type == FVGType.BULLISH else float(np.clip(-dr, 0.0, 1.0))
        else:
            ofi_ev = 0.5

        if absorption_score is not None and absorption_direction is not None:
            expected_dir = "BULLISH" if fvg_type == FVGType.BULLISH else "BEARISH"
            raw_abs = float(np.abs(absorption_score[middle_idx]))
            absorb_ev = raw_abs if absorption_direction[middle_idx] == expected_dir \
                else raw_abs * self.cfg.disagreement_dampening_factor
        else:
            absorb_ev = 0.5

        # OB confluence: percentile rank of distance (closer -> lower
        # percentile -> higher confluence score = 1 - percentile).
        if ob_dist is not None and ob_dist_pct_series is not None and not np.isnan(ob_dist[confirm_idx]):
            dist_pct = float(ob_dist_pct_series.iloc[confirm_idx])
            ob_confluence_ev = 1.0 - dist_pct
        else:
            ob_confluence_ev = 0.5  # no evidence either way, neutral prior

        vp = float(volatility_pct[confirm_idx])
        flow_damp = 1.0 - self.cfg.flow_evidence_regime_sensitivity * vp
        w_gap = self.cfg.base_weight_gap_size
        w_disp = self.cfg.base_weight_displacement
        w_ofi = self.cfg.base_weight_ofi * flow_damp
        w_absorb = self.cfg.base_weight_absorption * flow_damp
        w_ob = self.cfg.base_weight_ob_confluence

        total_w = max(w_gap + w_disp + w_ofi + w_absorb + w_ob, 1e-9)
        w_gap, w_disp, w_ofi, w_absorb, w_ob = (
            w_gap / total_w, w_disp / total_w, w_ofi / total_w, w_absorb / total_w, w_ob / total_w
        )

        quality = (
            w_gap * gap_ev + w_disp * displacement_ev + w_ofi * ofi_ev
            + w_absorb * absorb_ev + w_ob * ob_confluence_ev
        )
        quality = float(np.clip(quality, 0.0, 1.0))

        fvg = FairValueGap(
            fvg_id=self._next_fvg_id, fvg_type=fvg_type, fvg_high=fvg_high, fvg_low=fvg_low,
            fvg_ce=fvg_ce, origin_bar_index=origin_idx, confirmed_bar_index=confirm_idx,
            quality_score=quality, gap_size_evidence=gap_ev, displacement_evidence=displacement_ev,
            ofi_evidence=ofi_ev, absorption_evidence=absorb_ev, ob_confluence_evidence=ob_confluence_ev,
        )
        self._next_fvg_id += 1
        self._all_fvgs.append(fvg)
        self._active[fvg_type].append(fvg)

    # ── Lifecycle interaction (mirrors Module 2.2's touch/overshoot
    #    structure — see design decision #2 for why this parallel exists) ──
    def _process_fvg_interaction(
        self, fvg: FairValueGap, bar_index: int, bar_high: float, bar_low: float, bar_close: float,
        current_atr: float,
    ) -> None:
        touched = not (bar_low > fvg.fvg_high or bar_high < fvg.fvg_low)
        if not touched:
            return

        if fvg.partial_at_index is None:
            fvg.partial_at_index = bar_index
        new_status = FVGStatus.PARTIAL

        ce_reached = (bar_low <= fvg.fvg_ce) if fvg.fvg_type == FVGType.BULLISH else (bar_high >= fvg.fvg_ce)
        if ce_reached:
            new_status = FVGStatus.CE_FILLED
            if fvg.ce_filled_at_index is None:
                fvg.ce_filled_at_index = bar_index

        far_edge_reached = (bar_low <= fvg.fvg_low) if fvg.fvg_type == FVGType.BULLISH else (bar_high >= fvg.fvg_high)
        if far_edge_reached:
            new_status = FVGStatus.FILLED
            if fvg.filled_at_index is None:
                fvg.filled_at_index = bar_index

            # Evaluate decisive inversion AT THE SAME BAR as the fill
            # (design decision #7 — inversion and fill are checked jointly).
            overshoot = (fvg.fvg_low - bar_close) if fvg.fvg_type == FVGType.BULLISH else (bar_close - fvg.fvg_high)
            overshoot_ratio = max(overshoot, 0.0) / current_atr

            tracker = self._inversion_tracker[fvg.fvg_type]
            threshold = tracker.percentile_value(self.cfg.inversion_threshold_percentile)
            is_decisive = overshoot_ratio > threshold
            tracker.push(overshoot_ratio)  # causal: push AFTER read

            if is_decisive:
                new_status = FVGStatus.INVERTED
                fvg.inverted_at_index = bar_index
                inv_direction = FVGType.BEARISH if fvg.fvg_type == FVGType.BULLISH else FVGType.BULLISH
                inv = InvertedFVG(
                    inverted_id=self._next_inverted_id, original_fvg_id=fvg.fvg_id,
                    direction=inv_direction, confirmed_bar_index=bar_index,
                    zone_high=fvg.fvg_high, zone_low=fvg.fvg_low,
                    overshoot_ratio_at_inversion=overshoot_ratio,
                )
                self._inverted.append(inv)
                fvg.inverted_fvg_id = inv.inverted_id
                self._next_inverted_id += 1

        fvg.status = FVGStatus(max(int(fvg.status), int(new_status)))

    # ── Premium/Discount (vectorized, stateless — no loop needed) ───
    def _compute_premium_discount(
        self, close: np.ndarray, last_swing_high: np.ndarray, last_swing_low: np.ndarray, index: pd.Index
    ) -> pd.DataFrame:
        rng = last_swing_high - last_swing_low
        safe_rng = np.where(rng > 1e-9, rng, np.nan)
        position_in_range = np.clip((close - last_swing_low) / safe_rng, 0.0, 1.0)
        position_in_range = np.where(np.isnan(position_in_range), 0.5, position_in_range)  # degenerate range -> neutral

        premium_score = position_in_range
        discount_score = 1.0 - position_in_range

        discount_pct_context = causal_percentile_descriptive(
            pd.Series(discount_score, index=index), self.cfg.gap_percentile_window, self.cfg.min_percentile_samples
        )

        return pd.DataFrame({
            "position_in_range": position_in_range,
            "premium_score": premium_score,
            "discount_score": discount_score,
            "discount_percentile_context": discount_pct_context,
        }, index=index)

    # ── Public API ────────────────────────────────────────────────────
    def analyze(
        self,
        df: pd.DataFrame,
        open_col: str = "open", high_col: str = "high", low_col: str = "low", close_col: str = "close",
        atr_col: str = "atr", volatility_percentile_col: str = "volatility_percentile",
        adaptive_period_col: str = "adaptive_period",
        last_swing_high_col: str = "last_swing_high", last_swing_low_col: str = "last_swing_low",
        delta_ratio_col: Optional[str] = "delta_ratio",
        absorption_score_col: Optional[str] = "absorption_score",
        absorption_direction_col: Optional[str] = "absorption_direction_raw",
        nearest_bullish_ob_dist_col: Optional[str] = "nearest_bullish_ob_dist_atr",
        nearest_bearish_ob_dist_col: Optional[str] = "nearest_bearish_ob_dist_atr",
    ) -> Tuple[pd.DataFrame, List[FairValueGap], List[InvertedFVG]]:

        required = [
            open_col, high_col, low_col, close_col, atr_col, volatility_percentile_col,
            adaptive_period_col, last_swing_high_col, last_swing_low_col,
        ]
        optional_groups = {
            "order_flow": [delta_ratio_col] if delta_ratio_col else [],
            "absorption": [absorption_score_col, absorption_direction_col]
                if absorption_score_col and absorption_direction_col else [],
            "ob_confluence": [c for c in (nearest_bullish_ob_dist_col, nearest_bearish_ob_dist_col) if c],
        }
        availability = self._validate_input(df, required, optional_groups)

        n = len(df)
        open_ = df[open_col].values.astype(float)
        high = df[high_col].values.astype(float)
        low = df[low_col].values.astype(float)
        close = df[close_col].values.astype(float)
        atr = df[atr_col].values.astype(float)
        volatility_pct = df[volatility_percentile_col].values.astype(float)
        last_swing_high = df[last_swing_high_col].values.astype(float)
        last_swing_low = df[last_swing_low_col].values.astype(float)

        delta_ratio = df[delta_ratio_col].values.astype(float) if availability["order_flow"] else None
        absorption_score = df[absorption_score_col].values.astype(float) if availability["absorption"] else None
        absorption_direction = df[absorption_direction_col].values if availability["absorption"] else None

        nearest_bull_ob_dist = (
            df[nearest_bullish_ob_dist_col].values.astype(float)
            if nearest_bullish_ob_dist_col and nearest_bullish_ob_dist_col in df.columns else None
        )
        nearest_bear_ob_dist = (
            df[nearest_bearish_ob_dist_col].values.astype(float)
            if nearest_bearish_ob_dist_col and nearest_bearish_ob_dist_col in df.columns else None
        )
        ob_dist_pct_cache = {}
        if nearest_bull_ob_dist is not None:
            ob_dist_pct_cache["bull"] = causal_percentile_descriptive(
                pd.Series(nearest_bull_ob_dist, index=df.index),
                self.cfg.gap_percentile_window, self.cfg.min_percentile_samples,
            )
        if nearest_bear_ob_dist is not None:
            ob_dist_pct_cache["bear"] = causal_percentile_descriptive(
                pd.Series(nearest_bear_ob_dist, index=df.index),
                self.cfg.gap_percentile_window, self.cfg.min_percentile_samples,
            )

        # Pre-compute ATR-normalized gap-size percentile vectorized
        # (needs a 2-bar-forward-looking geometric fact per bar i, i.e.
        # gap between i-2 and i — still fully causal since this is
        # evaluated AT bar i using i-2's already-closed high/low).
        raw_gap_size = np.zeros(n)
        raw_gap_size[2:] = np.maximum(
            low[2:] - high[:-2], low[:-2] - high[2:]
        )
        raw_gap_size = np.maximum(raw_gap_size, 0.0) / np.maximum(atr, 1e-9)
        gap_size_pct = causal_percentile_descriptive(
            pd.Series(raw_gap_size, index=df.index), self.cfg.gap_percentile_window, self.cfg.min_percentile_samples
        )

        active_bull_count = np.zeros(n, dtype=int)
        active_bear_count = np.zeros(n, dtype=int)
        max_bull_quality = np.zeros(n)
        max_bear_quality = np.zeros(n)
        any_fvg_filled = np.zeros(n, dtype=bool)
        any_fvg_inverted = np.zeros(n, dtype=bool)
        fvg_net_bias_raw = np.zeros(n)

        for i in range(n):
            self._detect_and_create(
                i, high, low, open_, close, volatility_pct, delta_ratio,
                absorption_score, absorption_direction, nearest_bull_ob_dist, nearest_bear_ob_dist,
                ob_dist_pct_cache, gap_size_pct, atr,
            )

            for fvg_type in FVGType:
                still_active = []
                for fvg in self._active[fvg_type]:
                    self._process_fvg_interaction(fvg, i, high[i], low[i], close[i], atr[i])
                    if fvg.filled_at_index == i and fvg.status == FVGStatus.FILLED:
                        any_fvg_filled[i] = True
                    if fvg.inverted_at_index == i:
                        any_fvg_inverted[i] = True
                    if fvg.is_monitorable():
                        still_active.append(fvg)
                self._active[fvg_type] = still_active

            bulls = self._active[FVGType.BULLISH]
            bears = self._active[FVGType.BEARISH]
            active_bull_count[i] = len(bulls)
            active_bear_count[i] = len(bears)
            if bulls:
                max_bull_quality[i] = max(f.quality_score for f in bulls)
            if bears:
                max_bear_quality[i] = max(f.quality_score for f in bears)

            bull_bias = sum(f.quality_score for f in bulls)
            bear_bias = sum(f.quality_score for f in bears)
            fvg_net_bias_raw[i] = bull_bias - bear_bias

        net_bias_series = pd.Series(fvg_net_bias_raw, index=df.index)
        net_bias_period = compute_adaptive_period_from_volatility(net_bias_series, self.cfg.net_bias_period_config)
        net_bias_period_arr = net_bias_period.values.astype(np.int64)
        fvg_net_bias_smoothed = adaptive_ema_kernel(fvg_net_bias_raw, net_bias_period_arr, seed=0.0)

        pd_df = self._compute_premium_discount(close, last_swing_high, last_swing_low, df.index)

        out = df.copy()
        out["active_bullish_fvg_count"] = active_bull_count
        out["active_bearish_fvg_count"] = active_bear_count
        out["max_bullish_fvg_quality"] = max_bull_quality
        out["max_bearish_fvg_quality"] = max_bear_quality
        out["any_fvg_filled"] = any_fvg_filled
        out["any_fvg_inverted"] = any_fvg_inverted
        out["fvg_net_bias_raw"] = fvg_net_bias_raw
        out["fvg_net_bias_smoothed"] = fvg_net_bias_smoothed
        out["fvg_quality_percentile_context"] = causal_percentile_descriptive(
            pd.Series(np.maximum(max_bull_quality, max_bear_quality), index=df.index),
            self.cfg.gap_percentile_window, self.cfg.min_percentile_samples,
        )
        out = pd.concat([out, pd_df], axis=1)

        return out, self._all_fvgs, self._inverted

    def get_active_fvgs_at(self, bar_index: int, fvg_type: Optional[FVGType] = None) -> List[FairValueGap]:
        pool = self._all_fvgs if fvg_type is None else [f for f in self._all_fvgs if f.fvg_type == fvg_type]
        return [f for f in pool if f.was_monitorable_at(bar_index)]

    def fvg_registry_to_dataframe(self) -> pd.DataFrame:
        rows = []
        for f in self._all_fvgs:
            rows.append({
                "fvg_id": f.fvg_id, "type": f.fvg_type.value, "fvg_high": f.fvg_high, "fvg_low": f.fvg_low,
                "fvg_ce": f.fvg_ce, "origin_bar": f.origin_bar_index, "confirmed_bar": f.confirmed_bar_index,
                "status": f.status.name, "quality_score": f.quality_score,
                "gap_size_evidence": f.gap_size_evidence, "displacement_evidence": f.displacement_evidence,
                "ofi_evidence": f.ofi_evidence, "absorption_evidence": f.absorption_evidence,
                "ob_confluence_evidence": f.ob_confluence_evidence,
                "filled_at": f.filled_at_index, "inverted_at": f.inverted_at_index,
                "inverted_fvg_id": f.inverted_fvg_id,
            })
        return pd.DataFrame(rows)

    def inverted_registry_to_dataframe(self) -> pd.DataFrame:
        rows = []
        for inv in self._inverted:
            rows.append({
                "inverted_id": inv.inverted_id, "original_fvg_id": inv.original_fvg_id,
                "direction": inv.direction.value, "confirmed_bar": inv.confirmed_bar_index,
                "zone_high": inv.zone_high, "zone_low": inv.zone_low,
                "overshoot_ratio": inv.overshoot_ratio_at_inversion,
            })
        return pd.DataFrame(rows)


# ── Smoke Test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    np.random.seed(5)
    N = 500

    # Inject deliberate displacement moves to guarantee FVG formation.
    base = 30_000 + np.cumsum(np.random.randn(N) * 15)
    for k in range(50, N, 40):
        base[k:k + 3] += np.linspace(0, 200, 3)  # bullish displacement burst
    open_ = base.copy()
    close = open_ + np.random.randn(N) * 8
    high = np.maximum(open_, close) + np.abs(np.random.randn(N) * 5) + 1e-6
    low = np.minimum(open_, close) - np.abs(np.random.randn(N) * 5) - 1e-6
    atr = pd.Series(high - low).rolling(14, min_periods=1).mean().values
    volatility_pct = pd.Series(atr).rank(pct=True).fillna(0.5).values
    adaptive_period = np.full(N, 14)

    last_swing_high = pd.Series(high).rolling(30, min_periods=1).max().values
    last_swing_low = pd.Series(low).rolling(30, min_periods=1).min().values

    buy_vol = np.abs(np.random.randn(N) * 100 + 300)
    sell_vol = np.abs(np.random.randn(N) * 100 + 300)
    delta_ratio = np.divide(buy_vol - sell_vol, buy_vol + sell_vol)

    absorption_score = np.random.uniform(-1, 1, N)
    absorption_direction = np.where(absorption_score > 0, "BULLISH",
                                     np.where(absorption_score < 0, "BEARISH", "NEUTRAL"))
    nearest_bull_ob_dist = np.abs(np.random.randn(N)) * 0.5
    nearest_bear_ob_dist = np.abs(np.random.randn(N)) * 0.5

    df = pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close, "atr": atr,
        "volatility_percentile": volatility_pct, "adaptive_period": adaptive_period,
        "last_swing_high": last_swing_high, "last_swing_low": last_swing_low,
        "delta_ratio": delta_ratio,
        "absorption_score": absorption_score, "absorption_direction_raw": absorption_direction,
        "nearest_bullish_ob_dist_atr": nearest_bull_ob_dist, "nearest_bearish_ob_dist_atr": nearest_bear_ob_dist,
    })

    engine = FVGEngine()
    out, fvgs, inversions = engine.analyze(df)

    print(out[["active_bullish_fvg_count", "active_bearish_fvg_count",
               "discount_score", "premium_score", "fvg_net_bias_smoothed"]].tail(15).to_string())
    print(f"\nTotal FVGs detected: {len(fvgs)}")
    print(f"Total Inversions: {len(inversions)}")
    print("\nFVG status distribution:")
    print(engine.fvg_registry_to_dataframe()["status"].value_counts() if fvgs else "None detected")

    print("\n--- Causal Correctness Assertions ---")
    for f in fvgs:
        assert f.confirmed_bar_index == f.origin_bar_index + 2, "FVG must span exactly 3 bars"
        pre = engine.get_active_fvgs_at(f.confirmed_bar_index - 1)
        assert f.fvg_id not in [x.fvg_id for x in pre], "LOOK-AHEAD: FVG visible before confirmation!"
    print(f"✅ Verified {len(fvgs)} FVGs: correct 3-bar span, no premature visibility.")

    print("\n--- Structural Duplicate-Impossibility Check ---")
    origins = [(f.fvg_type, f.origin_bar_index) for f in fvgs]
    assert len(origins) == len(set(origins)), "Unexpected duplicate FVG — design invariant violated!"
    print("✅ No duplicate FVGs at same origin (structurally guaranteed, verified empirically).")

    print("\n--- Truncation Invariance Test ---")
    verify_truncation_invariance(FVGEngine, df, split_at=200)

    print("\n--- Validation Tests ---")
    bad = df.copy()
    bad.loc[5, "last_swing_high"] = bad.loc[5, "last_swing_low"] - 1
    try:
        FVGEngine().analyze(bad)
        print("❌ FAILED to catch inverted swing range")
    except FVGDataError as e:
        print(f"✅ Caught: {e}")

    print("\n⚠️  OPEN ITEMS for your judgment:")
    print("  1. Generic PersistentLifecycleRegistry[T] extraction — now a 3x pattern")
    print("     (Modules 2.2, 4.1, 4.2). Flagged, not unilaterally refactored.")
    print("  2. Module 4.1's temporary discount_premium_evidence proxy could now be")
    print("     superseded by this module's more rigorous premium/discount score in")
    print("     a future integration pass — not done automatically here.")
