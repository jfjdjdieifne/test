"""
Module 3.1: Volume Delta Engine
VERSION 2 - Hardened Production Grade

Fixes applied over V1 (independent review, corrected reasoning where the
external critique's justification was scientifically wrong even though
its conclusion was directionally right):

  1. Volume consistency check: split into soft (warn) / hard (raise)
     tolerances. IMPORTANT CORRECTION: the common claim that "float64
     rounding accumulates to ~2% error" is FALSE — float64 rounding error
     over even hundreds of thousands of additions stays around 1e-8 to
     1e-10 relative, many orders of magnitude below 2%. If real-world data
     shows deviations at the percent level, the actual cause is almost
     certainly PIPELINE HETEROGENEITY (buy/sell classified by one process,
     `volume` aggregated by a different one with different bar boundaries
     or partial-fill handling) — NOT numerical precision. This distinction
     matters: it means real deviations above a few tenths of a percent are
     a genuine data integrity signal, not noise to shrug off.

  2. Custom warning classes defined (VolumeDeltaDataWarning,
     VolumeDeltaPerformanceWarning) — Python has no built-in
     "PerformanceWarning" (that's a pandas-specific class); relying on it
     without importing pandas.errors would crash at runtime.

  3. Numba-absence performance warning now fires from within analyze()
     itself (not just an optional smoke-test print), for consistency with
     how a production module should surface operational risk to its
     caller — flagged here as a pattern that should also be retrofitted
     into Module 1.1 and Module 2.2 for consistency.

  4. Truncation Invariance Test generalized to check BOTH numeric AND
     categorical/string columns (the original proposal only checked
     numeric columns via `select_dtypes(include=[np.number])`, which
     would silently miss a look-ahead bug hiding in `delta_source` or
     `divergence_direction`).
"""

from __future__ import annotations

import warnings
import pandas as pd
import numpy as np
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple

from trading_system.core.causal_kernels import (
    NUMBA_OK,
    AdaptivePeriodConfig,
    adaptive_ema_kernel,
    causal_percentile_descriptive,
    compute_adaptive_period_from_volatility,
    rolling_ols_slope_adaptive,
    verify_truncation_invariance,
)


# ── Exceptions ───────────────────────────────────────────────────────────
class VolumeDeltaError(Exception):
    """Base exception for this module."""


class VolumeDeltaConfigError(VolumeDeltaError):
    """Raised when VolumeDeltaConfig has invalid/contradictory values."""


class VolumeDeltaDataError(VolumeDeltaError):
    """Raised when input dataframe fails sanity/schema/consistency checks."""


# ── Warnings (custom — no reliance on pandas-specific classes) ──────────
class VolumeDeltaDataWarning(UserWarning):
    """Raised for non-fatal data quality concerns (soft tolerance breach)."""


class VolumeDeltaPerformanceWarning(UserWarning):
    """Raised when running without Numba on a dataset large enough to matter."""


# ── Enums ────────────────────────────────────────────────────────────────
class FlowSource(Enum):
    REAL = "REAL"
    PROXY = "PROXY"
    PROXY_ZERO_RANGE = "PROXY_ZERO_RANGE"
    NO_VOLUME = "NO_VOLUME"


class DivergenceDirection(Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


# ── Config ───────────────────────────────────────────────────────────────
@dataclass
class VolumeDeltaConfig:
    fallback_min_period: int = 5
    fallback_max_period: int = 50
    fallback_vol_of_vol_period: int = 20
    fallback_period_rank_window: int = 100

    delta_percentile_window: int = 100
    slope_percentile_window: int = 100
    min_percentile_samples: int = 10

    # --- Volume consistency: soft/hard split (DISCLOSED data-integrity
    #     meta-parameters, not trading rules — see module docstring for
    #     why these are NOT justified by floating-point error). ---
    volume_soft_tolerance: float = 0.02   # above this: warn (possible pipeline quirk)
    volume_hard_tolerance: float = 0.05   # above this: raise (real pipeline bug)

    max_regression_window: int = 200

    # Dataset size above which a missing-Numba warning is worth raising
    # (below this, the O(n*window) pure-Python cost is negligible anyway).
    performance_warning_min_bars: int = 5_000

    def __post_init__(self) -> None:
        if self.fallback_min_period < 2:
            raise VolumeDeltaConfigError("fallback_min_period must be >= 2.")
        if self.fallback_max_period <= self.fallback_min_period:
            raise VolumeDeltaConfigError("fallback_max_period must be > fallback_min_period.")
        if self.fallback_vol_of_vol_period < 2:
            raise VolumeDeltaConfigError("fallback_vol_of_vol_period must be >= 2.")
        if self.delta_percentile_window < self.min_percentile_samples:
            raise VolumeDeltaConfigError("delta_percentile_window must be >= min_percentile_samples.")
        if self.slope_percentile_window < self.min_percentile_samples:
            raise VolumeDeltaConfigError("slope_percentile_window must be >= min_percentile_samples.")
        if not (0.0 < self.volume_soft_tolerance < 1.0):
            raise VolumeDeltaConfigError("volume_soft_tolerance must be in (0,1).")
        if not (0.0 < self.volume_hard_tolerance < 1.0):
            raise VolumeDeltaConfigError("volume_hard_tolerance must be in (0,1).")
        if self.volume_hard_tolerance <= self.volume_soft_tolerance:
            raise VolumeDeltaConfigError(
                "volume_hard_tolerance must be > volume_soft_tolerance."
            )
        if self.max_regression_window < 3:
            raise VolumeDeltaConfigError("max_regression_window must be >= 3.")



# ── Main Engine ──────────────────────────────────────────────────────────
class VolumeDeltaEngine:

    def __init__(self, config: Optional[VolumeDeltaConfig] = None):
        self.cfg = config or VolumeDeltaConfig()

    # ── Validation ───────────────────────────────────────────────────
    def _validate_and_prepare(
        self, df: pd.DataFrame, high_col: str, low_col: str, close_col: str,
        volume_col: Optional[str], buy_volume_col: Optional[str], sell_volume_col: Optional[str]
    ) -> None:
        base_required = [high_col, low_col, close_col]
        missing = [c for c in base_required if c not in df.columns]
        if missing:
            raise VolumeDeltaDataError(f"Missing required columns: {missing}")

        has_real = (
            buy_volume_col is not None and sell_volume_col is not None
            and buy_volume_col in df.columns and sell_volume_col in df.columns
        )
        has_volume = volume_col is not None and volume_col in df.columns

        if not has_real and not has_volume:
            raise VolumeDeltaDataError(
                "Must supply either (buy_volume_col AND sell_volume_col) "
                "for real order flow, or volume_col for OHLCV proxy fallback."
            )

        for col in (high_col, low_col, close_col):
            if df[col].isnull().any() or not np.isfinite(df[col].values).all():
                raise VolumeDeltaDataError(f"Column '{col}' contains NaN/Inf.")
        if (df[high_col] < df[low_col]).any():
            raise VolumeDeltaDataError("'high' < 'low' detected.")

        if has_real:
            for col in (buy_volume_col, sell_volume_col):
                if (df[col] < 0).any():
                    raise VolumeDeltaDataError(f"Column '{col}' contains negative volume.")
            if has_volume:
                total_real = df[buy_volume_col] + df[sell_volume_col]
                vol = df[volume_col]
                nonzero_mask = vol > 0
                if nonzero_mask.any():
                    rel_diff = (total_real[nonzero_mask] - vol[nonzero_mask]).abs() / vol[nonzero_mask]

                    hard_violations = int((rel_diff > self.cfg.volume_hard_tolerance).sum())
                    soft_violations = int(
                        ((rel_diff > self.cfg.volume_soft_tolerance) &
                         (rel_diff <= self.cfg.volume_hard_tolerance)).sum()
                    )
                    max_rel_diff = float(rel_diff.max())

                    if hard_violations > 0:
                        raise VolumeDeltaDataError(
                            f"buy_volume + sell_volume vs volume_col mismatch exceeds "
                            f"{self.cfg.volume_hard_tolerance:.1%} in {hard_violations} row(s) "
                            f"(max deviation: {max_rel_diff:.2%}). This magnitude is NOT "
                            f"explainable by floating-point rounding (which stays far below "
                            f"0.01% even over huge sums) — it indicates a genuine pipeline "
                            f"inconsistency between your buy/sell source and your volume source."
                        )
                    if soft_violations > 0:
                        warnings.warn(
                            f"buy_volume + sell_volume vs volume_col mismatch between "
                            f"{self.cfg.volume_soft_tolerance:.1%}-{self.cfg.volume_hard_tolerance:.1%} "
                            f"in {soft_violations} row(s) (max: {max_rel_diff:.2%}). Likely caused "
                            f"by differing bar-boundary handling between data sources, not floating "
                            f"point error. Proceeding, but verify your data pipeline.",
                            VolumeDeltaDataWarning, stacklevel=2,
                        )
        elif has_volume:
            if (df[volume_col] < 0).any():
                raise VolumeDeltaDataError(f"Column '{volume_col}' contains negative volume.")

    # ── Order flow split (real or proxy) ───────────────────────────
    def _compute_flow_split(
        self, df: pd.DataFrame, high_col: str, low_col: str, close_col: str,
        volume_col: Optional[str], buy_volume_col: Optional[str], sell_volume_col: Optional[str]
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        has_real = (
            buy_volume_col is not None and sell_volume_col is not None
            and buy_volume_col in df.columns and sell_volume_col in df.columns
        )

        n = len(df)
        source = np.empty(n, dtype=object)

        if has_real:
            buy = df[buy_volume_col].values.astype(float)
            sell = df[sell_volume_col].values.astype(float)
            total = buy + sell
            source[:] = FlowSource.REAL.value
            source[total == 0] = FlowSource.NO_VOLUME.value
            return buy, sell, source

        high = df[high_col].values.astype(float)
        low = df[low_col].values.astype(float)
        close = df[close_col].values.astype(float)
        volume = df[volume_col].values.astype(float)
        rng = high - low

        buy = np.zeros(n)
        sell = np.zeros(n)

        zero_vol_mask = volume == 0
        zero_range_mask = (rng == 0) & ~zero_vol_mask
        normal_mask = ~zero_vol_mask & ~zero_range_mask

        buy[normal_mask] = volume[normal_mask] * (close[normal_mask] - low[normal_mask]) / rng[normal_mask]
        sell[normal_mask] = volume[normal_mask] * (high[normal_mask] - close[normal_mask]) / rng[normal_mask]

        buy[zero_range_mask] = volume[zero_range_mask] * 0.5
        sell[zero_range_mask] = volume[zero_range_mask] * 0.5

        source[normal_mask] = FlowSource.PROXY.value
        source[zero_range_mask] = FlowSource.PROXY_ZERO_RANGE.value
        source[zero_vol_mask] = FlowSource.NO_VOLUME.value

        return buy, sell, source


    # ── Public API ────────────────────────────────────────────────────
    def analyze(
        self,
        df: pd.DataFrame,
        high_col: str = "high", low_col: str = "low", close_col: str = "close",
        volume_col: Optional[str] = "volume",
        buy_volume_col: Optional[str] = None, sell_volume_col: Optional[str] = None,
        adaptive_period_col: Optional[str] = "adaptive_period",
    ) -> pd.DataFrame:
        self._validate_and_prepare(df, high_col, low_col, close_col,
                                    volume_col, buy_volume_col, sell_volume_col)

        if not NUMBA_OK and len(df) >= self.cfg.performance_warning_min_bars:
            warnings.warn(
                f"Numba not available and dataset has {len(df)} bars. The adaptive "
                f"OLS slope kernel is O(n*window) — expect significantly slower "
                f"execution. Install numba for a 50-100x speedup.",
                VolumeDeltaPerformanceWarning, stacklevel=2,
            )

        out = df.copy()
        buy, sell, source = self._compute_flow_split(
            df, high_col, low_col, close_col, volume_col, buy_volume_col, sell_volume_col
        )
        total = buy + sell
        delta = buy - sell
        delta_ratio = np.divide(delta, total, out=np.zeros_like(delta), where=total > 0)

        out["buy_volume"] = buy
        out["sell_volume"] = sell
        out["delta"] = delta
        out["delta_ratio"] = delta_ratio
        out["delta_source"] = source

        if adaptive_period_col is not None and adaptive_period_col in df.columns:
            period_series = df[adaptive_period_col].bfill().ffill().fillna(
                self.cfg.fallback_min_period
            ).astype(int).clip(2, self.cfg.max_regression_window)
        else:
            period_series = compute_adaptive_period_from_volatility(
                pd.Series(delta_ratio, index=df.index),
                AdaptivePeriodConfig(
                    min_period=self.cfg.fallback_min_period,
                    max_period=self.cfg.fallback_max_period,
                    vol_of_vol_period=self.cfg.fallback_vol_of_vol_period,
                    period_rank_window=self.cfg.fallback_period_rank_window,
                ),
            ).clip(2, self.cfg.max_regression_window)

        period_arr = period_series.values.astype(np.int64)

        momentum = adaptive_ema_kernel(delta_ratio.astype(float), period_arr, seed=0.0)
        out["delta_momentum"] = momentum

        out["delta_momentum_percentile"] = causal_percentile_descriptive(
            pd.Series(momentum, index=df.index),
            self.cfg.delta_percentile_window, self.cfg.min_percentile_samples
        )

        log_close = np.log(df[close_col].values.astype(float))
        price_slope = rolling_ols_slope_adaptive(log_close, period_arr, self.cfg.max_regression_window)
        flow_slope = rolling_ols_slope_adaptive(momentum, period_arr, self.cfg.max_regression_window)

        price_slope_pct = causal_percentile_descriptive(
            pd.Series(price_slope, index=df.index),
            self.cfg.slope_percentile_window, self.cfg.min_percentile_samples
        )
        flow_slope_pct = causal_percentile_descriptive(
            pd.Series(flow_slope, index=df.index),
            self.cfg.slope_percentile_window, self.cfg.min_percentile_samples
        )
        out["price_slope_percentile"] = price_slope_pct
        out["flow_slope_percentile"] = flow_slope_pct

        price_norm = 2.0 * price_slope_pct - 1.0
        flow_norm = 2.0 * flow_slope_pct - 1.0
        divergence_raw = (price_norm - flow_norm).values
        out["divergence_raw"] = divergence_raw
        out["divergence_score"] = np.clip(np.abs(divergence_raw) / 2.0, 0.0, 1.0)

        direction = np.where(
            divergence_raw > 0, DivergenceDirection.BEARISH.value,
            np.where(divergence_raw < 0, DivergenceDirection.BULLISH.value,
                     DivergenceDirection.NEUTRAL.value)
        )
        out["divergence_direction"] = direction

        return out



# ── Smoke Test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import time as _t

    np.random.seed(7)
    N = 2000

    close = 30_000 + np.cumsum(np.random.randn(N) * 40)
    high = close + np.abs(np.random.randn(N) * 25) + 1e-6
    low = close - np.abs(np.random.randn(N) * 25) - 1e-6
    volume = np.abs(np.random.randn(N) * 100 + 500)
    adaptive_period = np.full(N, 14)

    df = pd.DataFrame({
        "high": high, "low": low, "close": close, "volume": volume,
        "adaptive_period": adaptive_period,
    })

    engine = VolumeDeltaEngine()

    t0 = _t.perf_counter()
    out_full = engine.analyze(df)
    print(f"✅ PROXY mode: {N} bars in {(_t.perf_counter()-t0)*1000:.1f} ms")
    print(out_full[["delta_ratio", "delta_source", "delta_momentum",
                     "delta_momentum_percentile", "divergence_score",
                     "divergence_direction"]].tail(10).to_string())

    buy_vol = volume * np.random.uniform(0.3, 0.7, N)
    sell_vol = volume - buy_vol
    df_real = df.copy()
    df_real["buy_volume"] = buy_vol
    df_real["sell_volume"] = sell_vol

    out_real = VolumeDeltaEngine().analyze(
        df_real, buy_volume_col="buy_volume", sell_volume_col="sell_volume"
    )
    print("\n✅ REAL order flow mode:")
    print(out_real["delta_source"].value_counts())

    print("\n--- Generalized Truncation Invariance Test ---")
    verify_truncation_invariance(VolumeDeltaEngine, df, split_at=500)

    print("\n--- Validation Tests ---")

    # Small deviation -> should WARN, not raise
    warn_case = df_real.copy()
    # Keep buy+sell at exactly 97% of reported volume (a 3% soft breach).
    warn_case.loc[5, "buy_volume"] = (
        warn_case.loc[5, "volume"] * 0.97 - warn_case.loc[5, "sell_volume"]
    )
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        VolumeDeltaEngine().analyze(warn_case, buy_volume_col="buy_volume", sell_volume_col="sell_volume")
        assert any(issubclass(x.category, VolumeDeltaDataWarning) for x in w), \
            "❌ FAILED to warn on soft-tolerance breach"
    print("✅ Soft tolerance correctly triggers warning (not raise).")

    # Large deviation -> should RAISE
    bad = df_real.copy()
    bad.loc[5, "buy_volume"] = bad.loc[5, "volume"] * 5
    try:
        VolumeDeltaEngine().analyze(bad, buy_volume_col="buy_volume", sell_volume_col="sell_volume")
        print("❌ FAILED to catch hard volume mismatch")
    except VolumeDeltaDataError as e:
        print(f"✅ Caught hard violation: {e}")

    try:
        VolumeDeltaEngine().analyze(df.drop(columns=["volume"]))
        print("❌ FAILED to catch missing volume source")
    except VolumeDeltaDataError as e:
        print(f"✅ Caught: {e}")

    print(f"\n⚡ Numba acceleration: {'ON' if NUMBA_OK else 'OFF (pip install numba)'}")
