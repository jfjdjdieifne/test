import pandas as pd
import pytest

from trading_system import IntegrationDataError, TradingAnalysisPipeline
from trading_system.engines.liquidity_map import LiquidityMapEngine


def test_pipeline_runs_and_wires_expected_outputs(enriched_market_df):
    result = TradingAnalysisPipeline().analyze(enriched_market_df)
    out = result.dataframe

    expected = {
        "delta_ratio", "liq_max_sweep_score", "ob_net_bias_smoothed",
        "fvg_net_bias_smoothed", "premium_score", "discount_score",
    }
    assert expected.issubset(out.columns)
    assert len(out) == len(enriched_market_df)
    assert not out.columns.has_duplicates
    assert set(result.timings_ms) == {
        "volume_delta", "liquidity_map", "order_blocks", "fvg"
    }
    assert all(value >= 0 for value in result.timings_ms.values())


def test_pipeline_rejects_missing_upstream_columns(enriched_market_df):
    bad = enriched_market_df.drop(columns=["atr", "structure_state"])
    with pytest.raises(IntegrationDataError, match="atr"):
        TradingAnalysisPipeline().analyze(bad)


def test_liquidity_historical_query_preserves_terminal_history(enriched_market_df):
    engine = LiquidityMapEngine()
    _, levels = engine.analyze(enriched_market_df)
    terminal = [x for x in levels if x.swept_at_index is not None or x.broken_at_index is not None]
    if not terminal:
        pytest.skip("Synthetic path did not create a terminal level")
    level = terminal[0]
    terminal_at = level.swept_at_index if level.swept_at_index is not None else level.broken_at_index
    assert level in engine.get_active_levels_at(level.created_at_index)
    assert level not in engine.get_active_levels_at(terminal_at)
