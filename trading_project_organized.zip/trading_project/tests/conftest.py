import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def enriched_market_df() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    n = 240
    open_ = 30_000 + np.cumsum(rng.normal(0, 20, n))
    close = open_ + rng.normal(0, 12, n)
    high = np.maximum(open_, close) + np.abs(rng.normal(5, 3, n)) + 1e-6
    low = np.minimum(open_, close) - np.abs(rng.normal(5, 3, n)) - 1e-6
    volume = np.abs(rng.normal(500, 80, n))
    atr = pd.Series(high - low).rolling(14, min_periods=1).mean().to_numpy()
    vol_pct = pd.Series(atr).rolling(100, min_periods=2).rank(pct=True).fillna(0.5).to_numpy()

    swing_high = np.zeros(n, dtype=bool)
    swing_low = np.zeros(n, dtype=bool)
    swing_high_price = np.full(n, np.nan)
    swing_low_price = np.full(n, np.nan)
    swing_high_origin = np.full(n, np.nan)
    swing_low_origin = np.full(n, np.nan)
    for i in range(20, n, 30):
        swing_high[i] = True
        swing_high_price[i] = high[i - 5]
        swing_high_origin[i] = i - 5
    for i in range(35, n, 33):
        swing_low[i] = True
        swing_low_price[i] = low[i - 5]
        swing_low_origin[i] = i - 5

    structure = np.full(n, "RANGING", dtype=object)
    bos_type = np.full(n, "NONE", dtype=object)
    bos_strength = np.zeros(n)
    for k, i in enumerate(range(50, n, 60)):
        direction = "BULLISH" if k % 2 == 0 else "BEARISH"
        structure[i:] = direction
        bos_type[i:] = "BOS"
        bos_strength[i:] = 0.6 + 0.1 * (k % 3)

    return pd.DataFrame({
        "open": open_, "high": high, "low": low, "close": close, "volume": volume,
        "atr": atr, "volatility_percentile": vol_pct,
        "adaptive_period": np.full(n, 14),
        "swing_high": swing_high, "swing_low": swing_low,
        "swing_high_price": swing_high_price, "swing_low_price": swing_low_price,
        "swing_high_origin_index": swing_high_origin,
        "swing_low_origin_index": swing_low_origin,
        "structure_state": structure, "last_bos_type": bos_type,
        "last_bos_strength": bos_strength,
        "last_swing_high": pd.Series(high).rolling(30, min_periods=1).max(),
        "last_swing_low": pd.Series(low).rolling(30, min_periods=1).min(),
    })
