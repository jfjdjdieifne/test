# Legacy patch notes extracted from the source bundle

The original mixed file contained patch instructions between modules rather than executable Python.

## Applied

- Module 2.2 now imports `CausalPercentileTracker` from shared causal kernels.
- Module 2.2 historical `was_monitorable_at()` and `get_active_levels_at()` reconstruction patch.
- Module 3.1 now imports shared adaptive EMA, OLS slope, descriptive percentile, adaptive-period and truncation utilities.
- Module 4.1 already contained `disagreement_dampening_factor` in config.

## Not applicable because source module is absent

- Module 1.1 shared Wilder RMA/adaptive-period patch.
- Module 3.2 shared-kernel refactor.
- Module 3.2 smoke-test `bar_type="time"` correction.
- Module 3.2/Absorption L2 disagreement dampening hook.

These items must be revisited when the missing module sources are added.
