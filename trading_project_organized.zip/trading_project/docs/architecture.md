# Architecture

## Data flow

```text
Upstream (not supplied)
  Module 1.1: ATR / volatility / adaptive period
  Module 2.1: confirmed swings + origin indexes
  Structure engine: BOS/state/last structural range
                │
                ▼
Module 3.1 Volume Delta
                │ delta/order-flow columns
                ▼
Module 2.2 Liquidity Map
                │ liquidity evidence
                ▼
Module 4.1 Order Blocks
                │ OB distance/confluence
                ▼
Module 4.2 FVG + Premium/Discount
                │
                ▼
Primary enriched DataFrame + lifecycle registries + timing metrics
```

## Separation of concerns

- `core/`: numerical causal primitives only.
- `engines/`: market-analysis state machines.
- `audit/`: generic causality, determinism and state-isolation checks.
- `pipeline.py`: explicit dependency order and cross-module wiring.
- `tests/`: regression/integration tests; engine demo code remains available via `python -m`.

## State policy

Liquidity, Order Block and FVG engines keep mutable lifecycle registries. The integration pipeline therefore constructs fresh engines on every `analyze()` call. Direct callers should also use one fresh engine per independent dataset unless a future explicit streaming API is introduced.

## Column contract

The integration layer validates the upstream columns before execution. Optional order-flow/absorption/confluence evidence remains neutral when absent according to each engine's own policy.
