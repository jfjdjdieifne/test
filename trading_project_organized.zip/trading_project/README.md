# Causal Trading System

تنظيم قابل للتشغيل للكود المجمّع في الملف الأصلي، مع فصل المحركات، الأدوات المشتركة، التدقيق، الربط والاختبارات.

## الوحدات الموجودة حالياً

| الوحدة | الملف | الحالة |
|---|---|---|
| 0.1 Causal/State Audit | `audit/causal_state.py` | موجود ويعمل |
| Shared causal kernels | `core/causal_kernels.py` | موجود ويعمل |
| 2.2 Liquidity Map | `engines/liquidity_map.py` | موجود ويعمل |
| 3.1 Volume Delta | `engines/volume_delta.py` | موجود ويعمل |
| 4.1 Order Blocks | `engines/order_blocks.py` | موجود ويعمل |
| 4.2 FVG + Premium/Discount | `engines/fvg.py` | موجود ويعمل |
| Integration | `pipeline.py` | يربط الوحدات الموجودة |

الوحدات المشار إليها في الملاحظات لكن كودها غير موجود في المصدر: **1.1 و2.1 و3.2**. لذلك الـ pipeline يتوقع أن تصله أعمدة ATR/regime وswings وmarket structure جاهزة.

## بنية المشروع

```text
trading_project/
├── pyproject.toml
├── README.md
├── docs/
│   ├── architecture.md
│   ├── engineering_report.md
│   ├── legacy_patch_notes.md
│   └── source_bundle_original.txt
├── scripts/
│   └── healthcheck.py
├── src/trading_system/
│   ├── pipeline.py
│   ├── audit/causal_state.py
│   ├── core/causal_kernels.py
│   └── engines/
│       ├── liquidity_map.py
│       ├── volume_delta.py
│       ├── order_blocks.py
│       └── fvg.py
└── tests/
    ├── conftest.py
    └── test_pipeline.py
```

## التشغيل

```bash
cd trading_project
python -m pip install -e ".[dev,performance]"
pytest
python scripts/healthcheck.py
```

بدون تثبيت الحزمة:

```bash
PYTHONPATH=src python scripts/healthcheck.py
```

## الاستخدام

```python
from trading_system import TradingAnalysisPipeline

result = TradingAnalysisPipeline().analyze(enriched_dataframe)
final_df = result.dataframe
print(result.timings_ms)
```

> هذا النظام تحليلي/بحثي حالياً، وليس منفّذ أوامر تداول ولا يضمن الربحية. يلزم backtest وwalk-forward واختبارات رسوم/انزلاق ومخاطر قبل أي استخدام حي.
