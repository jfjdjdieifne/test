import sys, time, datetime, os
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from ict_sessions import classify_session
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

WATCHING_SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

def print_banner(msg):
    print(f"\n{'='*85}")
    print(f"  {msg}")
    print(f"{'='*85}")

# =====================================================================
# 1. وضع التداول الحي (مفصل جداً - Verbose Mode)
# =====================================================================
def run_live():
    account_balance = ACCOUNT_BALANCE
    active_trades = {}
    ignored_signals = set()
    cycle = 0

    print_banner(f"🟢 بدء التداول الحي المدمج | الرصيد: {account_balance}$ | المخاطرة: 1%")

    while True:
        try:
            now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
            
            # مسح السوق التفصيلي (كل 5 دقائق)
            if cycle % 5 == 0:
                session_info = classify_session(int(time.time()*1000))
                curr_session = session_info.get("session", "UNKNOWN")
                
                print_banner(f"📡 رادار المسح الشامل | توقيت نيويورك: {now_ny.strftime('%H:%M:%S')} | الجلسة الحالية: {curr_session}")
                
                for symbol in WATCHING_SYMBOLS:
                    data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
                    if not data_15m or not data_15m['closes']: continue
                    current_p = data_15m['closes'][-1]
                    
                    print(f"\n🪙 العملة: {symbol} | السعر اللحظي: {current_p:.4f}")
                    
                    anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
                    bias = anchor.get("anchor_direction")
                    
                    if bias not in ["BULLISH", "BEARISH"]:
                        print("   📊 فريم (1D/4H) -> 🛑 الاتجاه: متذبذب (CHOP). السوق عرضي وبدون سيولة واضحة. البوت يتجاهل العملة.")
                        continue
                        
                    print(f"   📊 فريم (1D/4H) -> 🧭 الاتجاه: {bias} (تم تأكيد تسلسل القمم والقيعان).")
                    
                    sig = ae.detect_significant_swings(data_15m, swing_window=3, lookback_candles=150)
                    levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
                    
                    if not levels:
                        print("   🔍 فريم (15m)   -> 👁️ لا توجد سيولة (Major/Moderate) قريبة. البوت يراقب تشكل قمم/قيعان جديدة.")
                        continue
                        
                    target_lvl = levels[0]['price']
                    dist = abs(current_p - target_lvl)
                    target_type = "قاع (Sell-Side Liquidity)" if bias == "BULLISH" else "قمة (Buy-Side Liquidity)"
                    
                    print(f"   🔍 فريم (15m)   -> 🎯 أنتظر ضرب {target_type} عند السعر [{target_lvl:.4f}] (المسافة: {dist:.4f}$)")
                    
                    res = classify_sweep_or_run(data_15m, target_lvl, level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                    if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                        print(f"   ⚠️ فريم (15m)   -> 🚨 الماركت ميكر ضرب السيولة للتو وشكل ذيلاً (Sweep)!")
                        
                        data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                        res_5m = evaluate_all_entry_models(data_5m, bias)
                        status = res_5m.get("final_status")
                        
                        if status == "PENDING_SETUP":
                            print("   🔫 فريم (5m)    -> ⏳ ننتظر تشكل الإزاحة والفجوة السعرية (FVG) لتأكيد الدخول.")
                        elif status == "READY":
                            sig_id = f"{symbol}_{target_lvl}"
                            if sig_id not in ignored_signals and symbol not in active_trades:
                                plan = res_5m.get("chosen_model", {}).get("plan", {})
                                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                                
                                if entry and sl and tp1:
                                    risk_dist = abs(entry - sl)
                                    risk_usd = account_balance * RISK_PCT
                                    pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                                    
                                    print_banner(f"🚨 صفقة حية تفعلت: {symbol} | الحساب: {account_balance:.2f}$")
                                    print(f"القرار: {'بيع 🔴' if bias == 'BEARISH' else 'شراء 🟢'}")
                                    print(f"الدخول: {entry:.4f} | الستوب: {sl:.4f} | الهدف: {tp1:.4f}")
                                    print(f"💵 حجم العقد: {pos_size:.4f} | المخاطرة: {risk_usd:.2f}$")
                                    
                                    active_trades[symbol] = {
                                        "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                        "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                        "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                        "risk_usd": risk_usd
                                    }
                                    ignored_signals.add(sig_id)
                    else:
                        print("   🔫 فريم (5m)    -> ⏳ البوت في وضع الاستعداد بانتظار ضرب الهدف المبين أعلاه.")

            if active_trades:
                print("\n" + "-"*40)
                for symbol, t in list(active_trades.items()):
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
                    if not data_5m or not data_5m['closes']: continue
                    
                    h, l, c = data_5m['highs'][-1], data_5m['lows'][-1], data_5m['closes'][-1]
                    now_str = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz).strftime('%H:%M:%S')
                    print(f"[{now_str}] 👁️ {symbol} | السعر: {c:.4f} | הستوب: {t['current_sl']:.4f} | الرصيد: {account_balance:.2f}$")
                    
                    risk, entry, is_short, size, risk_usd = t['risk'], t['entry'], t['is_short'], t['size'], t['risk_usd']
                    
                    if is_short:
                        if h >= t['current_sl']:
                            if t['current_sl'] == t['sl']: 
                                account_balance -= risk_usd
                                print_banner(f"❌ {symbol}: ضرب الستوب! خسارة {-risk_usd:.2f}$ | الرصيد: {account_balance:.2f}$")
                            elif t['current_sl'] == entry: 
                                print_banner(f"🛡️ {symbol}: خروج عالدخول بأمان. الرصيد: {account_balance:.2f}$")
                            else: 
                                profit = (entry - t['current_sl']) * size
                                account_balance += profit
                                print_banner(f"🧠 {symbol}: ضرب الستوب المتتبع! ربح {profit:.2f}$ | الرصيد: {account_balance:.2f}$")
                            del active_trades[symbol]
                            continue
                            
                        if l <= t['tp1'] and not t['tp1_hit']:
                            profit_80 = (abs(t['tp1'] - entry) * size) * 0.8
                            account_balance += profit_80
                            print_banner(f"🎯 {symbol}: ضرب الهدف الأول! تم تأمين {profit_80:.2f}$ | الرصيد: {account_balance:.2f}$")
                            t['tp1_hit'] = True; t['be_activated'] = True; t['current_sl'] = entry
                            
                        if l <= (entry - 1.5*risk) and not t['be_activated']:
                            print(f"🛡️ {symbol}: تجاوز 1.5R. نقل الستوب للدخول.")
                            t['be_activated'] = True; t['current_sl'] = entry
                            
                        if len(data_5m['highs']) >= 3 and data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                            swing_high = data_5m['highs'][-2]
                            if l < data_5m['lows'][-2] and swing_high < t['current_sl'] and t['be_activated']:
                                t['current_sl'] = swing_high + (risk * 0.1)
                    else:
                        if l <= t['current_sl']:
                            if t['current_sl'] == t['sl']: 
                                account_balance -= risk_usd
                                print_banner(f"❌ {symbol}: ضرب الستوب! خسارة {-risk_usd:.2f}$ | الرصيد: {account_balance:.2f}$")
                            elif t['current_sl'] == entry: 
                                print_banner(f"🛡️ {symbol}: خروج عالدخول بأمان. الرصيد: {account_balance:.2f}$")
                            else: 
                                profit = (t['current_sl'] - entry) * size
                                account_balance += profit
                                print_banner(f"🧠 {symbol}: ضرب الستوب المتتبع! ربح {profit:.2f}$ | الرصيد: {account_balance:.2f}$")
                            del active_trades[symbol]
                            continue
                            
                        if h >= t['tp1'] and not t['tp1_hit']:
                            profit_80 = (abs(t['tp1'] - entry) * size) * 0.8
                            account_balance += profit_80
                            print_banner(f"🎯 {symbol}: ضرب الهدف الأول! تم تأمين {profit_80:.2f}$ | الرصيد: {account_balance:.2f}$")
                            t['tp1_hit'] = True; t['be_activated'] = True; t['current_sl'] = entry
                            
                        if h >= (entry + 1.5*risk) and not t['be_activated']:
                            print(f"🛡️ {symbol}: تجاوز 1.5R. نقل الستوب للدخول.")
                            t['be_activated'] = True; t['current_sl'] = entry
                            
                        if len(data_5m['lows']) >= 3 and data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                            swing_low = data_5m['lows'][-2]
                            if h > data_5m['highs'][-2] and swing_low > t['current_sl'] and t['be_activated']:
                                t['current_sl'] = swing_low - (risk * 0.1)

            cycle += 1
            time.sleep(60)
        except KeyboardInterrupt:
            print("\nتم الإيقاف.")
            sys.exit(0)

# =====================================================================
# 2. وضع الباكتيست 
# =====================================================================
def run_backtest(days_back=30):
    print_banner(f"⏱️ فحص تاريخي صارم לـ {days_back} יوماً | 5 عملات كبرى | الرصيد: 100.0$")
    bt_symbols = ["ETH/USDT", "BTC/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"]
    
    bt_account = 100.0
    all_results = []
    
    for symbol in bt_symbols:
        print(f"\n[🔄] جاري تحميل وتفحّص بيانات {symbol}...")
        try:
            full_data = brain.data_manager.get_ohlcv(symbol, "15m", 1500 + (days_back*96), output_format="dict")
            if not full_data or len(full_data['closes']) < 500: continue
            
            n = len(full_data["closes"])
            start_idx = max(200, n - (days_back*96))
            candidates = []
            reported_days = set()

            total_steps = len(range(start_idx, n, 10))
            current_step = 0
            
            for i in range(start_idx, n, 10): 
                current_step += 1
                if current_step % 20 == 0:
                    sys.stdout.write(f"\r     -> فحص الشموع ({current_step}/{total_steps}) 진행...")
                    sys.stdout.flush()

                window_data = {k: v[:i+1] for k, v in full_data.items() if isinstance(v, list)}
                try:
                    anchor = compute_mechanical_bias_anchor(window_data, lookback=150)
                    bias = anchor.get("anchor_direction")
                    if bias not in ["BULLISH", "BEARISH"]: continue

                    current_ts = window_data["timestamps"][-1]
                    day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
                    
                    # تبريد قاسي: صفقة واحدة لكل عملة في اليوم كحد أقصى!
                    if day_str in reported_days: continue

                    # فلتر الأوقات (السيولة الحقيقية فقط)
                    sess = classify_session(current_ts).get("session", "")
                    if sess not in ["LONDON_KILL_ZONE", "NY_AM_KILL_ZONE", "NY_PM_KILL_ZONE"]: continue

                    # فلتر السوينغات (التوازن المثالي)
                    sig = ae.detect_significant_swings(window_data, swing_window=3, lookback_candles=150)
                    levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
                    
                    for cand in levels:
                        res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=i)
                        if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                            if not any(c["symbol"] == symbol and abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
                                sess = classify_session(current_ts).get("session", "")
                                if sess in ["LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"]:
                                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})
                                reported_days.add(day_str)
                            break
                except Exception: pass
            
            print(f"\n     ✅ تم إيجاد {len(candidates)} إشارات. جاري محاكاة الدخول...")

            for cand in candidates:
                sweep_ts, bias, sym = cand['timestamp'], cand['bias'], cand['symbol']
                for k in range(0, 8):
                    sim_ts = sweep_ts + (k * 15 * 60 * 1000)
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts, limit=150)
                    try:
                        res = evaluate_all_entry_models(data_5m, bias)
                        if res.get("final_status") in ["READY", "PENDING_SETUP"]:
                            plan = res.get("chosen_model", {}).get("plan", {})
                            entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                            if entry and sl and tp1:
                                is_short = (bias == "BEARISH")
                                f_data = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts + 24*3600*1000, limit=288)
                                risk = abs(sl - entry)
                                if risk == 0: break
                                
                                c_sl, be, tp_hit, entry_hit = sl, False, False, False
                                outcome = "OPEN"
                                exit_price = entry
                                
                                for j in range(5, len(f_data['closes'])):
                                    h, l = f_data['highs'][j], f_data['lows'][j]
                                    if is_short:
                                        if h >= entry and not entry_hit: entry_hit = True
                                        if not entry_hit: continue
                                        if l <= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                        if l < (entry - 1.5*risk) and not be: c_sl, be = entry, True
                                        
                                        if h >= c_sl:
                                            exit_price = c_sl
                                            if c_sl == sl: outcome = "SL_HIT"
                                            elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                            else: outcome = "DYNAMIC_TRAIL_HIT"
                                            break
                                            
                                        if f_data['highs'][j-1] > f_data['highs'][j-2] and f_data['highs'][j-1] > f_data['highs'][j]:
                                            swing_high = f_data['highs'][j-1]
                                            if l < f_data['lows'][j-1] and swing_high < c_sl and be:
                                                c_sl = swing_high + (risk * 0.1) 
                                    else:
                                        if l <= entry and not entry_hit: entry_hit = True
                                        if not entry_hit: continue
                                        if h >= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                        if h > (entry + 1.5*risk) and not be: c_sl, be = entry, True
                                        
                                        if l <= c_sl:
                                            exit_price = c_sl
                                            if c_sl == sl: outcome = "SL_HIT"
                                            elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                            else: outcome = "DYNAMIC_TRAIL_HIT"
                                            break
                                            
                                        if f_data['lows'][j-1] < f_data['lows'][j-2] and f_data['lows'][j-1] < f_data['lows'][j]:
                                            swing_low = f_data['lows'][j-1]
                                            if h > f_data['highs'][j-1] and swing_low > c_sl and be:
                                                c_sl = swing_low - (risk * 0.1)

                                if not entry_hit: outcome = "ENTRY_NEVER_HIT"
                                
                                if outcome not in ["OPEN", "ENTRY_NEVER_HIT"]:
                                    all_results.append({
                                        "date": cand['datetime_utc'][:16].replace('T', ' '),
                                        "symbol": sym, "bias": "بيع🔴" if is_short else "شراء🟢",
                                        "entry": entry, "outcome": outcome, "tp1_hit": tp_hit,
                                        "risk": risk, "exit": exit_price, "tp1": tp1
                                    })
                                break
                    except Exception: pass
        except Exception: pass

    all_results.sort(key=lambda x: x["date"])
    for r in all_results:
        risk_usd = bt_account * RISK_PCT
        pos_size = risk_usd / r['risk'] if r['risk'] > 0 else 0
        profit = 0.0
        
        if r['outcome'] == "SL_HIT": profit = -risk_usd
        elif r['outcome'] == "BREAK_EVEN_HIT": profit = 0.0
        elif r['outcome'] in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: 
            profit = (abs(r['tp1'] - r['entry']) * pos_size) * 0.5
        elif r['outcome'] == "DYNAMIC_TRAIL_HIT":
            base_profit = (abs(r['tp1'] - r['entry']) * pos_size) * 0.5 if r['tp1_hit'] else 0.0
            rem_profit = (abs(r['exit'] - r['entry']) * pos_size) * 0.2
            profit = base_profit + rem_profit
            
        bt_account += profit
        r['profit_usd'] = profit
        r['balance'] = bt_account

    print_banner("النتيجة النهائية للباكتيست")
    print(f"{'التاريخ':<16} | {'العملة':<8} | {'النوع':<6} | {'الدخول':<8} | {'النتيجة':<22} | {'الربح':<8} | {'الرصيد':<8}")
    print("-" * 90)
    for r in all_results:
        o = r['outcome']
        if o == "DYNAMIC_TRAIL_HIT": o = "تتبع هيكلي 🧠🎯"
        elif o == "TP1_THEN_BE" or o == "PARTIAL_TP_HIT_THEN_OPEN": o = "ربح جزئي(80%) 🎯"
        elif o == "BREAK_EVEN_HIT": o = "خروج عالدخول 🛡️"
        elif o == "SL_HIT": o = "ستوب لوس ❌"
        print(f"{r['date']:<16} | {r['symbol']:<8} | {r['bias']:<6} | {r['entry']:>7.2f} | {o:<22} | {r['profit_usd']:>6.2f}$ | {r['balance']:>6.2f}$")

    wins = sum(1 for r in all_results if r['profit_usd'] > 0)
    losses = sum(1 for r in all_results if r['profit_usd'] < 0)
    bes = sum(1 for r in all_results if r['profit_usd'] == 0)

    print("="*90)
    print(f"عدد الصفقات الإجمالي المنفذة: {len(all_results)}")
    print(f"✅ رابحة: {wins} | 🛡️ تعادل: {bes} | ❌ خاسرة: {losses}")
    if (wins + losses) > 0:
        print(f"🏆 نسبة النجاح (Win Rate): {(wins/(wins+losses))*100:.1f}%")
    print(f"الرصيد النهائي: {bt_account:.2f}$ (النمو: +{((bt_account-100)/100)*100:.2f}%)")
    print("="*90)

if __name__ == "__main__":
    print_banner("مرحباً بك في ICT Algo Master 🤖")
    print("1. تشغيل التداول المباشر (Live Trading Simulator) [يقرأ السوق 24/7]")
    print("2. اختبار الباكتيست الصارم (30 Days - No Cheating) [مراقبة 5 عملات كبرى]")
    
    try:
        choice = input("\nأدخل رقم الخيار (1، 2): ")
        if choice == "1":
            run_live()
        elif choice == "2":
            run_backtest(30)
        else:
            print("خيار غير صحيح!")
    except KeyboardInterrupt:
        print("\nتم الإنهاء.")

