import sys, time, threading, datetime, os
sys.path.insert(0, ".")
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
import pytz
from ict_sessions import classify_session

# ================= الإعدادات =================
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8996304796:AAHK6RMV9jLKUS43oOX9I72jdJBNy0NOz1M")
CHAT_ID = None

brain = BrainCore()
ae = AuthenticityEngine()
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)
ny_tz = pytz.timezone('America/New_York')

WATCHING_SYMBOLS = [
    "BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT", 
    "ADA/USDT", "DOGE/USDT", "AVAX/USDT", "LINK/USDT", "DOT/USDT"
]

# بيانات المحاكاة الحية
live_account = 100.0
risk_pct = 0.01
active_trades = {}
ignored_signals = set()
is_live_active = False

# ================= دوال التيليجرام =================
def main_menu():
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("🟢 تشغيل التداول الحي (Live Paper Trading)", callback_data="toggle_live"),
        InlineKeyboardButton("📊 فحص الرصيد والصفقات المفتوحة", callback_data="check_status"),
        InlineKeyboardButton("🧠 تقرير التفكير العميق للسوق الآن", callback_data="live_thoughts"),
        InlineKeyboardButton("⏱️ باكتيست: آخر 30 يوماً (بدون غش)", callback_data="run_bt_30")
    )
    return markup

@bot.message_handler(commands=['start'])
def send_welcome(message):
    global CHAT_ID
    CHAT_ID = message.chat.id
    msg = "مرحباً بك في <b>غرفة عمليات ICT 🤖💼</b>\n\n"
    msg += "أنا مدير صندوقك الافتراضي. أمتلك 10 عملات كبرى في راداري، ورصيداً وهمياً بقيمة <code>100$</code> وإدارة مخاطر صارمة 1%.\n\n"
    msg += "ماذا نأمرني أن أفعل اليوم؟"
    bot.reply_to(message, msg, reply_markup=main_menu(), parse_mode='HTML')

# ================= محرك التداول الحي =================
def format_thoughts(symbol, bias, is_swept, swept_level):
    direction = "هابط 📉" if bias == "BEARISH" else "صاعد 📈"
    target_liq = "قمم سيولة شرائية (Buy-Side Liquidity)" if bias == "BEARISH" else "قيعان سيولة بيعية (Sell-Side Liquidity)"
    
    msg = f"🔎 <b>تفكير البوت الميكانيكي | {symbol}</b>\n"
    msg += f"────────────────\n"
    msg += f"🧠 <b>الاتجاه (Bias):</b> {direction} (بعد فحص 150 شمعة وقمم/قيعان).\n"
    
    if not is_swept:
        msg += f"⏳ <b>ماذا أنتظر؟</b> أنا أنتظر الماركت ميكر ليقوم بضرب {target_liq}، لن أضغط الزناد قبل أن أرى الفخ يكتمل.\n"
    else:
        msg += f"🚨 <b>ماذا رأيت؟</b> الماركت ميكر ضرب للتو سيولة عند <code>{swept_level}</code> وارتد تاركاً ذيلاً (Sweep)!\n"
        msg += f"⏳ <b>ماذا أنتظر للدخول؟</b> يجب أن أرى شمعة قوية تندفع وتخلف وراءها فجوة سعرية (FVG) على فريم 5 دقائق لأعلق أمري هناك.\n"
    return msg

def live_scanner_thread():
    global live_account, is_live_active, CHAT_ID
    cycle = 0
    while True:
        if is_live_active and CHAT_ID:
            try:
                # 1. مسح الأسواق للفرص الجديدة (كل 10 دقائق تقريباً لتجنب السپام)
                if cycle % 10 == 0:
                    for symbol in WATCHING_SYMBOLS:
                        data_15m = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
                        if not data_15m or not data_15m['closes']: continue
                        
                        anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
                        bias = anchor.get("anchor_direction")
                        if bias not in ["BULLISH", "BEARISH"]: continue
                        
                        sig = ae.detect_significant_swings(data_15m, swing_window=3, lookback_candles=150)
                        is_swept, swept_level = False, 0
                        
                        levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
                        for cand in levels:
                            res = classify_sweep_or_run(data_15m, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=len(data_15m['closes'])-1)
                            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -2:
                                is_swept, swept_level = True, cand["price"]
                                break
                        
                        sig_id = f"{symbol}_{swept_level}" if is_swept else None
                        
                        if is_swept:
                            data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=150)
                            res_5m = evaluate_all_entry_models(data_5m, bias)
                            status = res_5m.get("final_status")
                            
                            if status == "PENDING_SETUP" and sig_id not in ignored_signals:
                                bot.send_message(CHAT_ID, format_thoughts(symbol, bias, True, swept_level), parse_mode='HTML')
                                ignored_signals.add(sig_id)
                                
                            elif status == "READY":
                                if sig_id not in ignored_signals and symbol not in active_trades:
                                    plan = res_5m.get("chosen_model", {}).get("plan", {})
                                    entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                                    
                                    if entry and sl and tp1:
                                        risk_dist = abs(entry - sl)
                                        risk_usd = live_account * risk_pct
                                        pos_size = risk_usd / risk_dist if risk_dist > 0 else 0
                                        
                                        active_trades[symbol] = {
                                            "bias": bias, "entry": entry, "sl": sl, "tp1": tp1,
                                            "current_sl": sl, "be_activated": False, "tp1_hit": False,
                                            "is_short": bias == "BEARISH", "risk": risk_dist, "size": pos_size,
                                            "risk_usd": risk_usd
                                        }
                                        ignored_signals.add(sig_id)
                                        
                                        msg = f"🚨 <b>تأكيد اكتمل! جاري الدخول الآلي!</b> 🚨\n"
                                        msg += f"🪙 العملة: <b>{symbol}</b>\n"
                                        msg += f"🧭 القرار: {'🔴 بيع (SHORT)' if bias == 'BEARISH' else '🟢 شراء (LONG)'}\n"
                                        msg += f"📍 الدخول: <code>{entry:.4f}</code> (Limit Order)\n"
                                        msg += f"🛑 الستوب: <code>{sl:.4f}</code>\n"
                                        msg += f"🎯 الهدف الأول: <code>{tp1:.4f}</code> (80%)\n"
                                        msg += f"💵 حجم العقد: {pos_size:.4f} | المخاطرة: {risk_usd:.2f}$"
                                        bot.send_message(CHAT_ID, msg, parse_mode='HTML')

                # 2. متابعة الصفقات המفتوحة (دقيقة بدقيقة)
                if active_trades:
                    for symbol, t in list(active_trades.items()):
                        data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", int(time.time()*1000), limit=20)
                        if not data_5m or not data_5m['closes']: continue
                        
                        h, l = data_5m['highs'][-1], data_5m['lows'][-1]
                        risk, entry, is_short, size, risk_usd = t['risk'], t['entry'], t['is_short'], t['size'], t['risk_usd']
                        
                        if is_short:
                            if h >= t['current_sl']:
                                if t['current_sl'] == t['sl']: 
                                    live_account -= risk_usd
                                    out_msg = f"❌ <b>انضرب الستوب:</b> {symbol}\nالخسارة: -{risk_usd:.2f}$\nالرصيد: {live_account:.2f}$"
                                elif t['current_sl'] == entry: 
                                    out_msg = f"🛡️ <b>خروج عالدخول بأمان:</b> {symbol}\nالرصيد: {live_account:.2f}$"
                                else: 
                                    profit = (entry - t['current_sl']) * size
                                    live_account += profit
                                    out_msg = f"🧠 <b>قنص وتتبع ناجح:</b> {symbol}\nالربح المحجوز: +{profit:.2f}$\nالرصيد: {live_account:.2f}$"
                                bot.send_message(CHAT_ID, out_msg, parse_mode='HTML')
                                del active_trades[symbol]
                                continue
                                
                            if l <= t['tp1'] and not t['tp1_hit']:
                                profit_80 = (abs(t['tp1'] - entry) * size) * 0.8
                                live_account += profit_80
                                t['tp1_hit'] = True; t['be_activated'] = True; t['current_sl'] = entry
                                bot.send_message(CHAT_ID, f"🎯 <b>ضرب الهدف الأول:</b> {symbol}\nتم جني 80% أرباح (+{profit_80:.2f}$). نقلت الستوب للدخول!\nالرصيد: {live_account:.2f}$", parse_mode='HTML')
                                
                            if l <= (entry - 1.5*risk) and not t['be_activated']:
                                t['be_activated'] = True; t['current_sl'] = entry
                                bot.send_message(CHAT_ID, f"🛡️ <b>تأمين الصفقة:</b> {symbol}\nالسعر ابتعد 1.5R. نقلت הستوب للدخول.", parse_mode='HTML')
                                
                            if len(data_5m['highs']) >= 3 and data_5m['highs'][-2] > data_5m['highs'][-3] and data_5m['highs'][-2] > data_5m['highs'][-1]:
                                swing_high = data_5m['highs'][-2]
                                if l < data_5m['lows'][-2] and swing_high < t['current_sl'] and t['be_activated']:
                                    t['current_sl'] = swing_high + (risk * 0.1)
                                    bot.send_message(CHAT_ID, f"🧠 <b>تتبع هيكلي:</b> {symbol}\nتشكلت قمة هابطة. أنزلت الستوب لوس إلى <code>{t['current_sl']:.4f}</code>", parse_mode='HTML')
                        else:
                            if l <= t['current_sl']:
                                if t['current_sl'] == t['sl']: 
                                    live_account -= risk_usd
                                    out_msg = f"❌ <b>انضرب الستوب:</b> {symbol}\nالخسارة: -{risk_usd:.2f}$\nالرصيد: {live_account:.2f}$"
                                elif t['current_sl'] == entry: 
                                    out_msg = f"🛡️ <b>خروج عالدخول بأمان:</b> {symbol}\nالرصيد: {live_account:.2f}$"
                                else: 
                                    profit = (t['current_sl'] - entry) * size
                                    live_account += profit
                                    out_msg = f"🧠 <b>قنص وتتبع ناجح:</b> {symbol}\nالربح المحجوز: +{profit:.2f}$\nالرصيد: {live_account:.2f}$"
                                bot.send_message(CHAT_ID, out_msg, parse_mode='HTML')
                                del active_trades[symbol]
                                continue
                                
                            if h >= t['tp1'] and not t['tp1_hit']:
                                profit_80 = (abs(t['tp1'] - entry) * size) * 0.8
                                live_account += profit_80
                                t['tp1_hit'] = True; t['be_activated'] = True; t['current_sl'] = entry
                                bot.send_message(CHAT_ID, f"🎯 <b>ضرب الهدف الأول:</b> {symbol}\nتم جني 80% أرباح (+{profit_80:.2f}$). نقلت الستوب للدخول!\nالرصيد: {live_account:.2f}$", parse_mode='HTML')
                                
                            if h >= (entry + 1.5*risk) and not t['be_activated']:
                                t['be_activated'] = True; t['current_sl'] = entry
                                bot.send_message(CHAT_ID, f"🛡️ <b>تأمين الصفقة:</b> {symbol}\nالسعر ابتعد 1.5R. نقلت הستوب للدخول.", parse_mode='HTML')
                                
                            if len(data_5m['lows']) >= 3 and data_5m['lows'][-2] < data_5m['lows'][-3] and data_5m['lows'][-2] < data_5m['lows'][-1]:
                                swing_low = data_5m['lows'][-2]
                                if h > data_5m['highs'][-2] and swing_low > t['current_sl'] and t['be_activated']:
                                    t['current_sl'] = swing_low - (risk * 0.1)
                                    bot.send_message(CHAT_ID, f"🧠 <b>تتبع هيكلي:</b> {symbol}\nتشكل قاع صاعد. رفعت الستوب لوس إلى <code>{t['current_sl']:.4f}</code>", parse_mode='HTML')

            except Exception: pass
        cycle += 1
        time.sleep(60)

# ================= محرك الباكتيست الصارم =================
def strict_backtest_thread(days_back):
    global CHAT_ID
    if not CHAT_ID: return
    
    bot.send_message(CHAT_ID, f"🔄 <b>بدء الباكتيست (محاكاة {days_back} يوماً)</b>\nلا تقلق، أنا لا أغش الشموع المستقبلية برمجياً. انتظر قليلاً...", parse_mode='HTML')
    bt_account = 100.0
    all_results = []
    bt_symbols = ["ETH/USDT", "BTC/USDT", "SOL/USDT"] 
    
    for symbol in bt_symbols:
        try:
            full_data = brain.data_manager.get_ohlcv(symbol, "15m", 1500 + (days_back*96), output_format="dict")
            if not full_data or len(full_data['closes']) < 1000: continue
            
            n = len(full_data["closes"])
            start_idx = max(500, n - (days_back*96))
            candidates = []
            reported_days = set()

            for i in range(start_idx, n, 6): 
                window_data = {k: v[:i+1] for k, v in full_data.items() if isinstance(v, list)}
                try:
                    anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
                    bias = anchor.get("anchor_direction")
                    if bias not in ["BULLISH", "BEARISH"]: continue
                    current_ts = window_data["timestamps"][-1]
                    day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
                    if day_str in reported_days: continue
                    sig = ae.detect_significant_swings(window_data, swing_window=3, lookback_candles=150)
                    levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
                    
                    for cand in levels:
                        res = classify_sweep_or_run(window_data, cand["price"], level_is_high=(bias=="BEARISH"), check_from_idx=i)
                        if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                            # Cooldown 12h & Session Filter
                            if not any(c["symbol"] == symbol and abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
                                sess = classify_session(current_ts).get("session", "")
                                if sess not in ["ASIAN_RANGE", "DEAD_ZONE", "UNKNOWN"]:
                                    dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                                    candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "bias": bias, "symbol": symbol})
                                    reported_days.add(day_str)
                            break
                except Exception: pass

            for cand in candidates:
                sweep_ts, bias, sym = cand['timestamp'], cand['bias'], cand['symbol']
                for k in range(0, 8):
                    sim_ts = sweep_ts + (k * 15 * 60 * 1000)
                    data_5m = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts, limit=150)
                    try:
                        res = evaluate_all_entry_models(data_5m, bias)
                        if res.get("final_status") in ["READY", "PENDING_SETUP"]:
                            plan = res.get("chosen_model", {}).get("plan", {})
                            entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                            if entry and sl and tp1:
                                is_short = (bias == "BEARISH")
                                f_data = brain.data_manager.fetch_ohlcv_up_to(sym, "5m", sim_ts + 24*3600*1000, limit=288)
                                risk = abs(sl - entry)
                                if risk == 0: break
                                
                                c_sl, be, tp_hit, entry_hit = sl, False, False, False
                                outcome = "OPEN"
                                exit_price = entry
                                
                                for j in range(5, len(f_data['closes'])):
                                    h, l = f_data['highs'][j], f_data['lows'][j]
                                    if is_short:
                                        if h >= entry and not entry_hit: entry_hit = True
                                        if not entry_hit: continue
                                        if l <= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                        if l < (entry - 1.5*risk) and not be: c_sl, be = entry, True
                                        if h >= c_sl:
                                            exit_price = c_sl
                                            if c_sl == sl: outcome = "SL_HIT"
                                            elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                            else: outcome = "DYNAMIC_TRAIL_HIT"
                                            break
                                        if f_data['highs'][j-1] > f_data['highs'][j-2] and f_data['highs'][j-1] > f_data['highs'][j]:
                                            swing_high = f_data['highs'][j-1]
                                            if l < f_data['lows'][j-1] and swing_high < c_sl and be: c_sl = swing_high + (risk * 0.1) 
                                    else:
                                        if l <= entry and not entry_hit: entry_hit = True
                                        if not entry_hit: continue
                                        if h >= tp1 and not tp_hit: tp_hit, be, c_sl = True, True, entry
                                        if h > (entry + 1.5*risk) and not be: c_sl, be = entry, True
                                        if l <= c_sl:
                                            exit_price = c_sl
                                            if c_sl == sl: outcome = "SL_HIT"
                                            elif c_sl == entry: outcome = "TP1_THEN_BE" if tp_hit else "BREAK_EVEN_HIT"
                                            else: outcome = "DYNAMIC_TRAIL_HIT"
                                            break
                                        if f_data['lows'][j-1] < f_data['lows'][j-2] and f_data['lows'][j-1] < f_data['lows'][j]:
                                            swing_low = f_data['lows'][j-1]
                                            if h > f_data['highs'][j-1] and swing_low > c_sl and be: c_sl = swing_low - (risk * 0.1)

                                if not entry_hit: outcome = "ENTRY_NEVER_HIT"
                                if outcome not in ["OPEN", "ENTRY_NEVER_HIT"]:
                                    all_results.append({
                                        "date": cand['datetime_utc'][:16].replace('T', ' '),
                                        "symbol": sym, "bias": "بيع🔴" if is_short else "شراء🟢",
                                        "entry": entry, "outcome": outcome, "tp1_hit": tp_hit,
                                        "risk": risk, "exit": exit_price
                                    })
                                break
                    except Exception: pass
        except Exception: pass

    all_results.sort(key=lambda x: x["date"])
    for r in all_results:
        risk_usd = bt_account * risk_pct
        pos_size = risk_usd / r['risk'] if r['risk'] > 0 else 0
        profit = 0.0
        
        if r['outcome'] == "SL_HIT": profit = -risk_usd
        elif r['outcome'] == "BREAK_EVEN_HIT": profit = 0.0
        elif r['outcome'] == "TP1_THEN_BE": profit = (abs(r['entry'] - r['exit']) * pos_size) * 0.8
        elif r['outcome'] == "DYNAMIC_TRAIL_HIT":
            profit = ((abs(r['entry'] - r['exit']) * pos_size) * 0.8 if r['tp1_hit'] else 0.0) + ((abs(r['entry'] - r['exit']) * pos_size) * 0.2)
            
        bt_account += profit
        r['profit_usd'] = profit

    wins = sum(1 for r in all_results if r['profit_usd'] > 0)
    losses = sum(1 for r in all_results if r['profit_usd'] < 0)
    bes = sum(1 for r in all_results if r['profit_usd'] == 0)
    
    msg = f"📊 <b>نتيجة الباكتيست الصارم ({days_back} يوماً)</b>\n"
    msg += f"────────────────\n"
    msg += f"إجمالي الصفقات المنفذة: {len(all_results)}\n"
    msg += f"✅ صفقات رابحة: {wins}\n"
    msg += f"🛡️ صفقات تعادل: {bes}\n"
    msg += f"❌ صفقات خاسرة: {losses}\n"
    msg += f"────────────────\n"
    msg += f"💵 الرصيد المبدئي: 100.00$\n"
    msg += f"💰 <b>الرصيد النهائي: {bt_account:.2f}$</b>\n"
    msg += f"📈 <b>صافي الربح: +{((bt_account-100)/100)*100:.2f}%</b>\n"
    bot.send_message(CHAT_ID, msg, parse_mode='HTML', reply_markup=main_menu())


# ================= أوامر التيليجرام =================
@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    global is_live_active, CHAT_ID
    CHAT_ID = call.message.chat.id
    
    if call.data == "toggle_live":
        if is_live_active:
            is_live_active = False
            bot.answer_callback_query(call.id, "تم الإيقاف.")
            bot.send_message(CHAT_ID, "🔴 تم إيقاف التداول الحي والمراقبة.", reply_markup=main_menu())
        else:
            is_live_active = True
            bot.answer_callback_query(call.id, "تم التشغيل.")
            bot.send_message(CHAT_ID, "🟢 بدأ التداول الحي! سأقوم بمسح السوق الآن وأخبرك بأفكاري...", reply_markup=main_menu())
            
    elif call.data == "check_status":
        bot.answer_callback_query(call.id, "جاري فحص الحساب...")
        msg = f"🏦 <b>حالة الحساب</b>\n"
        msg += f"الرصيد الحالي: <code>{live_account:.2f}$</code>\n\n"
        if not active_trades:
            msg += "ليس لديك أي صفقات مفتوحة."
        else:
            msg += "📋 <b>الصفقات המفتوحة:</b>\n"
            for k, v in active_trades.items():
                msg += f"🪙 {k} | {v['bias']}\n   الستوب الحالي: {v['current_sl']:.4f}\n"
        bot.send_message(CHAT_ID, msg, parse_mode='HTML', reply_markup=main_menu())
        
    elif call.data == "live_thoughts":
        bot.answer_callback_query(call.id, "جاري قراءة أفكار البوت...")
        # نجلب تفكير البوت لأول عملة كعينة
        symbol = "BTC/USDT"
        data = brain.data_manager.fetch_ohlcv_up_to(symbol, "15m", int(time.time()*1000), limit=200)
        anchor = compute_mechanical_bias_anchor(data, lookback=150)
        bias = anchor.get("anchor_direction")
        if bias not in ["BULLISH", "BEARISH"]:
            bot.send_message(CHAT_ID, f"🧠 <b>تفكير البوت | {symbol}</b>\nالسوق حالياً متذبذب. لا يوجد اتجاه يومي واضح. لا يمكنني المخاطرة برصيدك هنا، سأنتظر.", parse_mode='HTML')
        else:
            sig = ae.detect_significant_swings(data, swing_window=3, lookback_candles=150)
            levels = sig.get("all_lows_tiered", []) if bias == "BULLISH" else sig.get("all_highs_tiered", [])
            target = levels[0]['price'] if levels else 0
            msg = format_thoughts(symbol, bias, False, target)
            bot.send_message(CHAT_ID, msg, parse_mode='HTML', reply_markup=main_menu())
            
    elif call.data == "run_bt_30":
        bot.answer_callback_query(call.id, "بدء الباكتيست في الخلفية...")
        threading.Thread(target=strict_backtest_thread, args=(30,), daemon=True).start()

if __name__ == "__main__":
    print("🚀 جاري تشغيل خادم ICT للتيليجرام...")
    threading.Thread(target=live_scanner_thread, daemon=True).start()
    try:
        bot.infinity_polling()
    except Exception as e:
        print(f"Error: {e}")
