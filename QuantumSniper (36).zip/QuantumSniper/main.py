import os, glob
import pandas as pd
import numpy as np

from data.data_processor import create_quantum_bars
from models.alpha_v2     import QuantumBrain
from models.risk         import RiskManager
from engine.simulator    import QuantumSimulator
from utils.real_data     import load_local_binance_data, generate_realistic_tick_data

def scan_csv(data_dir="data"):
    os.makedirs(data_dir, exist_ok=True)
    return glob.glob(os.path.join(data_dir, "*.csv"))

def select_file():
    files = scan_csv()
    if not files:
        print("[!] No CSV files in 'data' folder.")
        return None
    if len(files) == 1:
        return files[0]
    for i, f in enumerate(files):
        mb = os.path.getsize(f) / 1024 / 1024
        print(f"  [{i+1}] {os.path.basename(f)}  ({mb:.1f} MB)")
    while True:
        try:
            c = int(input(f"Select (1-{len(files)}): "))
            if 1 <= c <= len(files):
                return files[c-1]
        except ValueError:
            pass

def run_pipeline(csv_path):
    df_ticks = load_local_binance_data(csv_path)
    if df_ticks.empty:
        return None, None, []

    print("\n[*] Building Dollar-Volume Bars...")
    df_bars = create_quantum_bars(df_ticks, num_bars_target=600)

    brain      = QuantumBrain()
    df_signals = brain.think(df_bars)

    buy_bars = df_signals[df_signals['buy_signal'] == 1]
    print(f"\n[*] Signals found: {len(buy_bars)}")
    if not buy_bars.empty:
        print("\n── Top Narratives ──")
        top = buy_bars.nlargest(5, 'conviction')
        for _, r in top.iterrows():
            print(f"  {r['narrative']}")

    risk = RiskManager() 
    sim  = QuantumSimulator(initial_capital=10_000.0)
    results, logs = sim.run_simulation(df_signals, risk)

    return results, sim, logs

def print_stats(results, sim):
    print("\n" + "="*55)
    print("  PERFORMANCE REPORT")
    print("="*55)

    if results is None or results.empty:
        print("[!] No trades executed.")
        return

    sells = results[results['type'] == 'SELL']
    if sells.empty:
        print("[!] No closed trades.")
        return

    total_pnl = sim.capital - sim.initial_capital
    wr        = (sells['pnl_pct'] > 0).mean() * 100
    wins      = sells[sells['pnl_pct'] > 0]['pnl_pct']
    losses    = sells[sells['pnl_pct'] < 0]['pnl_pct']

    cap_used  = sim.initial_capital * 0.10
    gp        = (wins * cap_used).sum()
    gl        = abs((losses * cap_used).sum())
    pf        = gp / gl if gl > 0 else float('inf')

    avg_w     = wins.mean()   * 100 if len(wins)   > 0 else 0
    avg_l     = losses.mean() * 100 if len(losses) > 0 else 0
    exp       = (wr/100 * avg_w) + ((1-wr/100) * avg_l)

    eq        = sells['capital']
    peak      = eq.cummax()
    dd        = (eq - peak) / peak
    mdd       = dd.min() * 100 if not dd.empty else 0

    if 'scalp' in sells.columns:
        scalp_trades = sells[sells['scalp'] == True]
        swing_trades = sells[sells['scalp'] == False]
        scalp_wr = (scalp_trades['pnl_pct'] > 0).mean() * 100 if len(scalp_trades) > 0 else 0
        swing_wr = (swing_trades['pnl_pct'] > 0).mean() * 100 if len(swing_trades) > 0 else 0
    else:
        scalp_wr = swing_wr = 0
        scalp_trades = swing_trades = pd.DataFrame()

    print(f"Final Capital : ${sim.capital:,.2f}")
    print(f"Net PnL       : ${total_pnl:,.2f} ({total_pnl/sim.initial_capital*100:.2f}%)")
    print(f"Total Trades  : {len(sells)}")
    print(f"Win Rate      : {wr:.1f}%")
    print(f"Profit Factor : {pf:.2f}")
    print(f"Expectancy    : {exp:.2f}%/trade")
    print(f"Max Drawdown  : {mdd:.2f}%")
    print(f"Avg Win       : {avg_w:.2f}%")
    print(f"Avg Loss      : {avg_l:.2f}%")
    print(f"\n── Mode Breakdown ──")
    print(f"Scalp Trades  : {len(scalp_trades)} | WR: {scalp_wr:.1f}%")
    print(f"Swing Trades  : {len(swing_trades)} | WR: {swing_wr:.1f}%")

    with open("trade_log.txt", 'w', encoding='utf-8') as f:
        for log in sim.detailed_log:
            f.write(log + "\n")
    print("\n[*] Full log → trade_log.txt")

def menu():
    print("\n" + "="*55)
    print("  QUANTUM ICT ENGINE - AUTOMATED EXECUTION")
    print("="*55)
    
    files = scan_csv()
    if not files:
        print("[!] No CSV files in 'data' folder. Attempting fallback to mock data...")
        df_ticks = generate_realistic_tick_data()
        df_bars = create_quantum_bars(df_ticks, num_bars_target=600)
        
        brain = QuantumBrain()
        df_signals = brain.think(df_bars)
        
        risk = RiskManager()
        sim = QuantumSimulator(initial_capital=10_000.0)
        results, logs = sim.run_simulation(df_signals, risk)
        
        print_stats(results, sim)
        return
        
    f = files[0]
    print(f"[*] Auto-selected file: {f}")
    results, sim, logs = run_pipeline(f)
    if sim:
        print_stats(results, sim)

if __name__ == "__main__":
    menu()
