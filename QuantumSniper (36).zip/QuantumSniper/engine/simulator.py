import pandas as pd
import numpy as np

class QuantumSimulator:
    def __init__(self, initial_capital=10_000.0, taker_fee=0.001):
        self.initial_capital           = initial_capital
        self.capital                   = initial_capital
        self.taker_fee                 = taker_fee
        self.position                  = 0.0
        self.entry_price               = 0.0
        self.bars_held                 = 0
        self.highest_price_since_entry = 0.0
        self.initial_trade_capital     = 0.0
        self.structural_stop_price     = 0.0
        self.is_scalp                  = False
        self.current_max_bars          = 18
        self.trade_history             = []
        self.detailed_log              = []

    def slippage(self, base_price, order_usd, bar_vol, is_buy):
        base_slip = 0.00010
        pr        = order_usd / max(bar_vol, 1.0)
        impact    = 0.0003 * np.sqrt(pr) if pr > 0.04 else 0.0
        pct       = base_slip + impact
        return base_price * (1 + pct) if is_buy else base_price * (1 - pct)

    def run_simulation(self, df_signals, risk_manager):
        print(f"\n[*] Running Simulation | Capital: ${self.capital:,.2f}")
        df = df_signals.reset_index(drop=True)

        for i in range(len(df) - 1):
            bar = df.iloc[i]
            nxt = df.iloc[i + 1]

            if self.position > 0:
                self.highest_price_since_entry = max(
                    self.highest_price_since_entry, float(bar['high']))
                self.bars_held += 1

                exit_flag, reason = risk_manager.evaluate_position(
                    entry_price               = self.entry_price,
                    structural_stop_price     = self.structural_stop_price,
                    bars_held                 = self.bars_held,
                    current_price             = float(bar['close']),
                    current_atr               = float(bar['atr']),
                    highest_price_since_entry = self.highest_price_since_entry,
                    is_scalp                  = self.is_scalp,
                    max_hold_bars             = self.current_max_bars,
                )

                if exit_flag:
                    usd_val = self.position * float(nxt['open'])
                    fill    = self.slippage(float(nxt['open']), usd_val,
                                            float(bar['total_vol']), False)
                    gross   = self.position * fill
                    fee     = gross * self.taker_fee
                    net     = gross - fee
                    pnl_pct = (net - self.initial_trade_capital) / \
                               max(self.initial_trade_capital, 1.0)

                    self.capital += net
                    self.trade_history.append({
                        'type'     : 'SELL',
                        'price'    : fill,
                        'reason'   : reason,
                        'pnl_pct'  : pnl_pct,
                        'capital'  : self.capital,
                        'bars_held': self.bars_held,
                        'scalp'    : self.is_scalp,
                    })
                    log = (
                        f"[SELL] ${fill:,.0f} | {reason[:40]} | "
                        f"PnL:{pnl_pct*100:.2f}% | "
                        f"{'Scalp' if self.is_scalp else 'Swing'}\n"
                        f"  {bar.get('narrative','')}\n" + "-"*55
                    )
                    self.detailed_log.append(log)
                    print(f"  {log.splitlines()[0]}")

                    self.position = self.entry_price = 0.0
                    self.bars_held = 0
                    self.highest_price_since_entry = 0.0
                    self.structural_stop_price = 0.0
                    self.is_scalp = False
                    self.current_max_bars = 18

            elif self.position == 0 and int(bar.get('buy_signal', 0)) == 1:
                is_scalp  = bool(bar.get('is_scalp',   False))
                sizing    = float(bar.get('trade_size', 0.10))
                max_bars  = int(bar.get('max_bars',    18))

                usd = self.capital * sizing
                if usd < 10.0:
                    continue

                fill = self.slippage(float(nxt['open']), usd,
                                     float(bar['total_vol']), True)
                fee  = usd * self.taker_fee
                qty  = (usd - fee) / fill

                self.position                  = qty
                self.entry_price               = fill
                self.bars_held                 = 0
                self.highest_price_since_entry = fill
                self.initial_trade_capital     = usd
                self.capital                  -= usd
                self.structural_stop_price     = float(
                    bar.get('structural_stop_level', fill - float(bar['atr']))
                )
                self.is_scalp         = is_scalp
                self.current_max_bars = max_bars

                self.trade_history.append({
                    'type'      : 'BUY',
                    'price'     : fill,
                    'conviction': bar.get('conviction', 0),
                    'threshold' : bar.get('dynamic_threshold', 0),
                    'capital'   : self.capital + usd,
                    'scalp'     : is_scalp,
                    'narrative' : bar.get('narrative', ''),
                })
                log = (
                    f"[BUY] ${fill:,.0f} | "
                    f"Conv:{bar.get('conviction',0):.0f}>"
                    f"Thr:{bar.get('dynamic_threshold',0):.0f} | "
                    f"{'Scalp' if is_scalp else 'Swing'} "
                    f"{sizing*100:.0f}%\n"
                    f"  {bar.get('narrative','')}\n" + "-"*55
                )
                self.detailed_log.append(log)
                print(f"  {log.splitlines()[0]}")

        return pd.DataFrame(self.trade_history), self.detailed_log
