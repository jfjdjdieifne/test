import numpy as np
import pandas as pd

class MarketPerception:

    def find_liquidity_levels(self, df):
        n   = len(df)
        lo  = df['low'].values
        hi  = df['high'].values
        atr = df['atr'].values

        ssl_price = np.full(n, np.nan)
        bsl_price = np.full(n, np.nan)
        ssl_score = np.zeros(n)
        bsl_score = np.zeros(n)

        swing_low_count  = 0
        swing_high_count = 0

        for sw in [3, 5, 8]:
            w = float(sw) / 16.0 

            for i in range(sw, n - sw):
                atr_i = max(atr[i], 1.0)

                left_lo  = lo[i-sw:i]
                right_lo = lo[i+1:i+sw+1]
                left_hi  = hi[i-sw:i]
                right_hi = hi[i+1:i+sw+1]

                if len(left_lo) < sw or len(right_lo) < sw:
                    continue

                is_swing_low = bool(
                    (lo[i] <= left_lo).all() and
                    (lo[i] <= right_lo).all() and
                    lo[i] < left_lo.mean()
                )

                if is_swing_low:
                    depth = (left_lo.mean() - lo[i]) / atr_i
                    sc    = float(np.tanh(depth * 1.5)) * w

                    if np.isnan(ssl_price[i]):
                        ssl_price[i] = lo[i]
                        ssl_score[i] = sc
                        swing_low_count += 1
                    else:
                        ssl_score[i] = min(ssl_score[i] + sc, 1.0)

                is_swing_high = bool(
                    (hi[i] >= left_hi).all() and
                    (hi[i] >= right_hi).all() and
                    hi[i] > left_hi.mean()
                )

                if is_swing_high:
                    depth = (hi[i] - left_hi.mean()) / atr_i
                    sc    = float(np.tanh(depth * 1.5)) * w

                    if np.isnan(bsl_price[i]):
                        bsl_price[i] = hi[i]
                        bsl_score[i] = sc
                        swing_high_count += 1
                    else:
                        bsl_score[i] = min(bsl_score[i] + sc, 1.0)

        print(f"  [DEBUG] Raw swing lows: {swing_low_count} | swing highs: {swing_high_count}")

        ssl_s = pd.Series(ssl_price, index=df.index).ffill()
        bsl_s = pd.Series(bsl_price, index=df.index).ffill()

        ssl_q = pd.Series(ssl_score, index=df.index)
        bsl_q = pd.Series(bsl_score, index=df.index)
        ssl_q = ssl_q.replace(0, np.nan).ffill().fillna(0.20)
        bsl_q = bsl_q.replace(0, np.nan).ffill().fillna(0.20)

        last_ssl = 0
        decay_ssl = np.ones(n)
        for i in range(n):
            if not np.isnan(ssl_price[i]):
                last_ssl = i
            bars_since = i - last_ssl
            decay_ssl[i] = float(np.exp(-bars_since * 0.02))

        last_bsl = 0
        decay_bsl = np.ones(n)
        for i in range(n):
            if not np.isnan(bsl_price[i]):
                last_bsl = i
            bars_since = i - last_bsl
            decay_bsl[i] = float(np.exp(-bars_since * 0.02))

        ssl_q = ssl_q * pd.Series(decay_ssl, index=df.index)
        bsl_q = bsl_q * pd.Series(decay_bsl, index=df.index)

        ssl_s = ssl_s.where(ssl_s < df['close'], np.nan).ffill()

        return ssl_s, bsl_s, ssl_q.clip(0, 1), bsl_q.clip(0, 1)

    def find_equal_lows(self, df, tol_pct=0.0015):
        n   = len(df)
        eql = np.zeros(n)
        lo  = df['low'].values
        w   = 25

        for i in range(w, n):
            tol     = lo[i] * tol_pct
            past    = lo[i-w:i]
            matches = np.sum(np.abs(past - lo[i]) < tol)
            if matches >= 1:
                eql[i] = min(matches / 4.0, 1.0)

        return pd.Series(eql, index=df.index)

    def measure_sweep(self, df, ssl_s, ssl_q):
        n          = len(df)
        sweep_sc   = np.zeros(n)
        swept_lvl  = np.zeros(n)

        lo    = df['low'].values
        hi    = df['high'].values
        op    = df['open'].values
        cl    = df['close'].values
        atr   = df['atr'].values
        tvol  = df['total_vol'].values
        ssl   = ssl_s.fillna(0).values
        ssq   = ssl_q.fillna(0.2).values

        vol_med = pd.Series(tvol).rolling(20, min_periods=3).median().values

        sweep_count = 0
        for i in range(1, n):
            level = ssl[i]
            if np.isnan(level) or level <= 0:
                continue

            touched = lo[i] <= level * 1.001  
            if not touched:
                continue

            atr_i = atr[i] if atr[i] > 0 else 1.0
            vm    = vol_med[i] if not np.isnan(vol_med[i]) and vol_med[i] > 0 else tvol[i]

            penetration = max(0, (level - lo[i])) / atr_i
            closed_above = float(cl[i] > level)

            if penetration > 2.5 and cl[i] < level:
                sweep_sc[i] = 0.05  
                swept_lvl[i] = level
                continue

            wick_low     = min(op[i], cl[i]) - lo[i]
            candle_range = hi[i] - lo[i] + 1e-9
            wick_ratio   = wick_low / candle_range

            vol_anomaly = tvol[i] / (vm + 1e-9)
            vol_score   = float(np.tanh((vol_anomaly - 1.0) * 0.8))

            strength = float(ssq[i])

            if closed_above:
                base = 0.5
            else:
                base = 0.2 * ((cl[i] - lo[i]) / candle_range)  

            score = (
                base              * 0.40 +  
                vol_score      * 0.30 +  
                strength          * 0.20 +  
                (1 - penetration/2.5) * 0.10  
            )

            if penetration > 1.5:
                score *= 0.6  

            final_score = float(np.clip(score, 0, 1))
            sweep_sc[i]  = final_score
            swept_lvl[i]  = level
            if final_score > 0.25:
                sweep_count += 1

        print(f"  [DEBUG] Sweeps detected (>0.25): {sweep_count}")
        return (pd.Series(sweep_sc,  index=df.index),
                pd.Series(swept_lvl, index=df.index))

    def detect_bos(self, df, bsl_s):
        n       = len(df)
        bos_sc  = np.zeros(n)
        bsl     = bsl_s.fillna(0).values
        cl      = df['close'].values
        hi      = df['high'].values
        atr     = df['atr'].values
        tvol    = df['total_vol'].values

        vol_med = pd.Series(tvol).rolling(30, min_periods=5).median().values
        bos_count = 0

        for i in range(1, n):
            level = bsl[i]
            if np.isnan(level) or level <= 0:
                continue

            prev_close = cl[i-1]
            curr_close = cl[i]

            broke_above = (curr_close > level) and (prev_close <= level)
            if not broke_above:
                continue

            atr_i = atr[i] if atr[i] > 0 else 1.0
            break_strength = (curr_close - level) / (atr_i + 1e-9)

            vol_i   = tvol[i]
            vm = vol_med[i] if not np.isnan(vol_med[i]) and vol_med[i] > 0 else tvol[i]
            vol_score = np.tanh(vol_i / (vm + 1e-9) - 1.0)

            score = (np.tanh(break_strength) * 0.60 + vol_score * 0.40)

            final_score = float(np.clip(score, 0, 1))
            bos_sc[i]    = final_score
            if final_score > 0.20:
                bos_count += 1

        print(f"  [DEBUG] BOS events detected (>0.20): {bos_count}")
        return pd.Series(bos_sc, index=df.index)

    def find_order_blocks(self, df, bos_sc):
        n      = len(df)
        ob_hi  = np.full(n, np.nan)
        ob_lo  = np.full(n, np.nan)
        ob_mid = np.full(n, np.nan)
        ob_q   = np.zeros(n)

        op   = df['open'].values
        cl   = df['close'].values
        hi   = df['high'].values
        lo   = df['low'].values
        tvol = df['total_vol'].values
        bos  = bos_sc.values

        vol_med = pd.Series(tvol).rolling(30, min_periods=5).median().values

        for i in range(5, n):
            if bos[i] < 0.10:
                continue

            best_sc  = 0.0
            best_idx = -1

            for j in range(max(0, i-10), i):
                bearish_body = op[j] - cl[j]
                candle_range = hi[j] - lo[j] + 1e-9
                bearish_ratio = max(bearish_body / candle_range, 0)

                vm   = vol_med[j] if not np.isnan(vol_med[j]) and vol_med[j] > 0 else tvol[j]
                vol_score = np.tanh((tvol[j] / (vm + 1e-9)) - 0.5)

                bars_before_bos = i - j
                recency = np.exp(-bars_before_bos * 0.2)

                ob_candidate_score = (bearish_ratio * 0.40 + vol_score * 0.35 + recency * 0.25)

                if ob_candidate_score > best_sc:
                    best_sc = ob_candidate_score
                    best_idx = j

            if best_idx >= 0 and best_sc > 0.15:
                ob_hi[i]  = hi[best_idx]
                ob_lo[i]  = lo[best_idx]
                ob_mid[i] = (hi[best_idx] + lo[best_idx]) / 2
                ob_q[i]   = best_sc

        ob_hi_s  = pd.Series(ob_hi,  index=df.index).ffill()
        ob_lo_s  = pd.Series(ob_lo,  index=df.index).ffill()
        ob_mid_s = pd.Series(ob_mid, index=df.index).ffill()
        ob_q_s   = pd.Series(ob_q,   index=df.index).replace(0, np.nan).ffill().fillna(0)

        in_ob = ((df['low'] <= ob_hi_s) & (df['high'] >= ob_lo_s)).astype(float)

        return ob_hi_s, ob_lo_s, ob_mid_s, ob_q_s, in_ob

    def read_order_flow(self, df, lookback=100):
        ofi_raw = (df['buy_vol'] - df['sell_vol']) / (df['total_vol'] + 1e-9)

        def ep(arr):
            if len(arr) < 5:
                return 0.5
            return float(np.searchsorted(np.sort(arr[:-1]), arr[-1])) / max(len(arr) - 1, 1)

        ofi_pct = ofi_raw.rolling(lookback, min_periods=10).apply(ep, raw=True)
        ofi_acc = ofi_pct.diff(3)

        abs_imb      = (df['buy_vol'] - df['sell_vol']).abs()
        rolling_imb  = abs_imb.rolling(50, min_periods=5).sum()
        rolling_vol  = df['total_vol'].rolling(50, min_periods=5).sum()
        vpin         = rolling_imb / (rolling_vol + 1e-9)
        vpin_safety  = 1 - vpin.rolling(lookback, min_periods=10).apply(ep, raw=True)

        vol_ratio = df['total_vol'] / (df['total_vol'].rolling(10, min_periods=3).mean() + 1e-9)
        pullback_vol_low = (vol_ratio < 0.8).astype(float)  

        return {
            'ofi_raw'         : ofi_raw,
            'ofi_pct'         : ofi_pct,
            'ofi_acc'         : ofi_acc,
            'vpin'            : vpin,
            'vpin_safety'     : vpin_safety,
            'pullback_vol_low': pullback_vol_low,
        }

    def classify_regime_and_session(self, df):
        ema_fast = df['close'].ewm(span=21,  min_periods=1).mean()
        ema_mid  = df['close'].ewm(span=55,  min_periods=1).mean()
        ema_slow = df['close'].ewm(span=200, min_periods=1).mean()

        trend_score = (((ema_fast > ema_mid ).astype(float) * 0.40) + ((ema_mid  > ema_slow).astype(float) * 0.60))

        atr = df['atr']
        rel_vol = atr / (df['close'] + 1e-9)

        def ep(arr):
            if len(arr) < 5:
                return 0.5
            return float(np.searchsorted(np.sort(arr[:-1]), arr[-1])) / max(len(arr)-1, 1)

        vol_pct = rel_vol.rolling(100, min_periods=10).apply(ep, raw=True)

        session_quality = pd.Series(0.7, index=df.index)  
        if 'datetime' in df.columns:
            hours = pd.to_datetime(df['datetime']).dt.hour
            london_open = ((hours >= 7)  & (hours < 10)).astype(float)
            ny_open     = ((hours >= 13) & (hours < 16)).astype(float)
            asian       = ((hours >= 0)  & (hours < 6) ).astype(float)

            session_quality = (
                london_open * 1.0 +
                ny_open     * 0.9 +
                asian       * 0.5 +
                (~(london_open.astype(bool) | ny_open.astype(bool) | asian.astype(bool))).astype(float) * 0.7
            )

        return {
            'trend_score'    : trend_score,
            'vol_pct'        : vol_pct,
            'atr'            : atr,
            'session_quality': session_quality,
            'ema_fast'       : ema_fast,
            'ema_slow'       : ema_slow,
        }

    def simulate_htf(self, df, compression=5):
        df_htf = df.copy()
        group  = np.arange(len(df)) // compression

        agg = {
            'open'     : 'first',
            'high'     : 'max',
            'low'      : 'min',
            'close'    : 'last',
            'buy_vol'  : 'sum',
            'sell_vol' : 'sum',
            'total_vol': 'sum',
        }
        if 'timestamp' in df.columns:
            agg['timestamp'] = 'last'

        df_htf_grouped = df_htf.assign(_g=group).groupby('_g').agg(agg).reset_index(drop=True)
        htf_ema_fast = df_htf_grouped['close'].ewm(span=21,  min_periods=1).mean()
        htf_ema_slow = df_htf_grouped['close'].ewm(span=55,  min_periods=1).mean()
        htf_trend    = (htf_ema_fast > htf_ema_slow).astype(float)

        htf_trend_expanded = np.repeat(htf_trend.values, compression)[:len(df)]
        htf_trend_series   = pd.Series(htf_trend_expanded, index=df.index)

        return htf_trend_series

    def perceive(self, df_bars):
        df = df_bars.copy()

        df['atr'] = (df['high'] - df['low']).rolling(14, min_periods=1).mean()

        print("  [Perception] Finding real liquidity levels...")
        ssl_price, bsl_price, ssl_score, bsl_score = self.find_liquidity_levels(df)

        print("  [Perception] Detecting equal levels (EQL/EQH)...")
        eql_score = self.find_equal_lows(df)

        combined_ssl_score = (ssl_score * 0.6 + eql_score * 0.4).clip(0, 1)

        print("  [Perception] Measuring sweep events...")
        sweep_score, swept_ssl = self.measure_sweep(df, ssl_price, combined_ssl_score)

        print("  [Perception] Detecting Break of Structure...")
        bos_score = self.detect_bos(df, bsl_price)

        print("  [Perception] Finding Order Blocks...")
        ob_high, ob_low, ob_mid, ob_score, in_ob_zone = self.find_order_blocks(df, bos_score)

        print("  [Perception] Reading Order Flow...")
        of = self.read_order_flow(df)

        print("  [Perception] Classifying Regime & Sessions...")
        regime = self.classify_regime_and_session(df)

        print("  [Perception] Simulating HTF context...")
        htf_trend = self.simulate_htf(df, compression=5)

        df['ssl_price']        = ssl_price
        df['bsl_price']        = bsl_price
        df['ssl_score']        = combined_ssl_score
        df['eql_score']        = eql_score

        df['sweep_score']      = sweep_score
        df['swept_ssl']        = swept_ssl

        df['bos_score']        = bos_score

        df['ob_high']          = ob_high
        df['ob_low']           = ob_low
        df['ob_mid']           = ob_mid
        df['ob_score']         = ob_score
        df['in_ob_zone']       = in_ob_zone

        df['ofi_raw']          = of['ofi_raw']
        df['ofi_pct']          = of['ofi_pct']
        df['ofi_accel']        = of['ofi_acc']
        df['vpin']             = of['vpin']
        df['vpin_safety']      = of['vpin_safety']
        df['pullback_vol_low'] = of['pullback_vol_low']

        df['trend_score']      = regime['trend_score']
        df['vol_pct']          = regime['vol_pct']
        df['session_quality']  = regime['session_quality']
        df['htf_trend']        = htf_trend

        return df
