from models.perception import MarketPerception
from models.reasoning  import MarketReasoning
from models.decision   import DecisionEngine

class QuantumBrain:
    def __init__(self):
        self.perception = MarketPerception()
        self.reasoning  = MarketReasoning()
        self.decision   = DecisionEngine()

    def think(self, df_bars):
        print("\n[Brain] Phase 1/3 → Perception")
        df_p = self.perception.perceive(df_bars)

        print("\n[Brain] Phase 2/3 → Reasoning")
        df_r = self.reasoning.reason(df_p)

        print("\n[Brain] Phase 3/3 → Decision")
        df_s = self.decision.generate_signals(df_r)

        return df_s
