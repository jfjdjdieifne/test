import numpy as np
import pandas as pd

class DecisionEngine:
    def dynamic_threshold(self, trend_s, vol_pct, regime_mode):
        bases = {'up': 38.0, 'range': 42.0, 'down': 46.0}
        base  = bases.get(str(regime_mode), 42.0)

        vol_adj   = float(vol_pct)  * 8.0
        trend_adj = (0.5 - float(trend_s)) * 6.0

        return float(np.clip(base + vol_adj + trend_adj, 30.0, 65.0))

    def generate_signals(self, df_reasoned):
        df  = df_reasoned.copy()
        n   = len(df)

        signals    = np.zeros(n)
        stops      = np.zeros(n)
        thresholds = np.zeros(n)

        for i in range(12, n):
            trend_s     = float(df['trend'].iloc[i])
            vol_pct     = float(df['vol_pct'].iloc[i])
            regime_mode = df['regime_list'].iloc[i]

            thresh        = self.dynamic_threshold(trend_s, vol_pct, regime_mode)
            thresholds[i] = thresh

            if trend_s < 0.12:
                continue

            conviction = float(df['conviction'].iloc[i])

            if conviction >= thresh:
                if i >= 1 and signals[i-1] == 1:
                    continue
                signals[i] = 1
                stops[i]   = float(df['stop_raw'].iloc[i])

        df['buy_signal']            = signals
        df['structural_stop_level'] = stops
        df['dynamic_threshold']     = thresholds

        print(f"  ✓ Final buy signals: {int(signals.sum())}")
        return df
