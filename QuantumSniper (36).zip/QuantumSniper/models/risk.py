import numpy as np

class RiskManager:
    def __init__(self):
        pass

    def evaluate_position(self, entry_price, structural_stop_price,
                           bars_held, current_price, current_atr,
                           highest_price_since_entry,
                           is_scalp=False, max_hold_bars=18):

        atr = max(current_atr, 1.0)

        # 1. Hard Stop
        buf       = 0.18 * atr
        hard_stop = structural_stop_price - buf
        min_dist  = atr * (0.6 if is_scalp else 1.0)
        if (entry_price - hard_stop) < min_dist:
            hard_stop = entry_price - min_dist
        if current_price <= hard_stop:
            return True, "Hard Stop"

        # 2. Time Stop
        if bars_held >= max_hold_bars:
            moved = highest_price_since_entry - entry_price
            if moved < 0.30 * atr:
                return True, "Time Stop: No Move"
            if current_price < entry_price + 0.10 * atr:
                return True, "Time Stop: Faded"

        # 3. Scalp
        if is_scalp:
            t1 = entry_price + 0.8 * atr
            if highest_price_since_entry >= t1:
                be = entry_price + 0.05 * atr
                if current_price < be:
                    return True, "Scalp: BE"
            if highest_price_since_entry > entry_price + 1.2 * atr:
                trail = highest_price_since_entry - 0.6 * atr
                if current_price < trail:
                    return True, "Scalp: Trail"
            return False, "Hold(S)"

        # 4. Swing Breakeven
        t1 = entry_price + 1.6 * atr
        if highest_price_since_entry >= t1:
            be = entry_price + 0.08 * atr
            if current_price < be:
                return True, "Swing: BE"

        # 5. Swing Trailing
        t2 = entry_price + 2.5 * atr
        if highest_price_since_entry > t2:
            trail = highest_price_since_entry - 1.2 * atr
            if current_price < trail:
                return True, "Swing: Trail"

        return False, "Hold"
