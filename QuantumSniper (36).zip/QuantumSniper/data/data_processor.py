import numpy as np
import pandas as pd
from numba import njit

@njit
def generate_dollar_volume_bars(timestamps, prices, sizes,
                                 is_sell_initiator, target_dollar_volume):
    n = len(prices)
    out_ts   = np.zeros(n, dtype=np.int64)
    out_open = np.zeros(n, dtype=np.float64)
    out_high = np.zeros(n, dtype=np.float64)
    out_low  = np.zeros(n, dtype=np.float64)
    out_close= np.zeros(n, dtype=np.float64)
    out_bv   = np.zeros(n, dtype=np.float64)
    out_sv   = np.zeros(n, dtype=np.float64)

    bar_idx          = 0
    current_dv       = 0.0
    current_bv       = 0.0
    current_sv       = 0.0
    current_high     = -1e18
    current_low      =  1e18
    current_open     = 0.0
    is_new_bar       = True

    for i in range(n):
        price      = prices[i]
        size       = sizes[i]
        dollar_sz  = price * size
        is_sell    = is_sell_initiator[i]

        if is_new_bar:
            current_open = price
            current_high = price
            current_low  = price
            is_new_bar   = False

        current_high = max(current_high, price)
        current_low  = min(current_low,  price)

        vol_needed = target_dollar_volume - current_dv

        if dollar_sz < vol_needed:
            current_dv += dollar_sz
            if is_sell: current_sv += dollar_sz
            else:        current_bv += dollar_sz
        else:
            fill = vol_needed
            rem  = dollar_sz - vol_needed
            if is_sell: current_sv += fill
            else:        current_bv += fill

            out_ts[bar_idx]   = timestamps[i]
            out_open[bar_idx] = current_open
            out_high[bar_idx] = current_high
            out_low[bar_idx]  = current_low
            out_close[bar_idx]= price
            out_bv[bar_idx]   = current_bv
            out_sv[bar_idx]   = current_sv
            bar_idx += 1

            while rem >= target_dollar_volume:
                out_ts[bar_idx]    = timestamps[i]
                out_open[bar_idx]  = price
                out_high[bar_idx]  = price
                out_low[bar_idx]   = price
                out_close[bar_idx] = price
                if is_sell:
                    out_bv[bar_idx] = 0.0
                    out_sv[bar_idx] = target_dollar_volume
                else:
                    out_bv[bar_idx] = target_dollar_volume
                    out_sv[bar_idx] = 0.0
                bar_idx += 1
                rem -= target_dollar_volume

            current_dv   = rem
            current_bv   = rem if not is_sell else 0.0
            current_sv   = rem if is_sell     else 0.0
            current_open = price
            current_high = price
            current_low  = price
            is_new_bar   = (current_dv == 0)

    return (out_ts[:bar_idx], out_open[:bar_idx],
            out_high[:bar_idx], out_low[:bar_idx],
            out_close[:bar_idx], out_bv[:bar_idx], out_sv[:bar_idx])


def create_quantum_bars(tick_df, num_bars_target=600):
    ts       = tick_df['timestamp'].values
    prices   = tick_df['price'].values
    sizes    = tick_df['size'].values
    is_sell  = tick_df['is_buyer_maker'].values

    total_dv = float(np.sum(prices * sizes))
    target   = total_dv / num_bars_target

    print(f"[*] Dollar Bar Target: ${target:,.0f} per bar (~{num_bars_target} bars)")

    t, o, h, l, c, bv, sv = generate_dollar_volume_bars(
        ts, prices, sizes, is_sell, target
    )

    df = pd.DataFrame({
        'timestamp': t,
        'open'     : o,
        'high'     : h,
        'low'      : l,
        'close'    : c,
        'buy_vol'  : bv,
        'sell_vol' : sv,
        'total_vol': bv + sv,
    })

    df['ofi_ratio'] = (df['buy_vol'] - df['sell_vol']) / (df['total_vol'] + 1e-9)
    df['datetime']  = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')

    print(f"[*] Created {len(df)} Dollar-Volume Bars | Price range: ${df['close'].min():,.0f} - ${df['close'].max():,.0f}")
    return df
