import os, glob
import pandas as pd
import numpy as np

def load_local_binance_data(csv_path):
    print(f"\n[*] Loading: {csv_path}...")
    try:
        df = pd.read_csv(csv_path, header=None)
    except Exception as e:
        print(f"[!] Error: {e}")
        return pd.DataFrame()

    try:
        df = df[[5, 1, 2, 6]]
    except KeyError:
        df.columns = range(len(df.columns))
        df = df[[5, 1, 2, 6]]

    df.columns = ['timestamp', 'price', 'size', 'is_buyer_maker']

    df['price']     = pd.to_numeric(df['price'],     errors='coerce')
    df['size']      = pd.to_numeric(df['size'],      errors='coerce')
    df['timestamp'] = pd.to_numeric(df['timestamp'], errors='coerce')
    df = df.dropna()

    df['timestamp']      = df['timestamp'].astype(np.int64)
    df['is_buyer_maker'] = df['is_buyer_maker'].astype(bool)

    mask_micro = df['timestamp'] > 10_000_000_000_000
    df.loc[mask_micro, 'timestamp'] = df.loc[mask_micro, 'timestamp'] // 1000

    valid = (df['timestamp'] > 1_514_764_800_000) & \
            (df['timestamp'] < 1_893_456_000_000)
    dropped = (~valid).sum()
    if dropped > 0:
        print(f"[!] Dropped {dropped:,} invalid timestamps")
    df = df[valid]

    q1  = df['price'].quantile(0.001)
    q99 = df['price'].quantile(0.999)
    price_valid = (df['price'] > q1) & (df['price'] < q99) & (df['price'] > 0)
    df = df[price_valid]

    df = df.sort_values('timestamp').reset_index(drop=True)

    if not df.empty:
        sample_price = df['price'].median()
        sample_ts    = pd.to_datetime(df['timestamp'].iloc[0], unit='ms')
        print(f"[*] Loaded {len(df):,} ticks | "
              f"Median Price: ${sample_price:,.2f} | "
              f"Start: {sample_ts.date()}")

    return df

def generate_realistic_tick_data(num_ticks=1_000_000):
    print("\n[*] GENERATING ADVANCED FULL-MONTH SIMULATION (1 Million Ticks)...")
    np.random.seed(42)
    start_time = 1717200000000 
    time_increments = np.random.exponential(scale=1000, size=num_ticks).astype(np.int64)
    timestamps = start_time + np.cumsum(time_increments)
    returns = np.random.normal(0.000001, 0.00005, num_ticks)
    
    returns[500000:510000] -= 0.0004 
    returns[510000:520000] += 0.0006 
    returns[700000:750000] -= 0.0001 
    
    prices = 60000.0 * np.exp(np.cumsum(returns))
    is_buyer_maker = np.where(returns < 0, 
                              np.random.choice([True, False], p=[0.6, 0.4], size=num_ticks),
                              np.random.choice([True, False], p=[0.4, 0.6], size=num_ticks))
    is_buyer_maker[510000:520000] = np.random.choice([True, False], p=[0.05, 0.95], size=10000)
    
    base_sizes = np.random.exponential(scale=0.5, size=num_ticks) 
    base_sizes[500000:510000] *= 3.0
    base_sizes[510000:520000] *= 8.0 
    
    df = pd.DataFrame({
        'timestamp': timestamps,
        'price': prices,
        'size': base_sizes,
        'is_buyer_maker': is_buyer_maker
    })
    return df
