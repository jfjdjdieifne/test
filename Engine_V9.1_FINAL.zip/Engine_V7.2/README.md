# Engine V7.2 "The Whale Hunter"

محرك تداول ICT للكريبتو سبوت — شراء فقط (Spot Long Only)

## المميزات

- **Dual Mode**: Hyper-Displacement (موجات خارقة) + Capital Guard (حماية رأس المال)
- **Multi-Stage Exit**: 4 مراحل للحلب الأقصى للأرباح
- **True CVD**: من بيانات aggTrades الحقيقية (ليس proxy)
- **Volume Bars ديناميكية**: إلغاء الشموع الزمنية
- **Microstructure Analysis**: Tick velocity + OFI + Absorption detection

## الأداء (يونيو 2026)

```
Base Balance:    $109.00
Final Balance:   $386.12
Return:          +254.24%

Total Trades:    502
Win Rate:        70.9%
Total PnL:       +$277.12
```

## التثبيت

```bash
pip install -r requirements.txt
```

## الاستخدام

```python
from engine_v6.core.collector import download_daily
from engine_v6.core.volume_bars import DynamicVolumeBarBuilder
from engine_v6.core.real_cvd import RealCVDAnalyzer
from engine_v6.core.microstructure import MicrostructureAnalyzer
from engine_v6.core.energy import EnergyField
from engine_v6.core.strategy import NarrativeStrategy

# تحميل البيانات
trades = download_daily('BTCUSDT', 2026, 6, 14)

# بناء Volume Bars
builder = DynamicVolumeBarBuilder(min_volume=2.0, max_volume=100.0, percentile=50.0)
bars = builder.process_ticks(trades, progress_every=-1)
vbars = builder.to_dataframe(bars)

# التحليل
cvd = RealCVDAnalyzer(vbars)
micro = MicrostructureAnalyzer(trades, vbars)
ef = EnergyField(vbars, cvd, micro)

# الاستراتيجية
strategy = NarrativeStrategy(ef, vbars, balance=109.0, risk_pct=0.01, max_open=3)

# محاكاة
n = len(vbars)
for i in range(50, n - 1):
    strategy.process_pending(i)
    strategy.manage_trades(i)
    if len(strategy.open_trades) + len(strategy.pending_trades) < 3:
        plan = strategy.generate_signal(i)
        if plan:
            strategy.add_pending(plan)

# إغلاق الصفقات المفتوحة
for t in list(strategy.open_trades):
    strategy._close_trade(t, n-1, vbars['close'].iloc[n-1], 'END')

# النتائج
print(f'Trades: {len(strategy.closed_trades)}')
print(f'Wins: {sum(1 for t in strategy.closed_trades if t.realized_pnl > 0)}')
print(f'Win Rate: {sum(1 for t in strategy.closed_trades if t.realized_pnl > 0) / len(strategy.closed_trades) * 100:.1f}%')
print(f'PnL: ${sum(t.realized_pnl for t in strategy.closed_trades):+.4f}')
print(f'Balance: ${strategy.balance:.2f}')
```

## البنية

```
engine_v6/
├── core/
│   ├── collector.py          # تحميل aggTrades من Binance
│   ├── volume_bars.py        # Dynamic Volume Bars
│   ├── real_cvd.py           # CVD حقيقي من tick data
│   ├── microstructure.py     # Tick velocity + OFI + Institutional footprint
│   ├── energy.py             # حقل الطاقة التكيفي
│   └── strategy.py           # The Whale Hunter (Dual Mode + Multi-Stage Exit)
```

## المتطلبات

- Python 3.8+
- numpy
- pandas
- requests

## الترخيص

MIT License
